// v1.7i (elevator fit integration): the E1 latch post (20) in its NEW print pose (on its crank-side face), world numbers.
//   FEA (X, Y, Z) = (Xw, -Zw, Yw): Z = the layer direction (world Y).
// openscad --backend=Manifold -D 'fk="e1_latch_post"' -o fea/stl17/e1_latch_post_v17i.stl v17i_fea_e1.scad
include <coaster_e1.scad>
part = "none";
fk = "e1_latch_post";
if (fk=="e1_latch_post") rotate([90,0,0]) translate(E1_ORIGIN) latch_post_v1();
