// v1.8 modular: ELEVATOR 2 LIFT KIT for a lower coaster (docs/modules_v1.8.md section 9; docs/coaster_v1.8_modular.md).
// Elevator 2 is FROZEN (plate 1). The kit changes nothing on the frozen parts: the tower 26 keeps its shape and holes.
//  - PB2 pivot block: a plug that fills the tower's upper-left window (the window's legs and diagonal locate it), a
//    3 mm plate on the tower's front face (world +Y, rig y 13..16) and a strap on the lever-side face (rig y 3.4..5,
//    left of the lever hub). 2 x M3 x 16 along Y through plate, plug and strap (nut on the strap). The new fulcrum pin
//    3 x 20 is pressed in the plug + plate; the lever turns on it with the v1.7 spacer, MR63 pair and collar.
//    The old fulcrum pin stays in the tower (no load).
//  - 27-H lever: cup pin, roller and gate-cord tie hole at the SAME world points at rest as the v1.7 lever, so the cup,
//    floor, latch, crank and the gate cord see no change at rest. Shorter arm, smaller swing; the effort (rope) arm
//    scales with the arm (same IMA, 0.518).
//  - rope: shorter (the crown with P1, P3 and the anchor moves down by dZ); the pot travel is less.
//  - 39 tip cams: reprint for the new arc (generated from E2k_pin(a): to do with the crown, "go full").
// Fallback (owner's rule: only if PB2 fails): a new tower 26-H with the fulcrum at E2k_F.
// part = "pb2" (print pose) | "lever27H" (print pose) | "world" (kit at rest + the frozen tower, for checks) | "info"
include <coaster_e2.scad>
part2 = "none";
part_k = "world";
kit_dZ = 66.2813;                     // how much lower the coaster top is (v18_dZ in coaster_v1.scad; 1.5 deg / 19 levels)
// ---- the v1.7 values (rig coordinates; world = rig + [262, 67, 0]) ----
F0 = F; A0 = A; EF0 = EF; SW0 = SW; R0r = R_local;
E0 = [F0[0] + A0*cos(-SW0), 0, F0[2] + A0*sin(-SW0)];           // cup pin at rest (0, 0, 54)
Rr = [F0[0] + R0r*cos(-SW0), 0, F0[2] + R0r*sin(-SW0)];         // roller at rest (-26, 0, 88.6)
T0 = [F0[0] + 30*cos(-SW0), 0, F0[2] + 30*sin(-SW0)];           // gate tie hole at rest
T0top = [F0[0] + 30*cos(SW0), 0, F0[2] + 30*sin(SW0)];
// ---- the kit ----
E2k_F = F0 + [0, 0, -kit_dZ/2];                                 // new fulcrum: straight down the tower
E2k_A = norm([E0[0]-E2k_F[0], E0[2]-E2k_F[2]]);
E2k_SW = -atan2(E0[2]-E2k_F[2], E0[0]-E2k_F[0]);                // symmetric swing +-E2k_SW
E2k_EF = EF0*E2k_A/A0;
function pol(p) = [norm([p[0]-E2k_F[0], p[2]-E2k_F[2]]), atan2(p[2]-E2k_F[2], p[0]-E2k_F[0]) + E2k_SW];   // [r, angle from the lever line]
E2k_R = pol(Rr);                                                // roller: off the lever line by a small angle
// gate tie hole: the same point at rest, and the same vertical travel over the swing as v1.7 (30 (sin 53.1 + sin 53.1) = 48.0)
tr0 = T0top[2] - T0[2];
function tie_r(phi) = (T0[0]-E2k_F[0]) / cos(phi - E2k_SW);
function tie_travel(phi) = tie_r(phi)*(sin(E2k_SW+phi) - sin(-E2k_SW+phi));
function tie_solve(lo, hi, k=0) = k > 40 ? (lo+hi)/2 : let(m=(lo+hi)/2) (tie_travel(m) > tr0 ? tie_solve(m, hi, k+1) : tie_solve(lo, m, k+1));   // (travel grows as phi goes negative)
E2k_tphi = tie_solve(-40, 0);
E2k_T = [tie_r(E2k_tphi), E2k_tphi];
function E2k_pin(a) = [E2k_F[0] + E2k_A*cos(a), 0, E2k_F[2] + E2k_A*sin(a)];
function E2k_rope(a) = [E2k_F[0] + E2k_EF*cos(a), 0, E2k_F[2] + E2k_EF*sin(a)];
function E2k_tie(a) = [E2k_F[0] + E2k_T[0]*cos(a+E2k_T[1]), 0, E2k_F[2] + E2k_T[0]*sin(a+E2k_T[1])];
// ---- 27-H lever (lever coordinates: fulcrum at the origin, cup pin on +X, as lever2()) ----
module lever27H() difference() {
    union() {
        translate([0,0,lev2_hub_dz]) cylinder(d=18, h=8, center=true);
        hull() { cylinder(d=14, h=5.8, center=true); translate([E2k_A-30,0,0]) cylinder(d=9, h=5.8, center=true); }
        hull() { translate([0,0,lev2_hub_dz]) cylinder(d=18, h=8, center=true); translate([35,0,0]) cylinder(d=13, h=5.8, center=true); }
        hull() { translate([E2k_A-30,0,0]) cylinder(d=9, h=5.8, center=true); translate([E2k_A-12,lev_knee,0]) cylinder(d=9, h=5.8, center=true); }
        hull() { translate([E2k_A-12,lev_knee,0]) cylinder(d=9, h=5.8, center=true); translate([E2k_A,0,0]) cylinder(d=9, h=5.8, center=true); }
        hull() { translate([E2k_A,0,0]) cylinder(d=9, h=5.8, center=true); translate([E2k_EF,0,0]) cylinder(d=9, h=5.8, center=true); }
        let(p=[E2k_R[0]*cos(E2k_R[1]), E2k_R[0]*sin(E2k_R[1])]) hull() { translate([p[0], p[1], 0.1]) cylinder(d=9, h=6, center=true); translate([p[0], 0, 0]) cylinder(d=9, h=5.8, center=true); }   // roller boss (off the line)
        let(p=[E2k_T[0]*cos(E2k_T[1]), E2k_T[0]*sin(E2k_T[1])]) hull() { translate([p[0], p[1], 0]) cylinder(d=6, h=5.8, center=true); translate([p[0], 0, 0]) cylinder(d=9, h=5.8, center=true); }   // tie-hole ear
    }
    cylinder(d=4.5, h=20, center=true);
    for (z=[-4.01+lev2_hub_dz, 4.01+lev2_hub_dz-brg_h]) translate([0,0,z]) brg_pocket();
    translate([E2k_A,0,0]) cylinder(d=pin_turn, h=20, center=true, $fn=fit_fn);
    translate([E2k_R[0]*cos(E2k_R[1]), E2k_R[0]*sin(E2k_R[1]), 0]) cylinder(d=pin_press, h=20, center=true, $fn=fit_fn);
    translate([E2k_EF-2.5, 0, 0]) cylinder(d=2.2, h=20, center=true);
    translate([E2k_T[0]*cos(E2k_T[1]), E2k_T[0]*sin(E2k_T[1]), 0]) cylinder(d=2.2, h=20, center=true);
    translate([60,0,2.4]) linear_extrude(1.5) text("ELEVATOR 2 - TYPE 2", size=4.5, valign="center");
}
module lever27H_at(a) translate(E2k_F) rotate([0,-a,0]) rotate([90,0,0]) lever27H();   // rig coordinates
// ---- PB2 pivot block (rig coordinates). The tower's upper-left window (E2_tower): x F0-14 .. diagonal, z 14 .. F0z-16.
pb_x0 = F0[0]-14; pb_x1 = F0[0]+14; pb_z0 = 14; pb_z1 = F0[2]-16; pb_k = 6*sqrt(2);
function win1() = [[pb_x0, pb_z0+pb_k], [pb_x0, pb_z1], [pb_x1-pb_k*(pb_x1-pb_x0)/(pb_z1-pb_z0), pb_z1]];
pb_c = 0.2;                                  // clearance in the window
pb_zb = E2k_F[2] - 24;                       // plug bottom
pb_bolts = [[F0[0]-10.5, E2k_F[2]-9], [F0[0]-10.5, E2k_F[2]+9]];
module pb2_plug2d() intersection() { offset(delta=-pb_c) polygon(win1()); translate([pb_x0-1, pb_zb]) square([40, pb_z1-pb_zb+1]); }
module pb2() difference() {
    union() {
        rotate([90,0,0]) translate([0,0,-13]) linear_extrude(8) pb2_plug2d();                         // plug: rig y 5..13
        translate([F0[0]-20, 13, pb_zb-2]) cube([40, 3, pb_z1-pb_zb+2+8]);                              // front plate, rig y 13..16 (up over the window top bar)
    }
    translate([E2k_F[0], 5-0.01, E2k_F[2]]) rotate([-90,0,0]) cylinder(d=pin_press, h=11.02, $fn=fit_fn);    // new fulcrum pin, pressed 11 mm
    for (b=pb_bolts) translate([b[0], 0, b[1]]) rotate([-90,0,0]) cylinder(d=m3_clear, h=30, $fn=16);
}
// the strap is a separate part (it goes on the lever side, the plug + plate from the front)
module pb2_main() pb2();
// strap on the lever-side face (rig y 3.4..5, x F-21..F-7: on the tower's left leg, left of the lever hub), its own part
module pb2_strap() difference() { translate([F0[0]-21, 3.4, pb_zb]) cube([14, 1.6, 2*(E2k_F[2]-pb_zb)]);
    for (b=pb_bolts) translate([b[0], 0, b[1]]) rotate([-90,0,0]) cylinder(d=m3_clear, h=30, $fn=16); }
module E2k_world_rest() translate(E2_ORIGIN) { color("#59646f") E2_tower(); color("#d08a4a") { pb2(); pb2_strap(); } color("#59a5c4") lever27H_at(-E2k_SW); }
echo(E2k_F=E2k_F+E2_ORIGIN, E2k_A=E2k_A, E2k_SW=E2k_SW, E2k_EF=E2k_EF, IMA=(E2k_EF/E2k_A)*0.5, E2k_R=E2k_R, E2k_T=E2k_T,
     tie_travel=tie_travel(E2k_tphi), tie_travel_v17=tr0, lift=2*E2k_A*sin(E2k_SW), lift_v17=2*A0*sin(SW0),
     top_pin_world=E2k_pin(E2k_SW)+E2_ORIGIN, top_pin_v17=[F0[0]+A0*cos(SW0), 0, F0[2]+A0*sin(SW0)]+E2_ORIGIN, rope_top=E2k_rope(E2k_SW)+E2_ORIGIN);
if (part_k=="pb2")       rotate([-90,0,0]) translate([0,-16,0]) pb2_main();     // print on the front plate's outer face (rig y 16): the pin hole stands
if (part_k=="pb2_strap") rotate([90,0,0]) translate([0,-3.4,0]) pb2_strap();
if (part_k=="lever27H")  translate([0,0,2.9]) lever27H();                      // flat, as lever2_print()
if (part_k=="world")     E2k_world_rest();
