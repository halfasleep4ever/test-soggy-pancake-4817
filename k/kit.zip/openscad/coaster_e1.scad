// Coaster v1 wrapper for Elevator 1 (Type 1). Uses the tested rig parts from elevator1_test.scad (lever, cup, latch,
// wheel, idler, counterweight pot) but places them for the full coaster:
//  - the pins sit in the front frame IN FRONT of the lever (rig: a plate behind it; behind is the ramp stack now),
//  - the idler and counterweight move to the front-left corner (behind the loop chute, in front of the stack),
//  - no rig base, no feed risers, no top tray (the coaster has its own feed and the ladder funnel).
// Rig coordinates: lever plane y = 0, z up from the coaster base top. coaster_v1.scad places it at world (245.8, 103, 0)
// (the FRONT elevator: fed by the loop).
include <elevator1_test.scad>
part = "none";
// v1: longer ball arm so the lift reaches the top ladder position (rig: 205 mm, lift 324 -> 226 mm, lift about 357)
A = 226;
E1_ORIGIN = [245.8, 103, 0];
I1 = [10 - E1_ORIGIN[0], 98 - E1_ORIGIN[1], 262];             // idler (world X 10, Y 98, Z 262): 41.6 mm left of the wheel
                                                            // centre, as in the rig, so the pot (r 20) hangs clear of the wheel (r 25)
// v5 (2026-10-28): the v4 plate was solid (world X 44..150, Z 0..250) and hid the ramps from the front. Same plate,
// now a truss: 8 mm border, a 10 mm diagonal in each bay, a cross bar through the wheel pin and a low bar through
// the loop's lead-in tab; hubs round both pins. v5b: no loop board. The loop bolts to it (5 tabs, 2 of them through the
// two loop brackets, coaster_v1.scad loop_brackets()).
pw = 8;                                                     // member width
function e1w(p) = [p[0] + E1_ORIGIN[0], p[2]];              // rig point -> world (X, Z)
// v1.7 FEA (v3): the left loop-bracket bolts (48, 122) and (48, 138) have their 6.6 mm nut pockets 1.1 mm from the
// border's outer edge (X 44): 8.9 MPa there (x5, SF 2.2). The border gets a pad out to X 41 round both bolts (hidden
// behind the loop bracket from the front), tapering back to X 44 at Z 100 and Z 160.
module E1_plate_2d() union() {
    E1_plate_2d_v16();
    hull() { for (q=[[48, 122], [48, 138]]) translate(q) circle(r=7, $fn=28);
             for (z=[100, 160]) translate([45, z]) square([0.01, 0.01], center=true); }   // v4: long taper, no notch at X 44
}
module E1_plate_2d_v16() let(Wp=e1w(W), Pp=e1w(P), x0=44, x1=150, z1=250, zL=32.6, zW=Wp[1]) difference() {
    translate([x0, 0]) square([x1-x0, z1]);
    for (c=[[[x0, 0], [x1, zL]], [[x0, zL], [x1, zW]], [[x0, zW], [x1, z1]]]) let(a=c[0], b=c[1],
            lo=[a[0]+pw, a[1]+(a[1]==0 ? pw : pw/2)], hi=[b[0]-pw, b[1]-(b[1]==z1 ? pw : pw/2)])
        if (hi[1]-lo[1] > 12) offset(r=2, $fn=12) offset(delta=-2) difference() {
            translate(lo) square(hi-lo);
            if (b[1] == z1) hull() { translate(Wp) circle(d=10, $fn=16); translate(Pp + (Pp-Wp)*0.25) circle(d=10, $fn=16); }   // the W -> P diagonal
            else hull() { translate(a) circle(d=10, $fn=16); translate(b) circle(d=10, $fn=16); }
            translate(Wp) circle(r=10, $fn=32); translate(Pp) circle(r=11, $fn=32);
            translate([145, 179.6]) circle(r=8, $fn=24);   // pad for the loop top tab screw
            for (q=[[108.25, 169.75], [67.2, 44.5]]) translate(q) circle(r=8.5, $fn=24);   // v5b: pads for the loop tab bolts (on the bars)
            hull() { translate([81.35, 142.85]) circle(r=8.5, $fn=24); translate([81.35, 158]) circle(r=5, $fn=16); }   // v5b: pad + strut to the bar
            // v1.7 FEA: pads round the bolts in the left and right borders (left loop bracket bolts, foot flange bolts). The
            // 6.6 mm nut pocket left 1.1 mm of an 8 mm border: the x5 load gave 11.7 MPa there (SF 1.7).
            for (q=[[48, 17], [48, 29], [146, 14]]) translate(q) circle(r=9, $fn=24);
            hull() for (q=[[48, 122], [48, 138]]) translate(q) circle(r=9, $fn=24);     // v2: one strip X 44..57, Z 113..147
            for (q=[[x1-pw/2, z1], [Pp[0], z1]]) hull() { translate(Pp) circle(d=8, $fn=16); translate(q) circle(d=8, $fn=16); }   // P hub to the top bar
        }
}
// v1.6 (printability): the plate is two prints. The FRAME (the 8 mm truss web) prints flat, its front face (rig y +13)
// on the bed: the pivot and wheel pin holes are vertical (round), the layers carry the lever load in plane, no support.
// The FOOT (the slab in front, rig y 13..35) is its own print, bolted to the frame's bottom corners with 3 x M3x12
// through two 4 mm flanges (nuts in hex pockets in the frame's back face, like the loop bolts). The right flange stops
// at Z 21 (the loop is in front of it from Z 21.6, 3 mm from the web).
// The two v1.5 gussets behind the web are gone: they hung 8 mm over the base and touched nothing (the foot is in
// front), and flat they would start in mid air over the truss openings. The flanges now tie the web to the foot.
// v1.5 printed it in one piece upright: 48 g of support, 7 h, a floating island at Z 31 and horizontal pin holes.
E1_foot_bolts = [[48, 17], [48, 29], [146, 14]];             // world X, Z of the foot-flange bolts (frame border columns)
module E1_frame() difference() {                            // world X 44..150, Y 108..116 (rig y +5..+13), Z 0..250
    translate([0, 13, 0]) rotate([90,0,0]) linear_extrude(8) translate([-E1_ORIGIN[0], 0]) E1_plate_2d();
    for (p=[P, W]) translate([p[0], 0, p[2]]) rotate([-90,0,0]) cylinder(d=pin_press, h=40, $fn=fit_fn);   // pivot + wheel pins (3 mm steel, press; standing in the print)
    // v5b (no loop board): M3 bolts from the loop's tabs (and the two loop brackets) through the plate; an M3 nut in a
    // hex pocket 2.6 mm deep in the plate's back face (the bolt tip stays 1 mm in front of the lever's plane)
    // v1.6: the same for the 4 foot bolts
    for (q=concat(E1_loop_bolts(), E1_foot_bolts)) translate([q[0]-E1_ORIGIN[0], 0, q[1]]) {
        rotate([-90,0,0]) cylinder(d=m3_clear, h=20, $fn=16);
        translate([0, 5-0.01, 0]) rotate([-90,0,0]) rotate([0,0,30]) cylinder(d=m3_nut, h=2.61, $fn=6);
    }
}
module E1_foot() difference() {                             // world X 44..150, Y 116..138 (rig y 13..35), Z 0..8 + flanges to Z 36
    union() {
        translate([44-E1_ORIGIN[0], 13, 0]) cube([106, 22, 8]);           // foot, bolted to the base (4 x M3x14 countersunk + nuts, below)
        for (f=[[44, 36], [138, 21]]) translate([f[0]-E1_ORIGIN[0], 13, 0]) cube([12, 4, f[1]]);   // flanges on the frame's front face
    }
    // v1.7: 4 x M3x14 countersunk from under the base (world (54, 125), (136, 125), (54, 133), (136, 133)), nuts in hex
    // pockets 2.6 mm deep in the foot's top (the foot prints slab down: the holes are vertical, open pockets, no bridge)
    for (x=[54, 136]-[E1_ORIGIN[0],E1_ORIGIN[0]], y=[22, 30]) translate([x, y, 0]) foot_bolt(8, tip=0, td=false);
    for (q=E1_foot_bolts) translate([q[0]-E1_ORIGIN[0], 15, q[1]]) tdrop_y(m3_clear, 10, up=true);   // horizontal in the print: teardrop
}
module E1_plate() { E1_frame(); E1_foot(); }                // assembled (the checks and pictures use this)
// v1.7 counterweight post (13). v1.6: a 12 x 6 mm column, 276 mm tall, with the idler 37 mm in front of it; the pot and
// the drum cord load the idler with about 11.6 N (down) and 1.4 N (toward +X). Hand check (PETG E 2000): the 6 mm depth
// bent about 30 mm (Y) and 5 mm (X) at the idler, 5.3 MPa at the foot. Now the column is 12 x 20 mm (world Y 55..75):
// about 0.8 mm (Y) and 1.5 mm (X) at the idler, about 1.3 MPa at the foot (FEA to confirm). The idler rubbed the arm 0.5 mm (J30): the arm is 1.5 mm higher (Z 269.5..277.5, idler
// top 268.5, 1.0 mm clear). The cheek is 6 mm (was 3) for a 6 mm press on the idler pin. The foot (J31) is 24 x 22 mm
// with 2 x M3x14 countersunk from under the base, nuts in pockets in the foot top.
cwp_y1 = 75; cwp_arm_z = 269.5; cwp_top = 277.5; cwp_cheek_y1 = I1[1]+12;  // world Y 75; arm bottom Z; top Z; cheek to world Y 110 (v17f FEA; was 107)
// v1.7 FEA (docs/fea_v1.7_elevators.md): with the 12 mm column and the bare arm, the x5 dead load gave 19 MPa (SF 1.05)
// in the inside corner under the arm (Y 75, Z 269.5) and 1.6 mm (X) at the idler at 1x. Now (v17f): the post is 16 mm
// wide (world X -2..14, was 2..14; the 4 mm sit behind the pot from the front, the size does not grow), and a knee
// gusset under the arm (Y 75..92, down to Z 233) takes the arm's moment into the column. Every piece starts at X -2,
// the print face.
cwp_x0 = -2;                                                // world X of the print face (was 2)
cwp_gus = [[75, 233], [75, cwp_arm_z+1], [92, cwp_arm_z+1], [92, cwp_arm_z]];   // knee gusset (world Y, Z): clear of the pot top (Z 220) and the idler (Y 95.5+)
E1_cw_bolts = [[20, 60], [20, 72]];                         // world X, Y of the two foot bolts
module E1_cwpost() difference() {                           // world X -2..14, Y 55..75 column; foot X -2..26, Y 55..77; arm forward over the pot to the idler
    yb = 55 - E1_ORIGIN[1]; xb = cwp_x0 - E1_ORIGIN[0];
    union() {
        translate([xb, yb, 0]) cube([14-cwp_x0, cwp_y1-55, cwp_top]);
        translate([xb, yb, 0]) cube([26-cwp_x0, 22, 8]);                     // foot
        translate([xb, yb, cwp_arm_z]) cube([14-cwp_x0, cwp_cheek_y1-yb, cwp_top-cwp_arm_z]);   // arm over the pot
        // v1.7 FEA: knee gusset under the arm, the full post width
        translate([xb, -E1_ORIGIN[1], 0]) rotate([90,0,90]) linear_extrude(14-cwp_x0) polygon(cwp_gus);
        // v1.7 FEA (v2): a side web on the print-face side (X -2..1.5, Y 80..101, Z 252..arm) ties the cheek to the
        // gusset and the arm: the cheek twisted the arm (layer shear 4.6 MPa at the cheek / arm corner, SF 2.2). The pot
        // cord hangs at X 3.5: 2 mm clear.
        translate([xb, 80-E1_ORIGIN[1], 252]) cube([1.5-cwp_x0, 101-80, cwp_arm_z-252+0.01]);
        // v1.7 FEA (v2, v3): the column's foot corner (X 14, Y 75) was the peak (8.7 MPa, x5). Fillets where the column
        // meets the foot: right face 2.5 x 25 mm (the nut pockets start at X 16.7), front face 5 x 4 mm on a foot that now
        // reaches Y 80 (2.8 mm under the pot's lowest point, Z 12.4). A back rib (X -2..8, Y 46..55, full height; the stop
        // cups start at X 10.1, Y 53) makes the column deeper.
        translate([14-E1_ORIGIN[0], yb, 8]) rotate([-90,0,0]) linear_extrude(cwp_y1-55) polygon([[-0.01,0.01],[2.5,0.01],[-0.01,-25]]);
        translate([xb, cwp_y1-E1_ORIGIN[1], 8]) rotate([90,0,90]) linear_extrude(14-cwp_x0) polygon([[-0.01,-0.01],[5,-0.01],[-0.01,4]]);
        translate([xb, cwp_y1-E1_ORIGIN[1], 0]) cube([14-cwp_x0, 5, 8]);                 // foot to Y 80 under the column
        translate([xb, yb-9, 0]) cube([8-cwp_x0, 9.01, cwp_top]);                       // back rib (v4: Y 46..55)
        translate([xb, yb-9, 0]) cube([26-cwp_x0, 9.01, 8]);                            // foot to Y 46
        // idler cheek (pin from here). v1.6: flush with the post's print face (v1.5 hung 3 mm over the bed: a 16 mm
        // floating cantilever). v1.7: world Y 101..110 (9 mm; v17f FEA, was 6), up to the arm top
        translate([xb, I1[1]+3, 252]) cube([I1[0]+5-xb, cwp_cheek_y1-(I1[1]+3), cwp_top-252]);
    }
    // idler pin: horizontal in the print, teardrop pointing to +X (up); lying press (v1.7i: pin_press_lying, was 3.15)
    translate([I1[0], I1[1]+5, I1[2]]) rotate([0,-90,0]) tdrop_y(pin_press_lying, 20);
    // v1.7: foot bolts. The post prints on its X -2 face: the holes are horizontal, the teardrop and a hex corner point to +X (up)
    for (q=E1_cw_bolts) translate([q[0]-E1_ORIGIN[0], q[1]-E1_ORIGIN[1], 0]) foot_bolt(8, tip=0);
}
// v1.7 counterweight pot (21). v1.6: a round pot d 40 x 110 (world X -16.5..23.5): from the front it hid the stop cups at
// the stack's left end (X 9..36) 42 to 57 % of the time. Now a slim box 20.4 (X) x 40 (Y) x 176 mm, the same inside
// volume (110 cm3 for about 560 g of steel), the same hanging point (cord through the bail hole at world X 3.5, Y 98,
// Z 217 at rest), so the same drop and the same function. World X -6.7..13.7 (the cups start at X 9), Y 78..118.
// It hangs 66 mm lower: its bottom is at Z 44 at rest and Z 12.4 at the top of the lift.
cwp_h = 176; cwp_hole = cwp_h - 3;
module cw_pot_v17() difference() {
    union() {
        difference() { translate([-10.2, -20, 0]) rbox_c(20.4, 40, cwp_h, 2);
                       translate([-8.6, -18.4, 2]) rbox_c(17.2, 36.8, cwp_h, 1); }
        translate([-9.4, -3, cwp_h-6]) cube([18.8, 6, 6]);                                 // bail (ends inside the walls)
    }
    translate([0, 0, cwp_hole]) rotate([90,0,0]) cylinder(d=3, h=20, center=true, $fn=24);   // cord hole in the bail
}
module rbox_c(x, y, z, r) translate([r, r, 0]) linear_extrude(z) offset(r=r, $fn=16) square([x-2*r, y-2*r]);
function E1_potpos(a) = let(f=(sin(a)+sn)/(2*sn)) [I1[0]-6.5, I1[1], I1[2]-45-cwp_hole-f*cw_drop];   // pot bottom centre (rig)
// v1.7 hardware on the static E1 parts (rig coordinates; the lever plane is y 0, the frame y 5..13):
//  - lever pivot: pin 3 x 22 (y 13..-9, pressed through the whole 8 mm frame; v17f FEA, was 3 x 20 pressed 6.9), lever spacer 1.8 (y 3.2..5.0), collar 3 (y -5.1..-8.1)
//  - wheel: pin 3 x 28 (y 13..-15, pressed 8 mm; v17f FEA, was 3 x 25 pressed 5.9: 33 MPa at the hole edge, x5), wheel spacer 2.3 (y 2.7..5.0), collar 3 (y -11.1..-14.1)
//  - idler: pin 3 x 17 (y 6.9..-10.1, pressed 8.9 mm in the 9 mm cheek; v17f FEA, was 3 x 14 in a 6 mm cheek), idler spacer 0.8 (y -2.9..-2.1), collar 3 (y -7.1..-10.1)
//  - crank: pin 3 x 14 (y 23.9..9.9, pressed 6.3 mm in the latch post arm), collar 3 (y 12.9..9.9)
module E1_hw_static() {
    translate(P) { steel_pin_y(13, -9); color("#4a5360") { on_y(3.2, 5.0) lever_spacer(1.8); on_y(-8.1, -5.1) pin_collar(3); } }
    translate(W) { steel_pin_y(13, -15); color("#4a5360") { on_y(2.7, 5.0) pin_sleeve(2.3); on_y(-14.1, -11.1) pin_collar(3); } }
    translate([I1[0], 0, I1[2]]) { steel_pin_y(I1[1]+11.9, I1[1]-5.1); color("#4a5360") { on_y(I1[1]+2.1, I1[1]+2.9) pin_sleeve(0.8); on_y(I1[1]-5.1, I1[1]-2.1) pin_collar(3); } }
    translate(H) { steel_pin_y(23.9, 9.9); color("#4a5360") on_y(9.9, 12.9) pin_collar(3); }
}
// v1.7 hardware on the lever's roller (moves with the lever): pin 3 x 22 (y -2..20, pressed 5 mm in the lever), sleeve
// d 5 x 10.9 (y 3.05..13.95) between the lever and the MR63 roller (y 14..16.5), collar d 5.5 x 3.4 (y 16.6..20.0).
// The collar and sleeve stay inside the roller's radius (3), under the crank nose.
module E1_roller_hw_at(a) let(r=[P[0]+R_local*cos(a), 0, P[2]+R_local*sin(a)]) translate(r) {
    steel_pin_y(-2, 20); color("#4a5360") { on_y(3.05, 13.95) pin_sleeve(10.9, d=5); on_y(16.6, 20.0) pin_collar(3.4, d=5.5); } }
module E1_v1(a=-52.2, ball=true) {
    color("#59646f") E1_plate();
    color("#59646f") E1_cwpost();
    color("#59a5c4") translate(P) rotate([0,-a,0]) rotate([90,0,0]) lever();
    color("#59a5c4") cup_tipped(a);
    if (ball) color("silver") translate(ball_top_seat(a)) sphere(r=ball_r, $fn=32);
    let(r=[P[0]+R_local*cos(a), 0, P[2]+R_local*sin(a)]) color("silver") translate([r[0], roller_y, r[2]]) rotate([90,0,0]) cylinder(r=roller_r, h=2.5, center=true);
    color("#d08a4a") translate(W) wheel();
    color("#d08a4a") translate(I1) idler();
    color("#d08a4a") translate(H) { crank(); trip_pin(); }
    color("#4a5360") latch_post_v1();
    color("#9aa3ad") E1_pot_at(a);
    color("white") E1_cords(a);
    E1_hw_static(); E1_roller_hw_at(a);                     // v1.7: pins, collars, spacers, sleeve
}
// the cup's swept volume (for collision checks): cup + ball at angle a
module E1_cup_at(a) translate(E(a)) { cup_asm(cup_tilt(a)); translate(about_pv(cup_seat, cup_tilt(a))) sphere(r=ball_r, $fn=24); }
module E1_lever_at(a) translate(P) rotate([0,-a,0]) rotate([90,0,0]) lever();
function E1_cupball(a) = E(a) + cup_seat;
E1_SW = SW;
function E1_info() = [P, W, I1, H, R0, cw_drop, A, SW];
// for collision checks: parts that never move, and the moving ones at lever angle a
// the rig latch post has a 4 mm tenon into the rig base; on the coaster it stands on the plywood (glued + screw)
module latch_post_v1() intersection() { translate([H[0],0,0]) latch_post(); translate([-500,-500,0]) cube(1000); }
// v5: the lever cord, the drum cord and the pot cord at lever angle a (rig coordinates; for the checks and pictures)
module E1_cords(a, r=0.5) let(s=S(a), f=(sin(a)+sn)/(2*sn)) {
    hull() { translate([W[0]+25,0,W[2]]) sphere(r, $fn=8); translate(s) sphere(r, $fn=8); }
    hull() { translate([W[0]-10,-6.5,W[2]]) sphere(r, $fn=8); translate([I1[0]+6.5,I1[1],I1[2]]) sphere(r, $fn=8); }
    hull() { translate([I1[0]-6.5,I1[1],I1[2]]) sphere(r, $fn=8); translate([I1[0]-6.5,I1[1],I1[2]-42-f*cw_drop]) sphere(r, $fn=8); } }   // v1.7: to 3 mm over the bail (was 15)
module E1_static() { E1_plate(); E1_cwpost(); translate(W) wheel(); translate(I1) idler(); translate(H) { crank(); trip_pin(); } latch_post_v1(); E1_hw_static(); }
module E1_roller_at(a) let(r=[P[0]+R_local*cos(a), 0, P[2]+R_local*sin(a)]) translate([r[0], roller_y, r[2]]) rotate([90,0,0]) cylinder(r=roller_r, h=2.5, center=true);
module E1_moving(a) { translate(P) rotate([0,-a,0]) rotate([90,0,0]) lever(); E1_cup_at(a); E1_roller_at(a); E1_roller_hw_at(a);
    E1_pot_at(a); }
module E1_cup_alone(a) cup_tipped(a);                // cup without the ball (ball-entry check)
// for the Fusion v2 export: cup pin and the counterweight pot at lever angle a (rig coordinates)
function E1_pin(a) = E(a);
module E1_pot_at(a) translate(E1_potpos(a)) cw_pot_v17();   // v1.7 (E1_potpos is above, with the pot)
// v3: the horn pin path and the cup tilt (the tip cam in coaster_v1.scad follows the pin)
function E1_hornpin(a) = horn_pin(a);
function E1_tilt(a) = cup_tilt(a);
function E1_tipspan() = tip_span;
// ball at the top in the tipped cup: on the seat, and at the open end of the floor (rig coordinates)
function E1_topseat() = ball_top_seat(SW);
function E1_topend()  = ball_top_end(SW);
module E1_static_nt() { E1_plate(); E1_cwpost(); translate(W) wheel(); translate(I1) idler(); translate(H) crank(); latch_post_v1(); E1_hw_static(); }   // without the trip pin
module E1_trip_at() translate(H) trip_pin();
function E1_cupseat() = cup_seat;  function E1_cuppv() = Pv;  function E1_flrot() = fl_rot;
module E1_cupframe() cup_frame();
module E1_cupfloor() { cup_floor(); horn_pin_part(0); color("silver") translate(Pv) rotate([90,0,0]) cylinder(d=3, h=25.2, center=true, $fn=12); }
// v5b: fixed catch ledge + side pour (elevator1_test.scad), rig coordinates
module E1_ledge() rig_ledge();
// v1.7r: the ledge's top surface z (rig coordinates) and its V line (rig x), for the EVA dot seat (coaster_v1.scad e1_ledge)
function E1_ledgez(x, y) = rledgez(x, y);
function E1_ledge_xm() = T[0]+ledge_xT;
function E1_pour() = rig_pour();
function E1_rtray() = rtray;
function E1_edge() = pour_edge();
// v5b: where the loop bolts through this plate (world X, Z): tabs R2 (ring top), R3, R4, LT (lead-in), AT (arc); the
// right bracket's lower bolt; the left bracket's two bolts
function E1_loop_bolts() = [[145, 179.6], [108.25, 169.75], [81.35, 142.85], [120, 32.6], [67.2, 44.5], [146, 163], [48, 122], [48, 138]];
function E1_ballat(a) = ball_top_seat(a);   // v5b: ball centre in the cup at lever angle a (rig coordinates)

// ---- v1.6 print poses: every E1 part in its print orientation, on the bed (z from 0), near the origin ----
// k: e1_frame | e1_foot | e1_cw_post | e1_lever | e1_cup_frame | e1_cup_floor | e1_wheel | e1_idler | e1_crank |
//    e1_latch_post | e1_cw_pot | lever_spacer | v1.7: pin_collar | roller_collar | e1_roller_sleeve | e1_wheel_spacer | e1_idler_spacer
module E1_print(k) {
    xm = (44+150)/2 - E1_ORIGIN[0];
    if (k=="e1_frame")     translate([0, -125, 13]) rotate([-90,0,0]) translate([-xm, 0, 0]) E1_frame();   // front face (rig y 13) down
    if (k=="e1_foot")      translate([-xm, -24, 0]) E1_foot();                                            // slab down, flanges up
    if (k=="e1_cw_post")   rotate([0,0,45]) translate([138, 23.5, 0]) rotate([0,-90,0]) translate([-(cwp_x0-E1_ORIGIN[0]), 0, 0]) E1_cwpost();   // on its X -2 face (v17f; was X 2), diagonal
    if (k=="e1_lever")     lever_print();
    if (k=="e1_cup_frame") cup_frame_print();
    if (k=="e1_cup_floor") cup_floor_print();
    if (k=="e1_wheel")     wheel_print();
    if (k=="e1_idler")     translate([0,0,2]) rotate([90,0,0]) idler();
    if (k=="e1_crank")     crank_print();
    // v1.7i: on its crank-side face (rig y = crank_y1 + 0.6, world Y 120.6): upright, web, arm and foot all start there.
    // The crank pin hole is standing (press, as tested); the foot bolt holes lie, teardrop and hex corner up (+y).
    if (k=="e1_latch_post") rotate([90,0,0]) translate([0, -(crank_y1+0.6), 0]) intersection() { latch_post(); translate([-500,-500,0]) cube(1000); }
    if (k=="e1_cw_pot")    cw_pot_v17();                       // v1.7: slim box, upright, no support
    if (k=="lever_spacer") lever_spacer(1.8);                  // v1.7: 1.8 mm (was 1): lever end play 0.3 mm (E1, E2)
    if (k=="pin_collar")   pin_collar(3);                      // v1.7: d 7 x 3, press 3.15 + CA: E1 pivot, wheel, idler, crank; E2 pivot, crank (6)
    if (k=="roller_collar") pin_collar(3.4, d=5.5);            // v1.7: d 5.5 x 3.4 on the roller pins (E1, E2)
    if (k=="e1_roller_sleeve") pin_sleeve(10.9, d=5);          // v1.7: d 5 x 10.9, lever to roller (E1)
    if (k=="e1_wheel_spacer") pin_sleeve(2.3);                 // v1.7: d 7 x 2.3, frame to wheel
    if (k=="e1_idler_spacer") pin_sleeve(0.8);                 // v1.7: d 7 x 0.8, cheek to idler
}
