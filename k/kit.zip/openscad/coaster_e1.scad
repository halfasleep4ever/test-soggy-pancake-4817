// Coaster v1 wrapper for Elevator 1 (Type 1). Uses the tested rig parts from elevator1_test.scad (lever, cup, latch,
// wheel, idler, counterweight pot) but places them for the full coaster:
//  - the pins sit in the front frame IN FRONT of the lever (rig: a plate behind it; behind is the ramp stack now),
//  - v1.8r: NO idler: the counterweight pot hangs straight down from the drum (rules audit v1.7, 3.j.i(1), fix (b)),
//  - no rig base, no feed risers, no top tray (the coaster has its own feed and the ladder funnel).
// Rig coordinates: lever plane y = 0, z up from the coaster base top. coaster_v1.scad places it at world (245.8, 103, 0)
// (the FRONT elevator: fed by the loop).
include <v18m_params.scad>   // v1.8: first, so the lift kit below can use the size numbers
include <elevator1_test.scad>
part = "none";
// v1: longer ball arm so the lift reaches the top ladder position (rig: 205 mm, lift 324 -> 226 mm, lift about 357)
A = 226;
E1_ORIGIN = [245.8, 103, 0];
// v1.8 (modular) LIFT KIT: the size is set in v18m_params.scad. When the coaster's top is dZ lower, Elevator 1's top is dZ
// lower at the same X: the pivot goes dZ/2 straight down, the arm gets shorter and swings less; the cup's rest pin (0, 54),
// the roller and the latch (crank pivot H) stay where they are (the roller sits r_phi off the lever line), the effort arm
// scales with the arm (same IMA). Parts that change: 12a frame (pivot, wheel pin, top), 14 lever, 17 wheel position, 13
// post (arm to the wheel pin), cords; the pot hangs dZ-dependent lower with the wheel. dZ = 0: exactly v1.7 / v1.8r.
// (OpenSCAD evaluates a re-assigned variable where it was FIRST assigned, in elevator1_test.scad, before anything here:
// so the kit values are functions of constants only)
function e1k_dz() = v18_dZtop();
function e1k_P0() = [-226*cos(52.2), 0, 54 + 226*sin(52.2)];          // v1.7 pivot
function e1k_R0() = [-26, 0, 54 + 26*tan(52.2)];                       // v1.7 roller at rest
function e1k_A()  = e1k_dz() == 0 ? 226 : norm([226*cos(52.2), 226*sin(52.2) - e1k_dz()/2]);
function e1k_SW() = e1k_dz() == 0 ? 52.2 : atan2(226*sin(52.2) - e1k_dz()/2, 226*cos(52.2));
e1k_dZ = e1k_dz();
e1k_W0z = e1k_P0()[2] - 50*sin(52.2) - 35;                            // v1.7 wheel centre height
A  = e1k_A();
SW = e1k_SW();
LS = e1k_dz() == 0 ? 50 : 50*e1k_A()/226;
R_local = e1k_dz() == 0 ? e1k_A() - 26/cos(e1k_SW()) : norm([e1k_R0()[0] + e1k_A()*cos(e1k_SW()), e1k_R0()[2] - (54 + e1k_A()*sin(e1k_SW()))]);
r_phi   = e1k_dz() == 0 ? 0 : atan2(e1k_R0()[2] - (54 + e1k_A()*sin(e1k_SW())), e1k_R0()[0] + e1k_A()*cos(e1k_SW())) + e1k_SW();
// v1.8r (rules audit v1.7, UNSURE 3.j.i(1): the idler was a fixed pulley, a possible 3rd mechanism in a Type 1 elevator):
// the idler (18), its pin, spacer and collar are gone; post 13 now only holds the wheel pin's end. The pot cord leaves the drum's
// +X side and hangs straight down (same turning sense: the cord pulls down on the +X side as it pulled up on the -X side).
// The drum is 4.5 mm longer (rig y -2.2..-14.9, groove at y -11 = world Y 92), so the pot can hang centred under it at
// world Y 78..106 (E2's pot sweep ends at Y 76, the frame's nut tips start at Y 107).
d18_gy = -11;                                               // drum cord groove (rig y)
function d18_cord() = [W[0]+10, d18_gy, W[2]];              // where the pot cord leaves the drum (rig): world (61.6, 92, 158.1)
I1 = d18_cord();                                            // (E1_info()[2]: kept for old callers; v1.8r = the cord's top point)
// v5 (2026-10-28): the v4 plate was solid (world X 44..150, Z 0..250) and hid the ramps from the front. Same plate,
// now a truss: 8 mm border, a 10 mm diagonal in each bay, a cross bar through the wheel pin and a low bar through
// the loop's lead-in tab; hubs round both pins. v5b: no loop board. The loop bolts to it (5 tabs, 2 of them through the
// two loop brackets, coaster_v1.scad loop_brackets()).
pw = 8;                                                     // member width
function e1w(p) = [p[0] + E1_ORIGIN[0], p[2]];              // rig point -> world (X, Z)
// v1.7 FEA (v3): the left loop-bracket bolts (48, 122) and (48, 138) have their 6.6 mm nut pockets 1.1 mm from the
// border's outer edge (X 44): 8.9 MPa there (x5, SF 2.2). The border gets a pad out to X 41 round both bolts (hidden
// behind the loop bracket from the front), tapering back to X 44 at Z 100 and Z 160.
module E1_plate_2d() union() {
    E1_plate_2d_v16();
    hull() { for (q=[[48, 122], [48, 138]]) translate(q) circle(r=7, $fn=28);
             for (z=[100, 160]) translate([45, z]) square([0.01, 0.01], center=true); }   // v4: long taper, no notch at X 44
}
module E1_plate_2d_v16() let(Wp=e1w(W), Pp=e1w(P), x0=44, x1=150, z1=250-e1k_dz()/2, zL=32.6, zW=Wp[1]) difference() {
    translate([x0, 0]) square([x1-x0, z1]);
    for (c=[[[x0, 0], [x1, zL]], [[x0, zL], [x1, zW]], [[x0, zW], [x1, z1]]]) let(a=c[0], b=c[1],
            lo=[a[0]+pw, a[1]+(a[1]==0 ? pw : pw/2)], hi=[b[0]-pw, b[1]-(b[1]==z1 ? pw : pw/2)])
        if (hi[1]-lo[1] > 12) offset(r=2, $fn=12) offset(delta=-2) difference() {
            translate(lo) square(hi-lo);
            if (b[1] == z1) hull() { translate(Wp) circle(d=10, $fn=16); translate(Pp + (Pp-Wp)*0.25) circle(d=10, $fn=16); }   // the W -> P diagonal
            else hull() { translate(a) circle(d=10, $fn=16); translate(b) circle(d=10, $fn=16); }
            translate(Wp) circle(r=10, $fn=32); translate(Pp) circle(r=11, $fn=32);
            translate([145, 179.6]) circle(r=8, $fn=24);   // pad for the loop top tab screw
            for (q=[[108.25, 169.75], [67.2, 44.5]]) translate(q) circle(r=8.5, $fn=24);   // v5b: pads for the loop tab bolts (on the bars)
            hull() { translate([81.35, 142.85]) circle(r=8.5, $fn=24); translate([81.35, 158]) circle(r=5, $fn=16); }   // v5b: pad + strut to the bar
            // v1.7 FEA: pads round the bolts in the left and right borders (left loop bracket bolts, foot flange bolts). The
            // 6.6 mm nut pocket left 1.1 mm of an 8 mm border: the x5 load gave 11.7 MPa there (SF 1.7).
            for (q=[[48, 17], [48, 29], [146, 14]]) translate(q) circle(r=9, $fn=24);
            hull() for (q=[[48, 122], [48, 138]]) translate(q) circle(r=9, $fn=24);     // v2: one strip X 44..57, Z 113..147
            // v1.8r FEA: the pot now pulls the wheel pin DOWN 16 mm in front of the frame (the drum is longer); the neck
            // between the bolt strip (top Z 147) and the wheel hub (bottom Z 148) took 12 MPa (SF 1.7, x5). Strip and hub joined.
            hull() { translate([48, 138]) circle(r=9, $fn=24); translate(Wp) circle(r=10, $fn=32); }
            for (q=[[x1-pw/2, z1], [Pp[0], z1]]) hull() { translate(Pp) circle(d=8, $fn=16); translate(q) circle(d=8, $fn=16); }   // P hub to the top bar
        }
}
// v1.6 (printability): the plate is two prints. The FRAME (the 8 mm truss web) prints flat, its front face (rig y +13)
// on the bed: the pivot and wheel pin holes are vertical (round), the layers carry the lever load in plane, no support.
// The FOOT (the slab in front, rig y 13..35) is its own print, bolted to the frame's bottom corners with 3 x M3x12
// through two 4 mm flanges (nuts in hex pockets in the frame's back face, like the loop bolts). The right flange stops
// at Z 21 (the loop is in front of it from Z 21.6, 3 mm from the web).
// The two v1.5 gussets behind the web are gone: they hung 8 mm over the base and touched nothing (the foot is in
// front), and flat they would start in mid air over the truss openings. The flanges now tie the web to the foot.
// v1.5 printed it in one piece upright: 48 g of support, 7 h, a floating island at Z 31 and horizontal pin holes.
E1_foot_bolts = [[48, 17], [48, 29], [146, 14]];
E1_foot_grid_bolts = [[140, 120], [50, 130]]; E1_foot_grid_pins = [[50, 120], [140, 130]];   // v1.8 grid (world X, Y)
E1_cw_grid_pin = [0, 90];                                                                   // v1.8 grid: post 13's locating pin             // world X, Z of the foot-flange bolts (frame border columns)
module E1_frame() difference() {                            // world X 44..150, Y 108..116 (rig y +5..+13), Z 0..250
    translate([0, 13, 0]) rotate([90,0,0]) linear_extrude(8) translate([-E1_ORIGIN[0], 0]) E1_plate_2d();
    for (p=[P, W]) translate([p[0], 0, p[2]]) rotate([-90,0,0]) cylinder(d=pin_press, h=40, $fn=fit_fn);   // pivot + wheel pins (3 mm steel, press; standing in the print)
    // v5b (no loop board): M3 bolts from the loop's tabs (and the two loop brackets) through the plate; an M3 nut in a
    // hex pocket 2.6 mm deep in the plate's back face (the bolt tip stays 1 mm in front of the lever's plane)
    // v1.6: the same for the 4 foot bolts
    for (q=concat(E1_loop_bolts(), E1_foot_bolts)) translate([q[0]-E1_ORIGIN[0], 0, q[1]]) {
        rotate([-90,0,0]) cylinder(d=m3_clear, h=20, $fn=16);
        translate([0, 5-0.01, 0]) rotate([-90,0,0]) rotate([0,0,30]) cylinder(d=m3_nut, h=2.61, $fn=6);
    }
}
module E1_foot() difference() {                             // world X 44..150, Y 116..138 (rig y 13..35), Z 0..8 + flanges to Z 36
    union() {
        translate([44-E1_ORIGIN[0], 13, 0]) cube([106, 22, 8]);           // foot, bolted to the base (4 x M3x14 countersunk + nuts, below)
        for (f=[[44, 36], [138, 21]]) translate([f[0]-E1_ORIGIN[0], 13, 0]) cube([12, 4, f[1]]);   // flanges on the frame's front face
    }
    // v1.7: 4 x M3x14 countersunk from under the base (world (54, 125), (136, 125), (54, 133), (136, 133)), nuts in hex
    // pockets 2.6 mm deep in the foot's top (the foot prints slab down: the holes are vertical, open pockets, no bridge)
    // v1.8 (grid, docs/modules_v1.8.md): 2 screws on grid nodes world (140, 120), (50, 130) and 2 locating pins (3 x 9 rod,
    // pin_press 5 deep, standing in the slab-down print) at (50, 120), (140, 130)  (v1.7: 4 screws at X 54 / 136, Y 125 / 133)
    for (q=E1_foot_grid_bolts) translate([q[0]-E1_ORIGIN[0], q[1]-E1_ORIGIN[1], 0]) foot_bolt(8, tip=0, td=false);
    for (q=E1_foot_grid_pins) translate([q[0]-E1_ORIGIN[0], q[1]-E1_ORIGIN[1], -0.01]) cylinder(d=pin_press, h=5, $fn=fit_fn);
    for (q=E1_foot_bolts) translate([q[0]-E1_ORIGIN[0], 15, q[1]]) tdrop_y(m3_clear, 10, up=true);   // horizontal in the print: teardrop
}
module E1_plate() { E1_frame(); E1_foot(); }                // assembled (the checks and pictures use this)
// v1.8r wheel-pin end post (13, replaces the v1.7 counterweight post). The idler is gone; the pot now hangs from the drum
// 16 mm in front of the frame, and on the frame alone (pin pressed in the frame only) that bent the frame out of its plane
// (FEA x5: SF 1.7 at the wheel hub, 11 mm at the frame's top corner). This post carries the pin's far end: the wheel
// pin (3 x 36.5) runs from the frame through the wheel into the post's arm (slip hole), so the pin is supported at both
// ends. The arm's 1 mm boss (r 4) bears on the drum flange (0.3 mm end play): it replaces the wheel collar.
// A flat plate, world Y 79.2..86.2 (7 mm), boss to Y 87.2: a channel column X -5..9 (two ribs X -5..-1 and 5..9 to
// Y 96; left of the left stop cups at X 9..36, right of the card holder at X <= -6), an arm over the pot (Z 148..168;
// pot top Z 131) to the pin at (51.6, 158), a knee gusset, and a foot flange X -5..10, Y 79.2..104, Z 0..8 with
// 2 x M3x14 countersunk from under the base at world (-1.5, 100.5) and (6.5, 100.5), nuts in pockets in the foot top.
// Prints flat on its Y 79.2 face: the pin hole stands (round), ribs and foot are walls, the bolt holes lie (teardrops up).
p13_y0 = 79.2; p13_y1 = 86.2; p13_boss = 87.2; p13_x = [-5, 9];
E1_cw_bolts = [[0, 100], [10, 100]];                        // v1.8 grid nodes (v1.8r: (-1.5, 100.5), (6.5, 100.5); v1.7: (20, 60), (20, 72))
module p13_2d() let(c=[W[0]+E1_ORIGIN[0], W[2]]) union() {  // world X, Z
    translate([p13_x[0], 0]) square([p13_x[1]-p13_x[0], 168]);                 // column
    hull() { translate([p13_x[0], 148]) square([p13_x[1]-p13_x[0], 20]); translate(c) circle(r=9, $fn=48); }   // arm to the pin hub
    polygon([[p13_x[1]-0.1, 132], [p13_x[1]-0.1, 152], [23, 152], [23, 148.5]]);   // knee gusset (overlaps the arm: no notch)
}
module E1_cwpost() translate(-E1_ORIGIN) difference() {
    union() {
        translate([0, p13_y1, 0]) rotate([90,0,0]) linear_extrude(p13_y1-p13_y0) p13_2d();
        translate([W[0]+E1_ORIGIN[0], p13_y1-0.01, W[2]]) rotate([-90,0,0]) cylinder(r=4, h=p13_boss-p13_y1+0.01, $fn=32);   // boss on the flange
        for (x=[p13_x[0], p13_x[1]-4]) translate([x, p13_y1-0.01, 0]) cube([4, 96-p13_y1+0.01, 168]);   // ribs (channel column)
        translate([p13_x[0], p13_y0, 0]) cube([19, 104-p13_y0, 8]);             // foot flange (v1.8: to X 14, for the grid node (10, 100))
    }
    translate([W[0]+E1_ORIGIN[0], 0, W[2]]) rotate([-90,0,0]) cylinder(d=pin_slip, h=200, $fn=fit_fn);   // pin hole (slip; standing in the print)
    for (q=E1_cw_bolts) translate([q[0], q[1], 0]) foot_bolt(8, tip=90);       // print: on Y 79.2, so world +Y is up: teardrop + hex corner to +Y
    translate([E1_cw_grid_pin[0], E1_cw_grid_pin[1], -0.01]) linear_extrude(5) union() { circle(d=pin_press_lying, $fn=fit_fn); rotate(45) square(pin_press_lying/2); }   // v1.8 locating pin (lying: point to +Y)
}
// v1.8r counterweight pot (21): hangs straight under the drum, its cord hole on the cord line (world X 61.6, Y 92).
// A box 70 (X) x 28 (Y) x 90.5 mm, world X 26.6..96.6, Y 78..106. Top at rest Z 131.0 (2.1 mm under the wheel rim, which
// is the lowest thing over it); bottom Z 40.5 at rest, Z 8.9 at the top of the lift (1.3 mm over the gap slide's
// block at X 67.6..75.6, Z 7.6). Inside 66.8 x 24.8 x 88.5 = 147 cm3: about 740 g of steel nuts (5.05 g/cm3, as v1.7).
// Mass: docs/coaster_v1.8_rules.md (cad/v18r_e1_counterweight.py): the lever (14.8 g, CoM 70.5 mm out on the cup arm)
// was left out of the v1.7 sum; the true balance is 558 g hanging, so v1.7's 595 g had only 1.06 x. v1.8r: 728 g
// hanging (pot 36 g, slicer, + about 692 g of steel, 94 % full) = 1.30 x: 170 g over balance (simulator model: 155 g).
// The bail (8 tall, 6 wide) spans the short side (Y) at the top, flush with the rim; the 3 mm cord hole runs along X.
// Prints upright, no support (the bail is a 24.8 mm bridge between the long walls).
cw18 = [70, 28, 90.5]; cw18_top = 131.0 + (W[2] - (e1k_P0()[2] - 50*sin(52.2) - 35)); cw18_bail = [6, 8];   // cw18_top: v1.8 kit, follows the wheel (v1.8 fix 2026-10-30: cw18_bail had slipped into this comment, so the bail and its cord hole were missing)
cw18_hole = cw18[2] - cw18_bail[1]/2;
module cw_pot_v18() difference() {
    union() {
        difference() { translate([-cw18[0]/2, -cw18[1]/2, 0]) rbox_c(cw18[0], cw18[1], cw18[2], 2);
                       translate([-cw18[0]/2+1.6, -cw18[1]/2+1.6, 2]) rbox_c(cw18[0]-3.2, cw18[1]-3.2, cw18[2], 1); }
        translate([-cw18_bail[0]/2, -cw18[1]/2+0.8, cw18[2]-cw18_bail[1]]) cube([cw18_bail[0], cw18[1]-1.6, cw18_bail[1]]);   // bail (ends inside the walls)
    }
    translate([0, 0, cw18_hole]) rotate([0,90,0]) cylinder(d=3, h=20, center=true, $fn=24);   // cord hole in the bail (along X)
}
module rbox_c(x, y, z, r) translate([r, r, 0]) linear_extrude(z) offset(r=r, $fn=16) square([x-2*r, y-2*r]);
function E1_potpos(a) = let(f=(sin(a)+sn)/(2*sn)) [d18_cord()[0], d18_gy, cw18_top-cw18[2]-f*cw_drop];   // pot bottom centre (rig)
// v1.8r wheel and axle (17): the rig wheel (disc r 25 at y -2.5..2.5, drum r 10) with the drum 4.5 mm longer (y -2.2..
// -14.9) and its cord groove at y -11 (rig wheel: -6.5), flange r 12.5 at y -14.3..-15.5, the 2nd MR63 at the flange end.
// The same radii: wheel-and-axle IMA 10 / 25 = 0.40. A 1.6 mm tie hole through the flange into the groove (cord end knot
// behind the flange). Prints disc face down, drum up, no support.
module wheel_v18() {
    difference() {
        union() {
            rotate([90,0,0]) cylinder(r=25, h=5, center=true, $fn=96);
            translate([0,-8.55,0]) rotate([90,0,0]) cylinder(r=10, h=12.7, center=true, $fn=64);   // drum y -2.2..-14.9
            translate([0,-14.9,0]) rotate([90,0,0]) cylinder(r=12.5, h=1.2, center=true, $fn=64); // flange y -14.3..-15.5
        }
        rotate([90,0,0]) rotate_extrude($fn=96) translate([25,0]) circle(r=1.1);                 // lever cord groove on the rim
        translate([0,d18_gy,0]) rotate([90,0,0]) rotate_extrude($fn=64) translate([10,0]) circle(r=1.1);   // pot cord groove
        rotate([90,0,0]) cylinder(d=4.5, h=40, center=true);
        for (y=[2.5+0.01, -15.5+brg_h-0.01]) translate([0,y,0]) rotate([90,0,0]) brg_pocket();
        for (a=[0,120,240]) rotate([0,a,0]) translate([16,0,0]) rotate([90,0,0]) cylinder(d=1.6, h=8, center=true); // cord tie holes
        for (a=[60,180,300]) rotate([0,a,0]) translate([16,0,0]) rotate([90,0,0]) cylinder(d=10, h=8, center=true); // lighten
        translate([0,-13.3,8.6]) rotate([90,0,0]) cylinder(d=1.6, h=5, center=true, $fn=12);   // drum cord tie hole (y -15.8..-10.8, r 8.6: opens into the groove)
    }
}
// v1.7 hardware on the static E1 parts (rig coordinates; the lever plane is y 0, the frame y 5..13):
//  - lever pivot: pin 3 x 22 (y 13..-9, pressed through the whole 8 mm frame; v17f FEA, was 3 x 20 pressed 6.9), lever spacer 1.8 (y 3.2..5.0), collar 3 (y -5.1..-8.1)
//  - wheel: pin 3 x 36.5 (y 13..-23.5, pressed 8 mm in the frame, slip 6.2 mm in post 13's arm; v1.8r, was 3 x 28), wheel spacer 2.3 (y 2.7..5.0),
//    no collar (post 13's boss, y -15.8..-16.8, holds the wheel: end play 0.3)
//  - (v1.8r: no idler, no idler pin, spacer or collar)
//  - crank: pin 3 x 14 (y 23.9..9.9, pressed 6.3 mm in the latch post arm), collar 3 (y 12.9..9.9)
module E1_hw_static() {
    translate(P) { steel_pin_y(13, -9); color("#4a5360") { on_y(3.2, 5.0) lever_spacer(1.8); on_y(-8.1, -5.1) pin_collar(3); } }
    translate(W) { steel_pin_y(13, -23.5); color("#4a5360") on_y(2.7, 5.0) pin_sleeve(2.3); }   // v1.8r: pin into post 13's arm, no collar
    translate(H) { steel_pin_y(23.9, 9.9); color("#4a5360") on_y(9.9, 12.9) pin_collar(3); }
}
// v1.7 hardware on the lever's roller (moves with the lever): pin 3 x 22 (y -2..20, pressed 5 mm in the lever), sleeve
// d 5 x 10.9 (y 3.05..13.95) between the lever and the MR63 roller (y 14..16.5), collar d 5.5 x 3.4 (y 16.6..20.0).
// The collar and sleeve stay inside the roller's radius (3), under the crank nose.
module E1_roller_hw_at(a) let(r=[P[0]+R_local*cos(a+r_phi), 0, P[2]+R_local*sin(a+r_phi)]) translate(r) {
    steel_pin_y(-2, 20); color("#4a5360") { on_y(3.05, 13.95) pin_sleeve(10.9, d=5); on_y(16.6, 20.0) pin_collar(3.4, d=5.5); } }
module E1_v1(a=-52.2, ball=true) {
    color("#59646f") E1_plate();
    color("#59a5c4") translate(P) rotate([0,-a,0]) rotate([90,0,0]) lever();
    color("#59a5c4") cup_tipped(a);
    if (ball) color("silver") translate(ball_top_seat(a)) sphere(r=ball_r, $fn=32);
    let(r=[P[0]+R_local*cos(a+r_phi), 0, P[2]+R_local*sin(a+r_phi)]) color("silver") translate([r[0], roller_y, r[2]]) rotate([90,0,0]) cylinder(r=roller_r, h=2.5, center=true);
    color("#d08a4a") translate(W) wheel_v18();
    color("#59646f") E1_cwpost();
    color("#d08a4a") translate(H) { crank(); trip_pin(); }
    color("#4a5360") latch_post_v1();
    color("#9aa3ad") E1_pot_at(a);
    color("white") E1_cords(a);
    E1_hw_static(); E1_roller_hw_at(a);                     // v1.7: pins, collars, spacers, sleeve
}
// the cup's swept volume (for collision checks): cup + ball at angle a
module E1_cup_at(a) translate(E(a)) { cup_asm(cup_tilt(a)); translate(about_pv(cup_seat, cup_tilt(a))) sphere(r=ball_r, $fn=24); }
module E1_lever_at(a) translate(P) rotate([0,-a,0]) rotate([90,0,0]) lever();
function E1_cupball(a) = E(a) + cup_seat;
E1_SW = SW;
function E1_info() = [P, W, I1, H, R0, cw_drop, A, SW];
// for collision checks: parts that never move, and the moving ones at lever angle a
// the rig latch post has a 4 mm tenon into the rig base; on the coaster it stands on the plywood (glued + screw)
module latch_post_v1() intersection() { translate([H[0],0,0]) latch_post(); translate([-500,-500,0]) cube(1000); }
// v5: the lever cord, the drum cord and the pot cord at lever angle a (rig coordinates; for the checks and pictures)
module E1_cords(a, r=0.5) let(s=S(a), f=(sin(a)+sn)/(2*sn)) {
    hull() { translate([W[0]+25,0,W[2]]) sphere(r, $fn=8); translate(s) sphere(r, $fn=8); }
    // v1.8r: the pot cord straight down from the drum's +X side to 3 mm over the bail
    hull() { translate(d18_cord()) sphere(r, $fn=8); translate([d18_cord()[0], d18_gy, cw18_top+3-f*cw_drop]) sphere(r, $fn=8); } }
module E1_static() { E1_plate(); E1_cwpost(); translate(W) wheel_v18(); translate(H) { crank(); trip_pin(); } latch_post_v1(); E1_hw_static(); }   // v1.8r: post 13 = wheel-pin end post, no idler
module E1_roller_at(a) let(r=[P[0]+R_local*cos(a+r_phi), 0, P[2]+R_local*sin(a+r_phi)]) translate([r[0], roller_y, r[2]]) rotate([90,0,0]) cylinder(r=roller_r, h=2.5, center=true);
module E1_moving(a) { translate(P) rotate([0,-a,0]) rotate([90,0,0]) lever(); E1_cup_at(a); E1_roller_at(a); E1_roller_hw_at(a);
    E1_pot_at(a); }
module E1_cup_alone(a) cup_tipped(a);                // cup without the ball (ball-entry check)
// for the Fusion v2 export: cup pin and the counterweight pot at lever angle a (rig coordinates)
function E1_pin(a) = E(a);
module E1_pot_at(a) translate(E1_potpos(a)) cw_pot_v18();   // v1.8r (E1_potpos is above, with the pot)
// v3: the horn pin path and the cup tilt (the tip cam in coaster_v1.scad follows the pin)
function E1_hornpin(a) = horn_pin(a);
function E1_tilt(a) = cup_tilt(a);
function E1_tipspan() = tip_span;
// ball at the top in the tipped cup: on the seat, and at the open end of the floor (rig coordinates)
function E1_topseat() = ball_top_seat(SW);
function E1_topend()  = ball_top_end(SW);
module E1_static_nt() { E1_plate(); E1_cwpost(); translate(W) wheel_v18(); translate(H) crank(); latch_post_v1(); E1_hw_static(); }   // without the trip pin
module E1_trip_at() translate(H) trip_pin();
function E1_cupseat() = cup_seat;  function E1_cuppv() = Pv;  function E1_flrot() = fl_rot;
module E1_cupframe() cup_frame();
module E1_cupfloor() { cup_floor(); horn_pin_part(0); color("silver") translate(Pv) rotate([90,0,0]) cylinder(d=3, h=25.2, center=true, $fn=12); }
// v5b: fixed catch ledge + side pour (elevator1_test.scad), rig coordinates
module E1_ledge() rig_ledge();
// v1.7r: the ledge's top surface z (rig coordinates) and its V line (rig x), for the EVA dot seat (coaster_v1.scad e1_ledge)
function E1_ledgez(x, y) = rledgez(x, y);
function E1_ledge_xm() = T[0]+ledge_xT;
function E1_pour() = rig_pour();
function E1_rtray() = rtray;
function E1_edge() = pour_edge();
// v5b: where the loop bolts through this plate (world X, Z): tabs R2 (ring top), R3, R4, LT (lead-in), AT (arc); the
// right bracket's lower bolt; the left bracket's two bolts
function E1_loop_bolts() = [[145, 179.6], [108.25, 169.75], [81.35, 142.85], [120, 32.6], [67.2, 44.5], [146, 163], [48, 122], [48, 138]];
function E1_ballat(a) = ball_top_seat(a);   // v5b: ball centre in the cup at lever angle a (rig coordinates)

// ---- v1.6 print poses: every E1 part in its print orientation, on the bed (z from 0), near the origin ----
// k: e1_frame | e1_foot | e1_lever | e1_cup_frame | e1_cup_floor | e1_wheel | e1_crank |
//    e1_latch_post | e1_cw_pot | lever_spacer | v1.7: pin_collar | roller_collar | e1_roller_sleeve | e1_wheel_spacer
// v1.8r: e1_idler (18) and e1_idler_spacer are gone; e1_cw_post (13, now the wheel-pin end post), e1_wheel and e1_cw_pot are new
module E1_print(k) {
    xm = (44+150)/2 - E1_ORIGIN[0];
    if (k=="e1_frame")     translate([0, -125, 13]) rotate([-90,0,0]) translate([-xm, 0, 0]) E1_frame();   // front face (rig y 13) down
    if (k=="e1_cw_post")   translate([0, 0, -(p13_y0-E1_ORIGIN[1])]) rotate([90,0,0]) translate([-(23-E1_ORIGIN[0]), 0, -84]) E1_cwpost();   // v1.8r: flat on its Y 79.2 face
    if (k=="e1_foot")      translate([-xm, -24, 0]) E1_foot();                                            // slab down, flanges up
    if (k=="e1_lever")     lever_print();
    if (k=="e1_cup_frame") cup_frame_print();
    if (k=="e1_cup_floor") cup_floor_print();
    if (k=="e1_wheel")     translate([0,0,2.5]) rotate([-90,0,0]) wheel_v18();   // v1.8r: disc face down, the longer drum up
    if (k=="e1_crank")     crank_print();
    // v1.7i: on its crank-side face (rig y = crank_y1 + 0.6, world Y 120.6): upright, web, arm and foot all start there.
    // The crank pin hole is standing (press, as tested); the foot bolt holes lie, teardrop and hex corner up (+y).
    if (k=="e1_latch_post") rotate([90,0,0]) translate([0, -(crank_y1+0.6), 0]) intersection() { latch_post(); translate([-500,-500,0]) cube(1000); }
    if (k=="e1_cw_pot")    cw_pot_v18();                       // v1.8r: 70 x 28 x 90.5 box, upright, no support
    if (k=="lever_spacer") lever_spacer(1.8);                  // v1.7: 1.8 mm (was 1): lever end play 0.3 mm (E1, E2)
    if (k=="pin_collar")   pin_collar(3);                      // v1.7: d 7 x 3, press 3.15 + CA: E1 pivot, crank; E2 pivot, crank (v1.8r: 4: no idler, the wheel's is post 13's boss)
    if (k=="roller_collar") pin_collar(3.4, d=5.5);            // v1.7: d 5.5 x 3.4 on the roller pins (E1, E2)
    if (k=="e1_roller_sleeve") pin_sleeve(10.9, d=5);          // v1.7: d 5 x 10.9, lever to roller (E1)
    if (k=="e1_wheel_spacer") pin_sleeve(2.3);                 // v1.7: d 7 x 2.3, frame to wheel
}
