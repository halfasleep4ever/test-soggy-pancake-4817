// Coaster v1 wrapper for Elevator 1 (Type 1). Uses the tested rig parts from elevator1_test.scad (lever, cup, latch,
// wheel, idler, counterweight pot) but places them for the full coaster:
//  - the pin plate stands IN FRONT of the lever (rig: behind it; behind is the ramp stack now),
//  - the idler and counterweight move to the front-left corner (behind the loop chute, in front of the stack),
//  - no rig base, no feed risers, no top tray (the coaster has its own feed and the ladder funnel).
// Rig coordinates: lever plane y = 0, z up from the coaster base top. coaster_v1.scad places it at world (245.8, 103, 0)
// (the FRONT elevator: fed by the loop).
include <elevator1_test.scad>
part = "none";
// v1: longer ball arm so the lift reaches the top ladder position (rig: 205 mm, lift 324 -> 226 mm, lift about 357)
A = 226;
E1_ORIGIN = [245.8, 103, 0];
I1 = [10 - E1_ORIGIN[0], 98 - E1_ORIGIN[1], 262];             // idler (world X 10, Y 98, Z 262): 41.6 mm left of the wheel
                                                            // centre, as in the rig, so the pot (r 20) hangs clear of the wheel (r 25)
module E1_plate() difference() {                            // world X 44..150, Y 108..116 (rig y +5..+13), Z 0..250
    union() {
        translate([44-E1_ORIGIN[0], 5, 0]) cube([106, 8, 250]);
        translate([44-E1_ORIGIN[0], 5, 0]) cube([106, 30, 8]);           // foot, screwed to the base (4 x M3 into inserts / wood)
        for (x=[60, 140]-[E1_ORIGIN[0],E1_ORIGIN[0]]) translate([x-3, 5, 8]) rotate([90,0,90]) linear_extrude(6) polygon([[0,0],[-20,0],[0,60]]);  // gussets BEHIND the plate (in front is the loop board)
    }
    for (p=[P, W]) translate([p[0], 0, p[2]]) rotate([-90,0,0]) cylinder(d=pin_hole-0.15, h=40);   // pivot + wheel pins (3 mm steel)
    for (x=[54, 136]-[E1_ORIGIN[0],E1_ORIGIN[0]], y=[22, 30]) translate([x, y, -1]) cylinder(d=m3_clear, h=10, $fn=20);
    translate([60-E1_ORIGIN[0], 13.4, 60]) rotate([90,0,0]) linear_extrude(1) text("ELEVATOR 1  TYPE 1", size=6);   // label (behind the loop board: the visible one is on the lever)
}
module E1_cwpost() difference() {                           // world X 2..14, Y 55..61 post, arm forward over the pot to the idler
    yb = 55 - E1_ORIGIN[1];
    union() {
        translate([2-E1_ORIGIN[0], yb, 0]) cube([12, 6, 276]);
        translate([2-E1_ORIGIN[0], yb, 0]) cube([12, 22, 8]);               // foot
        translate([2-E1_ORIGIN[0], yb, 268]) cube([12, I1[1]-yb+6, 8]);    // arm over the pot
        translate([I1[0]-5, I1[1]+3, 252]) cube([10, 3, 24]);             // idler cheek (pin from here)
    }
    translate([I1[0], I1[1]-10, I1[2]]) rotate([-90,0,0]) cylinder(d=pin_hole-0.15, h=20);
}
module E1_v1(a=-52.2, ball=true) {
    color("#59646f") E1_plate();
    color("#59646f") E1_cwpost();
    color("#59a5c4") translate(P) rotate([0,-a,0]) rotate([90,0,0]) lever();
    color("#59a5c4") cup_tipped(a);
    if (ball) color("silver") translate(ball_top_seat(a)) sphere(r=ball_r, $fn=32);
    let(r=[P[0]+R_local*cos(a), 0, P[2]+R_local*sin(a)]) color("silver") translate([r[0], roller_y, r[2]]) rotate([90,0,0]) cylinder(r=roller_r, h=2.5, center=true);
    color("#d08a4a") translate(W) wheel();
    color("#d08a4a") translate(I1) idler();
    color("#d08a4a") translate(H) { crank(); trip_pin(); }
    color("#4a5360") latch_post_v1();
    f = (sin(a)+sn)/(2*sn);
    color("#9aa3ad") translate([I1[0]-6.5, I1[1], I1[2]-30-122-f*cw_drop]) cw_pot();
    s = S(a);
    color("white") { hull() { translate([W[0]+25,0,W[2]]) sphere(0.5); translate(s) sphere(0.5); }
                     hull() { translate([W[0]-10,-6.5,W[2]]) sphere(0.5); translate([I1[0]+6.5,I1[1],I1[2]]) sphere(0.5); }
                     hull() { translate([I1[0]-6.5,I1[1],I1[2]]) sphere(0.5); translate([I1[0]-6.5,I1[1],I1[2]-30-f*cw_drop]) sphere(0.5); } }
}
// the cup's swept volume (for collision checks): cup + ball at angle a
module E1_cup_at(a) translate(E(a)) { cup_asm(cup_tilt(a)); translate(about_pv(cup_seat, cup_tilt(a))) sphere(r=ball_r, $fn=24); }
module E1_lever_at(a) translate(P) rotate([0,-a,0]) rotate([90,0,0]) lever();
function E1_cupball(a) = E(a) + cup_seat;
E1_SW = SW;
function E1_info() = [P, W, I1, H, R0, cw_drop, A, SW];
// for collision checks: parts that never move, and the moving ones at lever angle a
// the rig latch post has a 4 mm tenon into the rig base; on the coaster it stands on the plywood (glued + screw)
module latch_post_v1() intersection() { translate([H[0],0,0]) latch_post(); translate([-500,-500,0]) cube(1000); }
module E1_static() { E1_plate(); E1_cwpost(); translate(W) wheel(); translate(I1) idler(); translate(H) { crank(); trip_pin(); } latch_post_v1(); }
module E1_roller_at(a) let(r=[P[0]+R_local*cos(a), 0, P[2]+R_local*sin(a)]) translate([r[0], roller_y, r[2]]) rotate([90,0,0]) cylinder(r=roller_r, h=2.5, center=true);
module E1_moving(a) { translate(P) rotate([0,-a,0]) rotate([90,0,0]) lever(); E1_cup_at(a); E1_roller_at(a);
    let(f=(sin(a)+sn)/(2*sn)) translate([I1[0]-6.5, I1[1], I1[2]-30-122-f*cw_drop]) cw_pot(); }
module E1_cup_alone(a) cup_tipped(a);                // cup without the ball (ball-entry check)
// for the Fusion v2 export: cup pin and the counterweight pot at lever angle a (rig coordinates)
function E1_pin(a) = E(a);
function E1_potpos(a) = let(f=(sin(a)+sn)/(2*sn)) [I1[0]-6.5, I1[1], I1[2]-30-122-f*cw_drop];
module E1_pot_at(a) translate(E1_potpos(a)) cw_pot();
// v3: the horn pin path and the cup tilt (the tip cam in coaster_v1.scad follows the pin)
function E1_hornpin(a) = horn_pin(a);
function E1_tilt(a) = cup_tilt(a);
function E1_tipspan() = tip_span;
// ball at the top in the tipped cup: on the seat, and at the open end of the floor (rig coordinates)
function E1_topseat() = ball_top_seat(SW);
function E1_topend()  = ball_top_end(SW);
module E1_static_nt() { E1_plate(); E1_cwpost(); translate(W) wheel(); translate(I1) idler(); translate(H) crank(); latch_post_v1(); }   // without the trip pin
module E1_trip_at() translate(H) trip_pin();
function E1_cupseat() = cup_seat;  function E1_cuppv() = Pv;  function E1_flrot() = fl_rot;
module E1_cupframe() cup_frame();
module E1_cupfloor() { cup_floor(); horn_pin_part(0); color("silver") translate(Pv) rotate([90,0,0]) cylinder(d=3, h=25.2, center=true, $fn=12); }
