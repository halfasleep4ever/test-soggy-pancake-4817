// v1.8 modular: the GRID BASE drawings and tools (docs/modules_v1.8.md section 3, docs/coaster_v1.8_modular.md).
// The base is 6 mm birch, sawn and drilled by hand (the Falcon 5W cannot cut 6 mm birch: it can mark it).
//  part = "svg_drill"  : 1:1 drawing (2D): outline + every hole to drill NOW (module screws, locating pins, frozen pattern
//                        holes, levelling wheels, panel screws) as full circles
//  part = "svg_marks"  : 1:1 drawing (2D): a cross at every grid node (drill later, when a module moves there) and a ring
//                        round every hole that gets a countersink from below. Engrave it on the top face (Falcon), or print it.
//  part = "template_L" / "template_R" : printed drill templates (2.4 mm PETG): clamp on the base, drill through.
//                        L registers on the base's back edge and left end; R on the back edge and 2 pegs in the column
//                        X 130 holes drilled with L (so a sawing error in the length does not move the right half's holes).
//  part = "strip"      : drill-guide test strip: guide holes for 3.0 / 3.2 / 3.3 / 3.5 mm drills. Drill a scrap of the same
//                        birch through it, then test: an M3 screw passes, the 3 mm rod slides in with no play you can feel.
//                        Write the chosen drill in coaster_v1.scad (v18_grid_hole).
// Every position comes from coaster_v1.scad (v18_grid(), v18_used(), v18_pins(), v18_pattern_holes(), LEV, v17_wood).
include <coaster_v1.scad>
part = "svg_drill";
tpl_t = 2.4;                 // template plate thickness
tpl_lip = 5;                 // registration lips (down over the base edge)
tpl_g = 3.35;                // template guide hole for a 3.2 mm drill (PETG shrinks: test with the strip)
tpl_split = [140, 125];      // L covers X <= 140, R covers X >= 125 (overlap column X 130: the R pegs)
tpl_pegs = [[130, 40], [130, 110]];

function v18_drill_now() = concat(v18_used(), v18_pins(), v18_pattern_holes(), LEV);
module v18_outline2d() translate([Lx0, Wy0]) square([L-Lx0, Wy1-Wy0]);
module v18_drill2d() difference() {
    v18_outline2d();
    for (q=concat(v18_used(), v18_pins())) translate(q) circle(d=v18_grid_hole, $fn=24);
    for (q=v18_pattern_holes()) translate(q) circle(d=m3_clear, $fn=24);
    for (q=LEV) translate(q) circle(d=m3_clear, $fn=24);
}
module v18_marks2d() {
    difference() { v18_outline2d(); offset(-0.3) v18_outline2d(); }
    for (q=v18_grid()) translate(q) { square([4, 0.3], center=true); square([0.3, 4], center=true); }
    for (q=concat(v18_used(), [for (h=v18_pattern_holes()) if (!v18_near(h, concat(pg_guide_xy(), [[41, 92.5], [103, 92.5]]), 0.01)) h]))
        translate(q) difference() { circle(d=7.3, $fn=48); circle(d=6.7, $fn=48); }        // countersink from below
    for (q=LEV) translate(q) difference() { circle(d=20.3, $fn=64); circle(d=19.7, $fn=64); } // counterbore d 20 x 3 from below
    translate([Lx0+8, Wy1-10]) text("v1.8 GRID 10 mm  TOP FACE  THIS EDGE = FRONT (Y 161.5)", size=4, font="Liberation Sans:style=Bold");
}
// drill template half: plate over the base, guide holes at every grid node and every hole to drill now
module v18_template(side) let(x0 = side=="L" ? Lx0-2 : tpl_split[1], x1 = side=="L" ? tpl_split[0] : L+2,
        inside = function(q) q[0] >= x0+3 && q[0] <= x1-3) difference() {
    union() {
        translate([x0, Wy0-2, 0]) cube([x1-x0, Wy1-Wy0+2, tpl_t]);
        translate([x0, Wy0-2, -tpl_lip]) cube([x1-x0, 2, tpl_lip+tpl_t]);                                       // back-edge lip
        if (side=="L") translate([Lx0-2, Wy0-2, -tpl_lip]) cube([2, Wy1-Wy0+2, tpl_lip+tpl_t]);                 // left-end lip
        if (side=="R") for (q=tpl_pegs) translate([q[0], q[1], -4]) cylinder(d=3.1, h=4.01, $fn=fit_fn);       // pegs into the L-drilled holes
    }
    for (q=v18_grid()) if (inside(q) && !(side=="R" && v18_near(q, tpl_pegs, 0.01))) translate([q[0], q[1], -1]) cylinder(d=tpl_g, h=tpl_t+2, $fn=fit_fn);
    for (q=concat(v18_pattern_holes(), LEV)) if (inside(q)) translate([q[0], q[1], -1]) cylinder(d=3.55, h=tpl_t+2, $fn=fit_fn);
    // window round the levelling counterbores (drilled from below with a 20 mm Forstner bit: centre hole only here)
    // labels: X / Y every 50 mm (raised 0.6 would be in the way of the drill: engraved 0.6)
    for (x=[ceil(x0/50)*50 : 50 : x1-10]) translate([x+1.5, Wy1-8, tpl_t-0.6]) linear_extrude(1) text(str(x), size=3.5, font="Liberation Sans:style=Bold");
    translate([x0+6, Wy0+20, tpl_t-0.6]) linear_extrude(1) text(str("v1.8 GRID ", side, side=="R" ? "  pegs in X 130" : "  left end"), size=4, font="Liberation Sans:style=Bold");
}
module v18_strip() difference() {
    cube([60, 16, 6]);
    for (i=[0:3]) let(d=[3.15, 3.35, 3.45, 3.65][i]) {
        translate([8+i*14, 6, -1]) cylinder(d=d, h=8, $fn=fit_fn);
        translate([8+i*14, 12.5, 6-0.6]) linear_extrude(1) text(str([3.0, 3.2, 3.3, 3.5][i]), size=3, halign="center", font="Liberation Sans:style=Bold");
    }
}
if (part=="svg_drill")  v18_drill2d();
if (part=="svg_marks")  v18_marks2d();
if (part=="template_L") v18_template("L");
if (part=="template_R") v18_template("R");
if (part=="strip")      v18_strip();
