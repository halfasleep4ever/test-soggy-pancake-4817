// v1.6 stack-side printed parts, one at a time, in their PRINT POSE (docs/coaster_v1.6_stack.md).
// pk   = part key (list in v16_build_stack.py, with numbers, copies and support plan)
// mode = "print": the part turned to its print pose (v16_build_stack.py then puts it on the bed centre)
//        "world": the part where it sits in the coaster at rest (inst = which copy)
// The print pose is the transform in pose(): the exporter does not turn anything itself.
// Steel, pads, felt and cords are drawn in silver / #2b2b2b / #2e343d / white: the builder exports from a copy of the
// .scad files with those colours switched off (as pack_v1.5/scad/build_stl.py).
include <coaster_v1.scad>
part = "none";
pk = "none"; inst = 0; mode = "print";
PR = mode == "print";

// rotate the vector n onto +Z (the plane with normal n becomes the bed)
module up(nv) let(u=nv/norm(nv), ax=cross(u, [0,0,1])) if (norm(ax) < 1e-9) children(); else rotate(a=acos(u[2]), v=ax) children();
module pose(r) if (PR) rotate(r) children(); else children();
module half(entry) translate([entry ? -10 : 100, -100, -10]) cube([110, 200, 100]);
module cup_local(right=true) stopcup(0.5, "STOP", false, test_cup_in - 2.5, side_in=false, zcut=15, x_in=true, lo_walls=true, wdrop=cup_wdrop(right));   // v1.7r: the left cups' front wall 2.5 mm lower
module e2feed_part() difference() { trough_chain([for (k=[2:len(E2feed)-1]) E2feed[k]], open_start=true, open_end=true, pads=[2]); trip_slot(E2O); }
module finish_part() { finish_track_body(); finish_feet(); }   // v1.8: the feet as drawn in the coaster (grid ears, pin boss)
module slide_spacer(k) intersection() { gd_static(); translate([pg_guide[k], pg_guideY, -0.01]) difference() { cylinder(d=7.5, h=pg_z[0]+0.01, $fn=24); translate([0,0,-1]) cylinder(d=3.36, h=5, $fn=16); } }

// ---- 01..05 ramp ends and stop cups: rig pose (as v1.5) ----
if (pk=="spine_end_entry")   if (PR) intersection() { stack_spine(); half(true); }  else at_ramp(inst) intersection() { stack_spine(); half(true); }
if (pk=="spine_end_exit")    if (PR) intersection() { stack_spine(); half(false); } else at_ramp(inst) intersection() { stack_spine(); half(false); }
if (pk=="carrier_end_entry") if (PR) intersection() { stack_carrier(); half(true); }  else at_ramp(inst) translate([0, -rod_cc(gap), 4]) intersection() { stack_carrier(); half(true); }
if (pk=="carrier_end_exit")  if (PR) intersection() { stack_carrier(); half(false); } else at_ramp(inst) translate([0, -rod_cc(gap), 4]) intersection() { stack_carrier(); half(false); }
// v1.7: two cup types (the lug sits on the front post's +X face for the right cups, -X face for the left cups)
if (pk=="stop_cup_R")        if (PR) v18_cup_part(true);  else uturn(2*inst);      // v1.8 (J10): pin + screw holes
if (pk=="stop_cup_L")        if (PR) v18_cup_part(false); else uturn(2*inst+1);
// ---- 06 stack frame: 8 pieces, all flat, tabs up ----
if (pk=="frame_ladder_back")  pose([90,0,0])  frame_ladder(0);
if (pk=="frame_ladder_front") pose([-90,0,0]) frame_ladder(1);
if (pk=="frame_post_back_L")  pose([90,0,0])  frame_post_lo(0, 0);
if (pk=="frame_post_back_R")  pose([90,0,0])  frame_post_lo(0, 1);
if (pk=="frame_post_front_L") pose([-90,0,0]) frame_post_lo(1, 0);
if (pk=="frame_post_front_R") pose([-90,0,0]) frame_post_lo(1, 1);
if (pk=="front_strip_L")      pose([-90,0,0]) fr_strip(0);   // v1.7: doubler strip on the front ladder's left post, flat
if (pk=="front_strip_R")      pose([-90,0,0]) fr_strip(1);
if (pk=="frame_bar_L")        pose([180,0,0]) frame_bar(0);
if (pk=="frame_bar_R")        pose([180,0,0]) frame_bar(1);
// ---- 07 / 08 comb frames: 2 pieces each, flat on the face away from the arms ----
if (pk=="comb_back_lo")  pose([90,0,0])  gd_frame_lo(0);
if (pk=="comb_back_hi")  pose([90,0,0])  gd_frame_hi(0);
if (pk=="comb_front_lo") pose([-90,0,0]) gd_frame_lo(1);
if (pk=="comb_front_hi") pose([-90,0,0]) gd_frame_hi(1);
// ---- 09..11 gap slide, peg plate, spacers: flat as drawn ----
if (pk=="gap_slide")    if (PR) pg_slide_s(0); else pg_slide();
if (pk=="peg_plate")    intersection() { gd_static(); translate([30, 60, -0.01]) cube([90, 40, 2.02]); }
if (pk=="slide_spacer") slide_spacer(inst);
// ---- 22 E1 feed: on its end ----
if (pk=="e1_feed") pose([0,-90,0]) e1feed();
// ---- 23 / 35 cages: on the strip's outer face (left: the mirrored part, so its strip face is -X); left top ring flat ----
if (pk=="cage_left")         if (PR) rotate([0,-90,0]) mirror([1,0,0]) cage_print(1); else at_ch(1) cage_print(1);
if (pk=="cage_left_topring") if (PR) mirror([1,0,0]) cage_topring(1); else at_ch(1) cage_topring(1);
if (pk=="cage_right")        if (PR) rotate([0,90,0]) cage_print(0); else at_ch(0) cage_print(0);
// ---- 24 / 36 carriages: v1.7 (index-pin ear): on the -y wall (the deflector and the lip stand up; tree support) ----
if (pk=="carriage_left")  if (PR) rotate([90,0,0]) mirror([1,0,0]) carriage_body(1); else at_ch(1) translate([0,0,cupEntryZ(k1)]) carriage_body(1);
if (pk=="carriage_right") if (PR) rotate([90,0,0]) carriage_body(0);                 else at_ch(0) translate([0,0,cupEntryZ(k2)]) carriage_body(0);
// ---- 25 E1 tray: 2 pieces, channel up, the keel bottom plane on the bed ----
tr_bA = (379.4-375.6)/130;                                 // A: keel bottom along the front run (X 100..230)
if (pk=="tray_e1_a") if (PR) up([-tr_bA, 0, 1]) tray_e1_a(); else tray_e1_a();
if (pk=="tray_e1_b") if (PR) up([-tr_bB[0], -tr_bB[1], 1]) tray_e1_b(); else tray_e1_b();
// ---- 37 E2 funnel ----
if (pk=="e2_funnel") pose([0,90,0]) e2_funnel();
// ---- 38 E2 top bracket: 3 pieces; 39 tip cams ----
if (pk=="e2_bracket_post_lo") pose([0,-90,0]) e2_bracket_lo();
if (pk=="e2_bracket_post_hi") pose([0,90,0])  e2_bracket_hi();
if (pk=="e2_bracket_beam")    pose([180,0,0]) e2_bracket_beam();
if (pk=="tip_cams")           pose([0,90,0])  tipcams();
// ---- 40 P3 bracket: flat, label up ----
if (pk=="p3_bracket") p3_bracket();                       // v1.7: on its bottom edge (Z 380), as drawn
// ---- 41..45 loop: ring and chute on their side (loop frame), brackets and spacers flat ----
if (pk=="loop_ring")      if (PR) CL_ring();  else at_loop() CL_ring();
if (pk=="loop_chute")     if (PR) CL_chute(); else at_loop() CL_chute();
if (pk=="loop_bracket_R") pose([90,0,0]) loop_bracket_R();
if (pk=="loop_bracket_L") pose([90,0,0]) loop_bracket_L();
if (pk=="card_holder_v18") holder();                 // v1.8: grid feet (print pose = as mounted)
if (pk=="e1_foot_v18")    E1_print("e1_foot");      // v1.8: grid screws + pins (print pose as E1_print)
if (pk=="e1_cw_post_v18") E1_print("e1_cw_post");   // v1.8: post 13 on grid nodes + pin
if (pk=="loop_stand_L")   pose([90,0,0]) ls1_leg(0);   // v1.8 LS1: flat on its back face (Y 112)
if (pk=="loop_stand_R")   pose([90,0,0]) ls1_leg(1);
if (pk=="loop_spacer")    if (PR) rotate([90,0,0]) loop_spacer([0, 0]); else loop_spacer(loop_tabs()[2+inst]);
// ---- 46..50 gate, feeds, finish ----
if (pk=="gate_box")     gate(flap=false);
if (pk=="gate_flap")    pose([0,-90,0]) gate_flap_part();     // v1.7t: on its -X end (knuckle axes stand: press holes round)
if (pk=="gate_crank")   pose([0,-90,0]) gate_crank();         // v1.7t 47b: on its -X face, spool up
if (pk=="e2_feed")      pose([90,0,0]) e2feed_part();
if (pk=="finish_track") finish_part();
if (pk=="finish_line")  pose([90,0,0]) finish_line();
// ---- 51 levelling wheels: flat ----
if (pk=="lev_wheel") let(q=LEV[inst]) if (PR) translate(-[q[0], q[1], -6-lev_set]) intersection() { lev_wheels(); translate([q[0], q[1], -20]) cylinder(d=19, h=14.5); }
                     else intersection() { lev_wheels(); translate([q[0], q[1], -20]) cylinder(d=19, h=14.5); }
// ---- v1.7 new parts (stack side) ----
if (pk=="cage_stand_R")  cage_stand_R();                                   // foot down
if (pk=="cage_stand_L")  cage_stand_L();                                   // bottom down
if (pk=="tray_hanger_a") pose([0,90,0]) tray_hanger(v17_hx[0]);           // flat on its X face (X 120)
if (pk=="tray_hanger_b") pose([0,90,0]) tray_hanger(v17_hx[1]);           // (X 200)
if (pk=="tray_arm")      pose([0,90,0]) tray_arm();                        // flat on its X face
if (pk=="e1_feed_stand_a") e1_feed_stand(0);                              // foot down, saddle up (felt corner)
if (pk=="e1_feed_stand_b") e1_feed_stand(1);
if (pk=="e2_feed_stand") e2_feed_stand();
if (pk=="pulley_collar") if (PR) rotate([90,0,0]) pulley_collar();          // flat
                         else if (inst==0) translate([E2P1[0], 62, E2P1[2]]) pulley_collar(); else translate([E2P3[0], 69.8, E2P3[2]]) pulley_collar();
// ---- v1.7t: E2 bracket braces (38d flat on its -Z face, 38e on its +X face), frame pegs (63, lying on the flat)
if (pk=="p1_strut")     p1_strut();
if (pk=="ledge_hanger") pose([0,90,0]) ledge_hanger();
if (pk=="frame_peg_12") frame_peg(12);
if (pk=="frame_peg_8")  frame_peg(8);
// ---- v1.7 (J58) gate cord guides: foot down
if (pk=="gate_legs") gate_legs();                                   // v1.7 46b: plate down
if (pk=="cord_guide_a") pose([-90,0,0]) cord_guide_a();   // on its back face, the peg up
if (pk=="cord_guide_b") cord_guide_b();
if (pk=="cord_guide_c") pose([0,90,0]) cord_guide_c();       // v1.7t: on its +X face (pegs C1, D and the tie tab stand up)
