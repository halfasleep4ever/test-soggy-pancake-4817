// v1.6 stack-side printed parts, one at a time, in their PRINT POSE (docs/coaster_v1.6_stack.md).
// pk   = part key (list in v16_build_stack.py, with numbers, copies and support plan)
// mode = "print": the part turned to its print pose (v16_build_stack.py then puts it on the bed centre)
//        "world": the part where it sits in the coaster at rest (inst = which copy)
// The print pose is the transform in pose(): the exporter does not turn anything itself.
// Steel, pads, felt and cords are drawn in silver / #2b2b2b / #2e343d / white: the builder exports from a copy of the
// .scad files with those colours switched off (as pack_v1.5/scad/build_stl.py).
include <coaster_v1.scad>
part = "none";
pk = "none"; inst = 0; mode = "print";
PR = mode == "print";

// rotate the vector n onto +Z (the plane with normal n becomes the bed)
module up(nv) let(u=nv/norm(nv), ax=cross(u, [0,0,1])) if (norm(ax) < 1e-9) children(); else rotate(a=acos(u[2]), v=ax) children();
module pose(r) if (PR) rotate(r) children(); else children();
module half(entry) translate([entry ? -10 : 100, -100, -10]) cube([110, 200, 100]);
module cup_local() stopcup(0.5, "STOP", false, test_cup_in - 2.5, side_in=false, zcut=15, x_in=true, lo_walls=true);
module e2feed_part() difference() { trough_chain([for (k=[2:len(E2feed)-1]) E2feed[k]], open_start=true, open_end=true, pads=[2]); trip_slot(E2O); }
module finish_part() {
    finish_track_body();
    for (y=[70, 125]) let(z=finish_pts[6][2]+(y-100)*(13.6-15.0)/41) translate([287-8, y-3, 0]) cube([16, 6, z-ball_r-0.8-1.6+0.3]);
}
module slide_spacer(k) intersection() { gd_static(); translate([pg_guide[k], pg_guideY, -0.01]) difference() { cylinder(d=7.5, h=pg_z[0]+0.01, $fn=24); translate([0,0,-1]) cylinder(d=3.36, h=5, $fn=16); } }

// ---- 01..05 ramp ends and stop cups: rig pose (as v1.5) ----
if (pk=="spine_end_entry")   if (PR) intersection() { stack_spine(); half(true); }  else at_ramp(inst) intersection() { stack_spine(); half(true); }
if (pk=="spine_end_exit")    if (PR) intersection() { stack_spine(); half(false); } else at_ramp(inst) intersection() { stack_spine(); half(false); }
if (pk=="carrier_end_entry") if (PR) intersection() { stack_carrier(); half(true); }  else at_ramp(inst) translate([0, -rod_cc(gap), 4]) intersection() { stack_carrier(); half(true); }
if (pk=="carrier_end_exit")  if (PR) intersection() { stack_carrier(); half(false); } else at_ramp(inst) translate([0, -rod_cc(gap), 4]) intersection() { stack_carrier(); half(false); }
if (pk=="stop_cup")          if (PR) cup_local(); else uturn(inst);
// ---- 06 stack frame: 8 pieces, all flat, tabs up ----
if (pk=="frame_ladder_back")  pose([90,0,0])  frame_ladder(0);
if (pk=="frame_ladder_front") pose([-90,0,0]) frame_ladder(1);
if (pk=="frame_post_back_L")  pose([90,0,0])  frame_post_lo(0, 0);
if (pk=="frame_post_back_R")  pose([90,0,0])  frame_post_lo(0, 1);
if (pk=="frame_post_front_L") pose([-90,0,0]) frame_post_lo(1, 0);
if (pk=="frame_post_front_R") pose([-90,0,0]) frame_post_lo(1, 1);
if (pk=="frame_bar_L")        pose([180,0,0]) frame_bar(0);
if (pk=="frame_bar_R")        pose([180,0,0]) frame_bar(1);
// ---- 07 / 08 comb frames: 2 pieces each, flat on the face away from the arms ----
if (pk=="comb_back_lo")  pose([90,0,0])  gd_frame_lo(0);
if (pk=="comb_back_hi")  pose([90,0,0])  gd_frame_hi(0);
if (pk=="comb_front_lo") pose([-90,0,0]) gd_frame_lo(1);
if (pk=="comb_front_hi") pose([-90,0,0]) gd_frame_hi(1);
// ---- 09..11 gap slide, peg plate, spacers: flat as drawn ----
if (pk=="gap_slide")    if (PR) pg_slide_s(0); else pg_slide();
if (pk=="peg_plate")    intersection() { gd_static(); translate([30, 60, -0.01]) cube([90, 40, 2.02]); }
if (pk=="slide_spacer") slide_spacer(inst);
// ---- 22 E1 feed: on its end ----
if (pk=="e1_feed") pose([0,-90,0]) e1feed();
// ---- 23 / 35 cages: on the strip's outer face (left: the mirrored part, so its strip face is -X); left top ring flat ----
if (pk=="cage_left")         if (PR) rotate([0,-90,0]) mirror([1,0,0]) cage_print(1); else at_ch(1) cage_print(1);
if (pk=="cage_left_topring") if (PR) mirror([1,0,0]) cage_topring(1); else at_ch(1) cage_topring(1);
if (pk=="cage_right")        if (PR) rotate([0,90,0]) cage_print(0); else at_ch(0) cage_print(0);
// ---- 24 / 36 carriages: on the +X wall (left: mirrored, -X) ----
if (pk=="carriage_left")  if (PR) rotate([0,-90,0]) mirror([1,0,0]) carriage_body(1); else at_ch(1) translate([0,0,cupEntryZ(k1)]) carriage_body(1);
if (pk=="carriage_right") if (PR) rotate([0,90,0]) carriage_body(0);                  else at_ch(0) translate([0,0,cupEntryZ(k2)]) carriage_body(0);
// ---- 25 E1 tray: 2 pieces, channel up, the keel bottom plane on the bed ----
tr_bA = (379.4-375.6)/130;                                 // A: keel bottom along the front run (X 100..230)
if (pk=="tray_e1_a") if (PR) up([-tr_bA, 0, 1]) tray_e1_a(); else tray_e1_a();
if (pk=="tray_e1_b") if (PR) up([-tr_bB[0], -tr_bB[1], 1]) tray_e1_b(); else tray_e1_b();
// ---- 37 E2 funnel ----
if (pk=="e2_funnel") pose([0,90,0]) e2_funnel();
// ---- 38 E2 top bracket: 3 pieces; 39 tip cams ----
if (pk=="e2_bracket_post_lo") pose([0,-90,0]) e2_bracket_lo();
if (pk=="e2_bracket_post_hi") pose([0,90,0])  e2_bracket_hi();
if (pk=="e2_bracket_beam")    pose([180,0,0]) e2_bracket_beam();
if (pk=="tip_cams")           pose([0,90,0])  tipcams();
// ---- 40 P3 bracket: flat, label up ----
if (pk=="p3_bracket") pose([90,0,0]) p3_bracket();
// ---- 41..45 loop: ring and chute on their side (loop frame), brackets and spacers flat ----
if (pk=="loop_ring")      if (PR) CL_ring();  else at_loop() CL_ring();
if (pk=="loop_chute")     if (PR) CL_chute(); else at_loop() CL_chute();
if (pk=="loop_bracket_R") pose([90,0,0]) loop_bracket_R();
if (pk=="loop_bracket_L") pose([90,0,0]) loop_bracket_L();
if (pk=="loop_spacer")    if (PR) rotate([90,0,0]) loop_spacer([0, 0]); else loop_spacer(loop_tabs()[2+inst]);
// ---- 46..50 gate, feeds, finish ----
if (pk=="gate_box")     gate(flap=false);
if (pk=="gate_flap")    gate_flap_plate(0);
if (pk=="e2_feed")      pose([90,0,0]) e2feed_part();
if (pk=="finish_track") finish_part();
if (pk=="finish_line")  pose([90,0,0]) finish_line();
// ---- 51 levelling wheels: flat ----
if (pk=="lev_wheel") let(q=LEV[inst]) if (PR) translate(-[q[0], q[1], -6-lev_set]) intersection() { lev_wheels(); translate([q[0], q[1], -20]) cylinder(d=19, h=14.5); }
                     else intersection() { lev_wheels(); translate([q[0], q[1], -20]) cylinder(d=19, h=14.5); }
