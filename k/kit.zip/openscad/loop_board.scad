// TEST 3 mount: the loop test pieces (loop_test.scad) on a 6 mm (1/4") birch plywood board, standing upright in two
// printed feet with leveling bolts. All sizes in the loop's frame: x along the board, y up, POI at (0, 0); the board's
// front face is w = 0 (the pieces sit on it).
// Board 380 x 420 mm: x -245 .. 135, y -65 .. 355. Holes: 3.5 mm (9/64") for M3, drilled from the paper template
// (make_loop_template.py -> loop_board_template.pdf).
// Parts: part="foot" (print 2). Hardware: see loop_board_parts.md.
include <loop_test.scad>

part = "assembly";   // assembly | foot

bx0 = -245; bx1 = 135; by0 = -65; by1 = 355; bt = 6.0;     // board (plywood is often 5.6..6.4 mm: the slot takes 6.6)
foot_x = [-150, 50];                                          // foot centres along the board
foot_hole_dx = 12; foot_hole_y = by0 + 15;                    // two M3 bolts per foot, 15 mm above the bottom edge
function foot_holes() = [ for (fx=foot_x, s=[-1,1]) [fx + s*foot_hole_dx, foot_hole_y] ];
function board_holes() = concat(tab_holes(), foot_holes());

// foot, printed flat: base 140 (across the board) x 40 (along it) x 6, a slot block 30 mm tall that grips the board's
// bottom edge, 2 M3 bolts through it, and an M4 leveling bolt in a nut pocket at each end of the base.
slot = 6.6; wall = 5; fh = 30; fl = 140; fwid = 40; fb = 6;
module foot() difference() {
    union() {
        translate([-fwid/2, -fl/2, 0]) cube([fwid, fl, fb]);
        translate([-fwid/2, -slot/2-wall, 0]) cube([fwid, slot+2*wall, fh]);
        // ribs so the slot block does not bend: 45 deg gussets front and back
        for (s=[-1,1]) hull() { translate([-2, s*(slot/2+wall), 0]) cube([4, 0.01, fh-4]); translate([-2, s*(slot/2+wall+20), 0]) cube([4, 0.01, fb]); }
    }
    translate([-fwid/2-1, -slot/2, fb]) cube([fwid+2, slot, fh]);                // the board slot
    for (s=[-1,1]) translate([s*foot_hole_dx, 0, fb+15]) rotate([90,0,0]) cylinder(d=3.4, h=slot+2*wall+2, center=true, $fn=24);
    for (s=[-1,1]) translate([s*foot_hole_dx, slot/2+wall-2.4, fb+15]) rotate([-90,0,0]) cylinder(d=6.6, h=3, $fn=6);   // M3 nut pocket
    for (s=[-1,1]) translate([0, s*(fl/2-9), -1]) { cylinder(d=4.4, h=fb+2, $fn=24); cylinder(d=8.2, h=3.6, $fn=6); }  // M4 bolt + nut from below
    translate([0, -fl/2+16, fb-0.6]) linear_extrude(1) text("FRONT", size=5, halign="center", valign="center");
}

module board() difference() {
    color("#c8a979") translate([bx0, by0, -bt]) cube([bx1-bx0, by1-by0, bt]);
    for (h=board_holes()) translate([h[0], h[1], -bt-1]) cylinder(d=3.5, h=bt+2, $fn=20);
}
module mounted() {
    board();
    assembly();
    // feet: the board edge sits in the slot; the foot's "front" (long side) is the side the pieces are on
    // foot frame -> world: x stays, foot up (z) -> world up (y), foot y -> -w (its FRONT side faces the pieces)
    for (fx=foot_x) color("#4a5360") translate([fx, by0 - fb, -bt/2]) rotate([-90,0,0]) foot();
}
if (part=="assembly") mounted();
if (part=="foot") foot();
