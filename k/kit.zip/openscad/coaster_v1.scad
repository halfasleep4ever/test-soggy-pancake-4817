// ROLLER COASTER R3 - full design, now VERSION 5 (2026-10-28; file name kept so the sim export and Fusion scripts still
// run). v4 is in cad/v4/ and in git (ca76ce9). v5 = v4 + the fixes in docs/coaster_v5.md (end-supported ramps, ball in
// view, minimal 3 mm basswood with laser files in cad/laser/, E2 rope in its own plane, touching loop lanes, 6 mm
// labels, pencil on the start line, levelling wheels). Everything in mm.
// World axes: X = length (left to right, 0 = left edge), Y = depth (back panel at the back, Y grows toward the
// viewer), Z = up (0 = top of the plywood base). Same layout as the simulator's R3 (sim cm x10), with the real part
// sizes. Shown with ladder 1 -> ramp 7, ladder 2 -> ramp 6, rail gap 14.3 mm.
//
// Ball path: start (pencil) -> chute -> 12 cm loop -> felt corner -> Elevator 1 (Type 1, front) -> fixed catch ledge ->
// front tray -> LEFT ladder channel -> carriage 1 -> ramp 7 ... ramp 19 (U-turn stop cups) -> bottom gate ->
// Elevator 2 (Type 2, back) -> fixed catch funnel -> RIGHT ladder channel -> carriage 2 -> ramp 6 ... ramp 19 -> gate
// (opened by a cord from Elevator 2's lever) -> finish track -> finish line -> felt stop.
//
// v5b (2026-10-28, docs/coaster_v5.md sections 16 to 18): (1) the hinged catch flaps are gone: a fence on each cup floor
// turns the ball off the floor's side edge onto a FIXED ledge (E1) / funnel (E2) beside the cup, where no part of the
// elevator ever goes; (2) no loop board: the loop bolts to Elevator 1's pin plate with printed brackets; (3) the gap
// knob (gears + lead screw) is replaced by a slide with cam slots and a peg plate (pin in numbered holes).
// part = "assembly" (default) | a printable part name (see the list at the end) | a subsystem for checks.
use <common.scad>
use <rail_test.scad>
use <coaster_e1.scad>
use <coaster_e2.scad>
use <coaster_loop.scad>
use <v17_card.scad>          // v1.7: timing card holder (coordinator's file): holder()
include <common.scad>

part = "assembly";
gap  = 14.3;                 // rail gap shown (12 .. 16.5)
v17_press = pin_hole - 0.15;   // v1.7: 3 mm steel pin or rod, press fit (3.15, fit test 2026-10-28)
k1 = 6; k2 = 5;              // ladder targets (0-based ramp index): ramp 7 (left channel, even) and ramp 6 (right, odd)
e1a = -E1_info()[7]; e2a = -53.1;   // (v1.8: E1's swing follows its lift kit)    // elevator angles shown (rest)

// ---------------- the stack ----------------
// v1.8 (modular): the size numbers are in v18m_params.scad (v18_th, v18_Lr, v18_n, v18_H, v18_goff, v18_Ztop_min).
// Everything in the stack range scales with (Ztop - Z19) (v18_sz), everything above it moves down with dZ (v18_tz).
include <v18m_params.scad>
th = v18_th; Lr = v18_Lr; x0 = 30; xRe = x0 + Lr*cos(th);       // ramp ends at X 30 and 229.8
n = v18_nlev();
drop = 8.05;                                                         // ball drop in each U-turn cup (exit 2.5 mm below entry)
Pp = Lr*sin(th) + drop;                                              // level pitch 16.77
Z19 = 56;                                                            // ramp 19 end ball line (16 mm above Elevator 2's cup)
Ztop = Z19 + (n-1)*Pp + Lr*sin(th);                                  // ramp 1 start, 366.7
v18_dZ = v18_Z17 - Ztop;                                             // how much lower the top is than v1.7
function v18_sz(z) = Z19 + (z - 56)*(Ztop - Z19)/(v18_Z17 - 56);    // a v1.7 Z inside the stack range, scaled
function v18_tz(z) = z - v18_dZ;                                     // a v1.7 Z above the stack (crown), moved down
assert(Ztop >= v18_Ztop_min - 0.01, str("v1.8: Ztop ", Ztop, " is under the limit ", v18_Ztop_min, " (E1 tray over the loop chute)"));
planeY = [16, 38];                                                   // back / front ramp planes (ball line)
function dirOf(i) = i%2 ? -1 : 1;
function entry(i) = [i%2 ? xRe : x0, planeY[i%2], Ztop - i*Pp];
function rend(i)  = entry(i) + [dirOf(i)*Lr*cos(th), 0, -Lr*sin(th)];
cc12 = rod_cc(12); kR = (ball_r + rod_d/2)/ball_r;
d2 = rod_cc(gap) - rod_cc(12+v18_goff);                              // outer rail moved by the gap knob (v1.8: from the slide's 0, gap 12 + v18_goff)
ballZ0 = 12 + rod_drop(12);                                          // ball line above the spine bottom (gap 12): 20.57
slabOut = 21.1;                                                      // slab reaches this far outward of the inner rod
// a ramp's spine frame: x along the ramp, y = 0 at the inner (fixed) rod, -y outward, z = 0 at the spine bottom
module at_ramp(i) translate(entry(i)) rotate([0,0, i%2 ? 180 : 0]) rotate([0,th,0]) translate([0, cc12/2, -ballZ0]) children();
// both start 1 mm in: the 2.5 deg tilt otherwise pushes the end face 0.9 mm into the cup before it (Fusion check)
// v5 fix 1: every ramp is held only at its two ends (26 mm spine and carrier pieces, as rail_test spine200e /
// carrier200e). The 3 mm rods span the 148 mm between them (sag under the ball about 0.03 mm). The ball shows between
// the ends from the front. The frame tabs (X 34, 222.8) and the comb-frame arms (X 50, 209.8) both land on the ends.
// v1.7 (J7, J18): an X key. A 2 x 1 mm ridge across each spine end's slab (along Y, under the carrier) and a 2.4 x 1.2 mm
// notch across the carrier's bottom: the carrier still slides in Y (gap), but not along X, so the comb frames glued to
// the carriers are held in X (the comb-frame guide stubs guided nothing and are gone).
v17_keyx = [13, 187];
module stack_spine() difference() { ends_only(200) { intersection() { spine(200); translate([1, -slabOut, -1]) cube([200, slabOut+3.6, 40]); }
    for (x=v17_keyx) translate([x-1, -slabOut, 4-0.01]) cube([2, 8.6, 1.01]); }
    v18_j6_slabholes(); }   // v1.8 (J6): locating pin + countersunk M3 x 8 into the frame pad
module stack_carrier() ends_only(200) { difference() { intersection() { carrier(200); translate([1, -2.6, -1]) cube([200, 4.6, 30]); }   // v1.8: from the wall face (the 0.4 mm foot stub met the comb pad)
    for (x=v17_keyx) translate([x-1.2, -4, -1]) cube([2.4, 7, 2.2]); }
    v18_j15_ribs(); }
// v1.8 (J15, no glue): a dovetail rib on each carrier end's outer face, under the comb arm (x 20, 180; carrier frame z 4..7).
// The comb arm's pad has the matching groove, closed at its top: the comb hangs on the 38 ribs and pushes / pulls the
// carriers in Y. Lift the comb 3.5 mm (the frame pin leaves the slide's cam slot too) and every carrier is free.
v18_j15_x = [20, 180]; v18_j15_z = [4, 7]; v18_j15_c = 0.15;
function v18_dove(c, y0, dy) = [[-1.5-c, y0], [-2.2-c, y0+dy], [2.2+c, y0+dy], [1.5+c, y0]];
module v18_j15_ribs() for (x=v18_j15_x) translate([x, 0, v18_j15_z[0]]) linear_extrude(v18_j15_z[1]-v18_j15_z[0]) polygon(v18_dove(0, -2.6+0.01, -1.8));
module ramp(i) at_ramp(i) {
    color("#d08a4a") stack_spine();
    color("#59a5c4") translate([0, -rod_cc(gap), 4]) stack_carrier();
    color("silver") { translate([100, 0, 12]) rotate([0,90,0]) cylinder(d=rod_d, h=196, center=true, $fn=12);
                      translate([100, -rod_cc(gap), 12]) rotate([0,90,0]) cylinder(d=rod_d, h=196, center=true, $fn=12); }
}
// U-turn stop cup after ramp i (rail_test stopcup, placed by its test coordinates: ramp end at x 200, ball line y 0,
// gap-12 ball line z 39.69).
test_ball_z = 39.69; test_cup_in = 35.637;
// v1.7r (rule 3.c): the FRONT side wall of each stop cup (world +Y side: test y1 for the right cups, y0 for the left
// cups, turned 180 deg) ends cup_fdrop lower than the back one, so more of the ball shows from the front.
// Only the LEFT cups (their front wall is the entry-side wall at y0, along which the ball comes in; it rolls away from it
// to the exit corner at y1): 2.5 mm (wall top 4.8 mm under the ball centre, 0.28 m/s sideways needed to climb it; the
// ball crosses the cup at about 0.07 m/s). The right cups keep theirs: their front wall is the exit-corner wall the ball
// rolls into, and the lug in front of it (below) hides that band anyway. Visibility test: docs/coaster_v1.7_rules_fixes.md.
cup_fdrop = 2.5;
function cup_wdrop(right) = right ? [0, 0] : [cup_fdrop, 0];
module uturn(i) translate(rend(i)) rotate([0,0, i%2 ? 180 : 0]) translate([-200, 0, -test_ball_z])
    color("#6cbf8f") v18_cup_part(i%2==0);
// v1.8 (J10): the stop cup with its lug and the lug's pin and screw holes (test frame); also the print part (v16_stack_parts)
module v18_cup_part(right) difference() { union() { stopcup(0.5, "STOP", false, test_cup_in - 2.5, side_in=false, zcut=15, x_in=true, lo_walls=true, wdrop=cup_wdrop(right)); cup_lug(right); }
    v18_j10_lugholes(right); }   // every cup has the ladder slot (left channel: odd cups, right: even); v5: low walls (ball in view)
// v1.7 (J10): each stop cup gets a lug 4 x 9 mm that lies flat on the front post's side face: glue face 36 mm2 (CA).
// Test frame: right cups (i even): the post's +X face is at test x 197; left cups (i odd, turned 180): its -X face at x 200.
// v1.7 FEA (stack side): the ball's hit on the stop pad (14 N est. at 0.5 m/s) bent the 4 x 9 lug at the cup wall:
// SF 0.43. The lug now covers the post's whole side face (8 deep with the doubler, Y 53.65..61.65) and is 17 tall
// (Z 15..32, still under the cup's wall top): glue face 136 mm2, section modulus 7.5 x.
// v1.7r (rule 3.c): the LEFT cups' lug is 9 tall (Z 15..24 in the test frame: its top is 9.6 under the cup's ball centre,
// level with the ball's bottom), glue face 8 x 9 = 72 mm2. The 17 mm lug hid the lower part of every ball at the left
// stack end from the front; the left cups had SF 6.0 with it (v1.7 4 x 9 lug: 3.34). Right cups: unchanged (SF 1.84).
cup_lugL_h = 9;
module cup_lug(right) if (right) translate([197, postYf[0]-16, 15]) cube([13, 4+v17_fdbl, 17]);
                      else translate([200, 38-postYf[1]-v17_fdbl, cup_lugL_z0]) cube([13, 4+v17_fdbl, 15+cup_lugL_h-cup_lugL_z0]);
// ---------------- v1.8 (modular, docs/modules_v1.8.md section 10): screws + locating pins instead of glue ----------------
// hole helpers (fit holes $fn = fit_fn): along X with the teardrop point to +Z; along Z with the point to +y
module v18_td_x(d, x0, x1) translate([x0, 0, 0]) rotate([0,90,0]) linear_extrude(x1-x0) union() { circle(d=d, $fn=fit_fn); rotate(135) square(d/2); }
module v18_td_z(d, z0, z1) translate([0, 0, z0]) linear_extrude(z1-z0) union() { circle(d=d, $fn=fit_fn); rotate(45) square(d/2); }
// J6: each spine end sits on a pad under its slab (frame side): a 3 x 7 locating pin (rod) pressed in the pad, pin_slip in
// the slab (+-0.075); the screw beside it (and the v1.7 X-key ridge) stop the turn; 1 M3 x 8 countersunk DOWN through the
// slab (head flush with the slab top, under the carrier) into a nut in the pad's underside. Same x on every ramp (ramp
// frame), so the 19 entry ends are one part again, and the 19 exit ends. Pad 10 x 11.6 x 4 under the slab + a block under the tab.
// (export check: a pad longer than the tab along the ramp starts in mid air in the post's flat print. So the pad keeps the
// tab's x range plus 45 deg flanks, and the pin and the screw sit one behind the other across the slab.)
v18_j6_pin  = [6, 194];           // pin and screw x (entry end, exit end), ramp frame: inside every tab (x 1..7, 4..10 / 190..196, 193..199)
v18_j6_bolt = v18_j6_pin;
v18_j6_py   = -slabOut + 2.5;     // pin y (-18.6)
v18_j6_y    = -slabOut + 8;       // screw y (-13.1); the nut's flats face y (across flats 5.7)
v18_j6_pad  = [[1, 11], [189, 199]];
v18_j6_pw   = 11.6;               // pad depth under the slab (y -21.1 .. -9.5)
module v18_j6_pad(i, px) at_ramp(i) let(x=rlx(i, px), e=(x < 100 ? 0 : 1), d=(i%2==0 ? planeY[0]+cc12/2-slabOut-postYb[1] : postYf[0]-(planeY[1]-cc12/2+slabOut)+0.5)) {
    hull() { translate([x-3, -slabOut, -4]) cube([6, v18_j6_pw, 4]);                                    // the tab's width at the slab edge,
             translate([v18_j6_pad[e][0], -slabOut+4, -4]) cube([v18_j6_pad[e][1]-v18_j6_pad[e][0], v18_j6_pw-4, 4]); }   // the full width 4 mm in (45 deg)
    // (y from the slab edge: the comb bars pass 0.5 mm outside it at gap 12)
    translate([x-3, -slabOut-d-0.01, -4]) cube([6, d+0.02, 3.01]);          // under the tab, from the post to the pad
}
module v18_j6_padholes(i, px) at_ramp(i) let(e=(rlx(i, px) < 100 ? 0 : 1)) {
    translate([v18_j6_pin[e], v18_j6_py, 0]) v18_td_z(pin_press_lying, -3.6, 0.01);                    // pin: lying in the frame print, point up (+y)
    translate([v18_j6_bolt[e], v18_j6_y, -5]) cylinder(d=m3_clear, h=6, $fn=16);
    translate([v18_j6_bolt[e], v18_j6_y, -4.01]) cylinder(d=m3_nut_lying, h=2.61, $fn=6);             // nut: corners along x, flats across the slab
}
module v18_j6_slabholes() for (e=[0,1]) {
    translate([v18_j6_pin[e], v18_j6_py, -1]) cylinder(d=pin_slip, h=10, $fn=fit_fn);                // standing in the spine-end print
    translate([v18_j6_bolt[e], v18_j6_y, -1]) cylinder(d=m3_clear, h=10, $fn=16);
    translate([v18_j6_bolt[e], v18_j6_y, 4-1.71]) cylinder(d1=3.4, d2=6.4, h=1.72, $fn=24);          // countersink, flush
}
module v18_j6_hw(i) at_ramp(i) color("silver") for (e=[0,1]) {
    translate([v18_j6_pin[e], v18_j6_py, -3.5]) cylinder(d=3, h=7, $fn=16);
    translate([v18_j6_bolt[e], v18_j6_y, -4]) cylinder(d=3, h=8, $fn=12);
}
// J10: each stop cup lug: 1 locating pin 3 x 9 (rod) along X, pin_press in the front post's side face, pin_slip in the lug;
// 1 M3 x 16 along X from the post's inner face (cylinder head) through the post into a nut in the lug (pocket from the
// lug's outer face). Left cups (lug 9 tall, no room for a pin beside the nut): the screw only, in close-fit 3.2 holes.
// Test frame (rail_test): right cups: post X 189..197, lug 197..210; left cups (turned 180): post 192..200, lug 200..213.
cup_lugL_z0 = 15;   // (v1.8 export check: a lower lug left the cup body hanging over the bed)
v18_m3_close = 3.2;   // close-fit M3 hole: the left cups' screw also locates them (+-0.15)
function v18_j10(right) = right ? [189, 197, 210, postYf[0]-16+(4+v17_fdbl)/2, 28, 19.5]      // [post in, post out, lug end, y, bolt z, pin z]
                                : [192, 200, 213, 38-postYf[1]-v17_fdbl+(4+v17_fdbl)/2, 19.5, undef];   // left: screw only (lug 9 tall)
module v18_j10_lugholes(right) let(q=v18_j10(right)) {
    translate([0, q[3], q[4]]) { v18_td_x(right ? m3_clear : v18_m3_close, q[1]-0.01, q[2]+1); translate([q[1]+(right?4:4), 0, 0]) rotate([0,90,0]) cylinder(d=m3_nut_lying, h=q[2]-q[1]-3, $fn=6); }
    if (right) translate([0, q[3], q[5]]) v18_td_x(pin_slip, q[1]-0.01, q[1]+4);
}
module v18_j10_postholes(right) let(q=v18_j10(right)) {
    translate([0, q[3], q[4]]) v18_td_x(right ? m3_clear : v18_m3_close, q[0]-1, q[1]+0.01);
    translate([0, q[3], q[4]]) v18_td_x(6.0, q[0]-10, q[0]+0.01);   // head counterbore where the lap splice widens the post inward (4 mm)
    if (right) translate([0, q[3], q[5]]) v18_td_x(pin_press_lying, q[1]-5, q[1]+0.01);
}
module at_cup(i) translate(rend(i)) rotate([0,0, i%2 ? 180 : 0]) translate([-200, 0, -test_ball_z]) children();
// the post holes of every cup on front post k (k 1: right cups, even i; k 0: left cups, odd i), world
module v18_j10_frameholes(k) for (i=[0:n-2]) if ((i%2==0) == (k==1)) at_cup(i) v18_j10_postholes(i%2==0);
module v18_j10_hw(i) at_cup(i) let(r=(i%2==0), q=v18_j10(r)) color("silver") {
    translate([q[0]-3, q[3], q[4]]) rotate([0,90,0]) cylinder(d=5.5, h=3, $fn=16);
    translate([q[0], q[3], q[4]]) rotate([0,90,0]) cylinder(d=3, h=16, $fn=12);
    if (r) translate([q[1]-5, q[3], q[5]]) rotate([0,90,0]) cylinder(d=3, h=9, $fn=12);
}
module uturn_pad(i) translate(rend(i)) rotate([0,0, i%2 ? 180 : 0]) translate([-200, 0, -test_ball_z]) stoppad(0.5, test_cup_in - 2.5, lo_walls=true);
// frame: 4 posts, tabs from every spine to the posts, top beams
postX = [34, 222.8]; postYb = [-9, -5];
// v1.8: the front posts keep their v1.7 clearance to the front carriers at the widest gap: a wider gap range
// (v18_goff > 0) moves them out by the extra rod spacing
v18_fy0 = 53.65 + max(0, rod_cc(16.5+v18_goff) - rod_cc(16.5));   // (the carriers reach Y 52.75 at 16.5)
postYf = [v18_fy0, v18_fy0 + 4];   // front posts 1 mm out: the carriers reach Y 52.8 at gap 16.5
yS = Ztop + 16; yBeam = yS + 10; yK = yS + 24;
function ballZat(i, x) = entry(i)[2] - abs(x - entry(i)[0])*tan(th);  // ball line height over X on ramp i
// v1.5 frame, kept for reference (one 397 mm piece: too tall for the 270 mm bed)
module frame_v15() color("#4a5360") {
    for (px=postX) { translate([px-4, postYb[0], 0]) cube([8, 4, yBeam+4]); translate([px-4, postYf[0], 0]) cube([8, 4, yBeam+4]); }
    for (py=[postYb[0], postYf[0]]) translate([postX[0]-4, py, yBeam]) cube([postX[1]-postX[0]+8, 4, 4]);
    for (px=postX) translate([px-4, postYb[0], yBeam]) cube([8, postYf[1]-postYb[0], 4]);
    for (i=[0:n-1], px=postX) let(zb=ballZat(i,px)-ballZ0) {
        if (i%2==0) translate([px-3, postYb[1], zb-1]) cube([6, planeY[0]+cc12/2-slabOut-postYb[1], 4]);
        else        translate([px-3, planeY[1]-cc12/2+slabOut, zb-1]) cube([6, postYf[0]-(planeY[1]-cc12/2+slabOut)+0.5, 4]);
    }
}
// v1.6 (print fix, docs/coaster_v1.6_stack.md): the frame is 8 printed pieces, all printed flat (no support):
//  - 2 ladders (f = 0 back, 1 front): the upper part of both posts + the top beam along X + their ramp tabs;
//  - 4 lower posts (f, k = 0 left, 1 right) with their tabs;
//  - 2 cross bars along Y (k = 0 left, 1 right) on top.
// Post joint: an in-plane half lap, 24 mm long, in a splice that is 4 mm wider toward the middle of the stack (12 x 4 mm),
// cut where no tab is. Each half keeps 6 mm of the width; 2 steel pins 2 x 12 mm go across the seam (along X). The lap
// faces are vertical when the piece lies flat, so both halves print with no overhang.
// Corner joint: half lap in Z (the ladder keeps the lower 2 mm, the cross bar the upper 2 mm) + a 2 x 8 mm steel pin.
fr_lapL = 24;                                              // lap length (Z)
fr_mid = [[v18_sz(229.5), v18_sz(221.25)], [v18_sz(237.9), v18_sz(212.6)]];                // lap centre Z [back, front][left, right]: between two tabs
fr_pinD = 2.1;                                             // v1.7t: hole for a printed PETG peg d 2.0 (part 63, + CA); the owner has no 2 mm pins and
                                                           // a 3 mm pin would leave < 1.2 mm in the 4 mm post layers (the front ladder's lap is ladder 4 + strip 4)
function fr_py(f) = [postYb[0], postYf[0]][f];             // post Y (low face), 4 mm thick
function fr_spl(k) = k==0 ? [postX[0]-4, postX[0]+8] : [postX[1]-8, postX[1]+4];   // splice X range (widened inward)
function fr_seam(k) = (fr_spl(k)[0]+fr_spl(k)[1])/2;
function fr_lap(f, k) = [fr_mid[f][k]-fr_lapL/2, fr_mid[f][k]+fr_lapL/2];
// one post with its tabs, as v1.5
module fr_post(f, k) let(px=postX[k]) {
    translate([px-4, fr_py(f), 0]) cube([8, 4, yBeam+4]);
    for (i=[0:n-1]) if (i%2 == f) let(zb=ballZat(i,px)-ballZ0) {
        if (f==0) translate([px-3, postYb[1], zb-1]) cube([6, planeY[0]+cc12/2-slabOut-postYb[1], 4]);
        else      translate([px-3, planeY[1]-cc12/2+slabOut, zb-1]) cube([6, postYf[0]-(planeY[1]-cc12/2+slabOut)+0.5, 4]);
        fr_ledge(i, px);
    }
    if (f==1) fr_doubler(k);
}
// v1.7 (FEA, hand push): the front posts have no back panel; 4 mm deep they bent 13 mm under a 2 N push at mid height
// (SF 1.8 at a tab root). A 4 mm doubler on the front face (Y 57.65..61.65, up to the top beam) makes them 8 mm deep.
// The right one is cut to the E2 feed's outer surface (part of its saddle).
v17_fdbl = 4;
// The doubler is part of the LOWER post prints (they lie on that face). On the ladders (they lie on the beam's front face,
// and the P3 bracket needs that face) it is a separate flat strip (06i, 06j), glued (CA) and bolted through the post with
// M3 x 12 (nuts on the post's back face, between the ramp levels; left: also the 2 tray-arm bolts).
function fr_strip_z(k) = k==0 ? [v18_sz(276), v18_sz(309.8), v18_tz(385)] : [v18_sz(251), v18_sz(318), v18_sz(360), v18_tz(385)];   // (Z 385: v1.7 FEA, the P3 plate bolts)
module fr_strip(k) let(L=fr_lap(1, k), sp=fr_spl(k), o=(k==0 ? [fr_seam(k), sp[1]] : [sp[0], fr_seam(k)])) difference() {
    union() { translate([postX[k]-4, postYf[1], L[1]-0.01]) cube([8, v17_fdbl, (k==1 ? v18_tz(440) : yBeam+4)-L[1]+0.01]);   // (v1.7 FEA: up to the beam top, Z 396.65: the P3 plate bears on it;
              // v1.7t FEA: the right strip goes on up behind the plate to Z 440: the 38d strut's second M3 (X 223.5, Z 431.25) passes
              // strut, plate and strip, so the P1 rope load enters the strip, not the plate's corner at the strip top (SF 1.5))
              translate([o[0], postYf[1], L[0]]) cube([o[1]-o[0], v17_fdbl, fr_lapL]); }
    fr_strip_holes(k); if (k==1) st_p3_holes(); v18_j10_frameholes(k);   // v1.8 J10: the cup screws and pins pass the strip
}
module fr_strip_holes(k) for (z=concat(fr_strip_z(k), k==0 ? v17_armz : [])) translate([postX[k], postYf[0]-1, z]) rotate([-90,0,0]) cylinder(d=m3_clear, h=6+v17_fdbl, $fn=16);
module fr_strip_nuts() color("silver") for (k=[0,1], z=fr_strip_z(k)) translate([postX[k], postYf[0]+0.01, z]) rotate([90,0,0]) cylinder(d=6.35, h=2.4, $fn=6);
module fr_doubler(k) difference() { translate([postX[k]-4, postYf[1]-0.01, 0]) cube([8, v17_fdbl+0.01, yBeam]);
    if (k==1) trough_outer([for (j=[2:len(E2feed)-1]) E2feed[j]]); }
// v1.7 (J6): a 3 mm ledge under each spine end's slab at its tab. The slab sits on it: glue face 6 x 6 mm (CA), plus the
// v1.6 butt face. Drawn in the ramp's frame, so its top is exactly the slab's (2.5 deg) underside.
function rlx(i, px) = abs(px - entry(i)[0]) / cos(th);
module fr_ledge(i, px) v18_j6_pad(i, px);   // v1.8 (J6): pad 22 x 9 x 4 (was the v1.7 6 x 7 x 3 glue ledge)
module fr_ledge_holes(f, k) for (i=[0:n-1]) if (i%2 == f) v18_j6_padholes(i, postX[k]);
// v1.7 (J12): a foot flange 8 x 10 x 3 mm on each lower post (back posts: to the front; front posts: to the back, under
// the stack), one M3 x 12 countersunk up from under the base, nut on the flange
v17_footY = [0, 48.65];
// v1.8 (grid, docs/modules_v1.8.md section 5): each foot flange reaches its grid node (bolt: M3 x 12 countersunk from
// under the base, nut on the flange); back-left and front-right carry the frame's 2 locating pins (3 x 9 rod, 5 mm in the
// flange's boss, 4 mm into the grid hole). Flanges [x0, x1, y0, y1]; they stay off the gap slide's strips (X >= 40).
v18_ffoot = [[[25, 38, -5, 14], [215, 226.8, -5, 5]], [[25, 38, 43.65, 53.65], [215, 227, 36, 53.65]]];   // [f][k]
v18_fbolt = [[[30, 0], [220, 0]], [[30, 50], [220, 50]]];
v18_fpin  = [[[30, 10], undef], [undef, [220, 40]]];
module fr_foot(f, k) let(q=v18_ffoot[f][k], pn=v18_fpin[f][k]) {
    translate([q[0], q[2], 0]) cube([q[1]-q[0], q[3]-q[2], 3]);
    if (!is_undef(pn)) translate([pn[0], pn[1], 0]) cylinder(d=8, h=5, $fn=32);      // pin boss (5 deep)
}
// the pin hole lies in the post's print (back pieces: +Y up, front: -Y up): teardrop to that side
module fr_foot_hole(f, k) let(b=v18_fbolt[f][k], pn=v18_fpin[f][k]) {
    translate([b[0], b[1], -1]) cylinder(d=m3_clear, h=5, $fn=16);
    if (!is_undef(pn)) translate([pn[0], pn[1], -0.01]) linear_extrude(5) union() { circle(d=pin_press_lying, $fn=fit_fn); rotate(f==0 ? 45 : 225) square(pin_press_lying/2); }
}
// v1.7 (J2): back panel M3 x 16 (v1.7t; was x 14) through the back posts (3.4 holes along Y), nut on the post's front face. Right post:
// Z 188 / 322 (at 200 / 340 the nut met a ramp tab)
function fr_bpz(k) = k==0 ? [v18_sz(60), v18_sz(200), v18_sz(340)] : [v18_sz(60), v18_sz(188), v18_sz(322)];
module fr_bp_holes(f, k) if (f==0) for (z=fr_bpz(k)) translate([postX[k], postYb[0]-1, z]) rotate([-90,0,0]) cylinder(d=m3_clear, h=6, $fn=16);
// v1.7: the tray arm's 2 M3 through the front-left post (Z 349, 364.5); P3 bracket bosses on the front ladder's top beam
// (J61: the beam is 4 x 4, too small for an M3: a 10 x 7 x 10.3 boss behind it takes the bolt, nut in its back face)
v17_armz = [v18_tz(349), v18_tz(364.5)];
module fr_arm_holes() for (z=v17_armz) translate([postX[0], postYf[0]-1, z]) rotate([-90,0,0]) cylinder(d=m3_clear, h=6+v17_fdbl, $fn=16);
v17_p3x = [80, 190];
module fr_p3_boss() for (x=v17_p3x) translate([x-5, postYf[1]-7, v18_tz(389.5)]) cube([10, 7, 10.3]);
module fr_p3_holes() for (x=v17_p3x) { translate([x, postYf[0]-4, v18_tz(394.65)]) rotate([-90,0,0]) cylinder(d=m3_clear, h=12, $fn=16);
    translate([x, postYf[1]-7-0.01, 394.65]) rotate([-90,0,0]) cylinder(d=m3_nut, h=2.6, $fn=6); }
// (v1.7t: the lap holes lie in every print: teardrop, point up in the print = world +Y for the back pieces (on their -Y
// face), -Y for the front ones; the corner holes lie in the ladders and stand in the bars, printed upside down)
module fr_lap_pins(f, k) let(L=fr_lap(f, k)) for (z=[fr_mid[f][k]-7, fr_mid[f][k]+7])
    translate([fr_spl(k)[0]-1, fr_py(f)+2, z]) rotate([0,90,0]) linear_extrude(14) union() { circle(d=fr_pinD, $fn=fit_fn); rotate(f==0 ? 45 : 225) square(fr_pinD/2); }
module fr_corner_pin(f, k, lying=false) translate([postX[k], fr_py(f)+2, yBeam-4]) linear_extrude(8.01) union() { circle(d=fr_pinD, $fn=fit_fn); if (lying) rotate(f==0 ? 45 : 225) square(fr_pinD/2); }
// part 63: printed peg d 2.0 with a flat (prints lying on it), length L (12 for the laps, 8 for the corners)
module frame_peg(L) intersection() { rotate([0,90,0]) cylinder(d=2.0, h=L, $fn=fit_fn); translate([-1, -2, -0.85]) cube([L+2, 4, 3]); }
// lower post (f, k): below the lap, plus the outer half of the splice
module frame_post_lo(f, k) let(L=fr_lap(f, k), s=fr_spl(k), o=(k==0 ? [s[0], fr_seam(k)] : [fr_seam(k), s[1]])) difference() {
    union() {
        intersection() { fr_post(f, k); translate([-50, -50, -1]) cube([400, 200, L[0]+1]); }
        translate([o[0], fr_py(f), L[0]]) cube([o[1]-o[0], f==1 ? 4+v17_fdbl : 4, fr_lapL]);
        fr_foot(f, k);
        if (f==1 && k==1) e2feed_saddle();
    }
    fr_lap_pins(f, k); fr_foot_hole(f, k); fr_bp_holes(f, k);
    fr_ledge_holes(f, k); if (f==1) v18_j10_frameholes(k);   // v1.8 J6, J10
}
// ladder f: both posts above their laps (+ the inner half of each splice), the top beam, the tabs; corners cut to Z yBeam+2
module frame_ladder(f) difference() {
    union() {
        for (k=[0,1]) let(L=fr_lap(f, k), s=fr_spl(k), o=(k==0 ? [fr_seam(k), s[1]] : [s[0], fr_seam(k)])) {
            intersection() { fr_post(f, k); translate([-50, -50, L[1]]) cube([400, 200, 500]); }
            translate([o[0], fr_py(f), L[0]]) cube([o[1]-o[0], f==1 ? 4+v17_fdbl : 4, fr_lapL]);
        }
        translate([postX[0]-4, fr_py(f), yBeam]) cube([postX[1]-postX[0]+8, 4, 4]);
        // v1.7 FEA (stack side): a 2 N push down on the back top beam's middle gave SF 1.45 and 2 mm (4 x 4 beam, 189 mm
        // between the posts). Both top beams are 10 mm deep now (a web Z 386.65..392.65 under the beam, between the posts;
        // the comb frames' top bars stay under Z 384.2)
        translate([postX[0]+4-0.01, fr_py(f), yBeam-6]) cube([postX[1]-postX[0]-8+0.02, 4, 6.01]);
        if (f==1) fr_p3_boss();
    }
    if (f==1) { fr_arm_holes(); fr_p3_holes(); for (k=[0,1]) fr_strip_holes(k);
                translate([-50, postYf[1], -1]) cube([400, 50, 500]); }      // v1.7: the doubler is a separate strip here
    for (k=[0,1]) { fr_lap_pins(f, k); fr_corner_pin(f, k, true); fr_bp_holes(f, k); fr_ledge_holes(f, k); if (f==1) v18_j10_frameholes(k);   // v1.8 J6, J10
        translate([postX[k]-4.01, fr_py(f)-0.01, yBeam+2]) cube([8.02, 4.02, 3]); }
}
// cross bar k: the side beam along Y (v1.5) minus the lower half of the two corner squares
module frame_bar(k) let(px=postX[k]) difference() {
    translate([px-4, postYb[0], yBeam]) cube([8, postYf[1]-postYb[0], 4]);
    for (f=[0,1]) { translate([px-4.01, fr_py(f)-0.01, yBeam-1]) cube([8.02, 4.02, 3]); fr_corner_pin(f, k); }
}
module frame() color("#4a5360") {
    for (f=[0,1]) { frame_ladder(f); for (k=[0,1]) frame_post_lo(f, k); }
    for (k=[0,1]) fr_strip(k); fr_strip_nuts();
    for (k=[0,1]) frame_bar(k);
}
// gap drive. v5b fix 3 (Kai, 2026-10-28): a PEG PLATE instead of the 32:16 gears and the left/right lead screw.
// The 2 comb frames (bars at xB, arms to every carrier, guide-rod stubs) stay. Each frame now has a bottom bar (the
// frame is a closed rectangle) with a pin block and a 3 x 20 steel pin pointing down at X pg_xp. Under the stack, on the
// base, a SLIDE moves along X; its two straight cam slots (5.5 deg) carry the pins: slide travel s moves the back frame
// -Y and the front frame +Y by d2 = s * pg_k, the same outer-rail move as the lead screw made. 6 mm of travel = 0.5 mm of
// gap, exactly linear. The slide's arm reaches forward over a fixed PEG PLATE (in front of the stack, X 38..106); a
// 3 x 20 steel pin through the arm's index hole into a numbered hole locks the setting: row A 12.0 .. 16.5 mm (10 holes,
// 0.5 steps), row B half a step on (12.25 .. 16.25, 9 holes): 0.25 mm steps with one pin. The slide is held by two M3
// bolts with spacers in a long slot. Everything is under Z 20: below every ball path and out of the sight lines.
xB = [50, 209.8]; xm = (x0+xRe)/2;
zBarB = planeY[0] + cc12/2 - slabOut - 2 - d2;  zBarF = planeY[1] - cc12/2 + slabOut + 2 + d2;
yG = Z19 - ballZ0 - 16;
pg_p = 6;                                  // hole pitch (slide travel) per 0.5 mm of gap
pg_k = 0.5*rail_k/pg_p;                    // frame move per mm of slide travel (0.0964: 5.5 deg slots)
function pg_d2(g) = rod_cc(g) - rod_cc(12+v18_goff);      // outer-rail (frame) move from gap 12
function pg_s(g) = pg_d2(g)/pg_k;          // slide travel for gap g: 0 at 12, 54 at 16.5
pg_xp = 100;                               // the frames' pins (world X)
pg_yb0 = planeY[0] + cc12/2 - slabOut - 2 + 2;   // back pin Y at gap 12 (2 mm inside the frame bar); it moves -d2
pg_yf0 = planeY[1] - cc12/2 + slabOut + 2 - 2;   // front pin Y at gap 12; it moves +d2
pg_z = [2.2, 4.6];                         // slide (2.4 mm PETG)
pg_slot = pin_hole + 0.05;                 // cam slot width (3 mm pin)
pg_uA = 44; pg_rowY = [76, 84];            // index holes on the arm (slide coordinates), rows A and B
pg_guide = [100, 156]; pg_guideY = 27;     // the slide's two guide bolts (world X), in one long slot
function pg_guide_xy() = [for (x=pg_guide) [x, pg_guideY]];
function pg_gapA(n) = 12 + v18_goff + 0.5*n;          // row A hole n (0..9)
function pg_gapB(n) = 12.25 + v18_goff + 0.5*n;       // row B hole n (0..8)
function pg_holeX(row, n) = pg_uA + pg_p*n + (row == 1 ? pg_p/2 : 0);   // peg plate hole (world X)
function pg_ongrid(g) = abs(4*g - round(4*g)) < 1e-6 && g >= 12+v18_goff && g <= 16.5+v18_goff;
module gapdrive() { gd_frame(0); gd_frame(1); gd_static(); pg_slide(); pg_lockpin(); }
// one comb frame (s = 0 back, 1 front): bars, guide-rod stubs, arms to its carriers (moves with the gap setting)
// v1.6 (print fix): 377 mm tall, too tall for the bed. Now 2 pieces (lower, upper), each printed flat on its face away
// from the arms (back frame: -Y face; front: +Y face), arms up. Joint: a dovetail key in the plane of the frame in a
// splice 8 mm wide (each vertical bar), 16 mm tall, between two arms; glue it (CA). The face on the bed is flat: the
// foot blocks no longer stick out 1 mm on that side, the pin block reaches it (it was 0.5 mm short). Pin holes 2.9 mm
// (press) for the 3 x 20 frame pin (in the pin block, teardrop: horizontal in the print) and the 3 x 8 guide stubs.
gd_mid = [v18_sz(199), v18_sz(216.5)];                     // dovetail seam Z [back, front] (between two arms on both bars)
gd_sw = 4;                                 // splice half width (X)
function gd_bed(s) = s==0 ? -1 : 1;        // the side that lies on the bed (-Y for the back frame, +Y for the front)
function gd_zb(s) = [zBarB, zBarF][s];
function gd_yp(s) = [pg_yb0 - d2, pg_yf0 + d2][s];
// dovetail in the XZ plane (loop_test.scad dove(): neck 3, head 4.4, 5 long), c = clearance
module gd_dove(s, x, c) let(zb=gd_zb(s)) translate([x, zb+2, gd_mid[s]]) rotate([90,0,0])
    linear_extrude(4) polygon([[-1.5-c, -0.01], [-2.2-c, 5+c], [2.2+c, 5+c], [1.5+c, -0.01]]);
module gd_body(s) let(zb=gd_zb(s), yp=gd_yp(s), sb=gd_bed(s)) difference() {
    union() {
        for (x=xB) {
            translate([x-1.5, zb-1.5, yG]) cube([3, 3, yS-yG]);
            translate([x-2.5, sb < 0 ? zb-1.5 : zb-2.5, yG-2.6]) cube([5, 4, 5.6]);               // foot block: flush on the bed side, 0.6 lower (wall under the stub hole)
            translate([x-gd_sw, zb-1.5, gd_mid[s]-8]) cube([2*gd_sw, 3, 16]);                         // splice
        }
        // top bar. v1.7 FEA (stack side): the 3 x 3 bar took a 2 N push at its middle with SF 0.08 and 11 mm; now 8 deep
        // (toward the stack, flush with the bed face) and 12 tall (Z 372.15..384.15): over the top ramp's arms and parts
        difference() { translate([xB[0]-1.5, sb < 0 ? zb-1.5 : zb-6.5, yS-10.5]) cube([xB[1]-xB[0]+3, 8, 10.5]);   // v1.8: 10.5 tall (was 12): the comb lifts 3.5 mm to free the carriers (J15)
                       if (sb > 0) translate([69, zb-7, yS-11]) cube([22, 10, 9.5]); }        // (front: E2's pot passes under X 70..90 at gap 16.5)
        translate([xB[0]-1.5, zb-1.5, yG-1.5]) cube([xB[1]-xB[0]+3, 3, 3]);                      // v5b: bottom bar
        translate([pg_xp-4, sb < 0 ? yp-3.5 : yp-3, 7.4]) cube([8, 6.5, yG+1.5-7.4]);             // pin block (v1.6: 6.5 deep, flush on the bed side)
        // arms: from each carrier's outer face to its frame bar, just under the rods
        for (i=[0:n-1], x=xB) if ((i%2==0) == (s==0)) let(z=ballZat(i,x)-ballZ0+12-4, back=(i%2==0),
            yo = back ? planeY[0]+cc12/2-rod_cc(gap)-2.6 : planeY[1]-cc12/2+rod_cc(gap)+2.6) {
            // v1.7 FEA (stack side): 4 x 4 arms (were 2 x 2: SF 0.14 at the arm roots for a 2 N push on the top bar)
            if (back) translate([x-2, zBarB+1.5, z-2]) cube([4, yo-zBarB-1.5, 4]);
            else      translate([x-2, yo, z-2]) cube([4, zBarF-1.5-yo, 4]);
            // v1.7 (J15): a glue pad 8 x 6 mm on the arm's end, flat on the carrier's outer face (48 mm2, CA); 45 deg taper
            // from the 2 x 2 arm, so it prints with no support (arms up)
            // v1.8 (J15): the pad (8 x 2.5 x 6) carries a dovetail groove (closed at the top: it hangs on the carrier's rib), no CA
            if (back) hull() { translate([x-1, yo-5.5, z]) cube([2, 0.01, 2]); translate([x-4, yo-2.5, z-2]) cube([8, 2.5, 6]); }
            else      hull() { translate([x-1, yo+5.5-0.01, z]) cube([2, 0.01, 2]); translate([x-4, yo, z-2]) cube([8, 2.5, 6]); }
        }
    }
    // frame pin hole (Z), teardrop: its point is up in the print (away from the bed side)
    translate([pg_xp, yp, 7.4-1]) linear_extrude(yG+1.5-7.4+2) union() { circle(d=pin_press_lying, $fn=fit_fn); rotate(sb < 0 ? 45 : 225) square(pin_press_lying/2); }   // v1.7t: lying press (fit audit)
    // v1.7: the guide stub holes are gone (the stubs guided nothing); the X key of the carriers holds the frame in X
    v18_j15_grooves(s);
}
// the grooves, drawn in the carrier's own (2.5 deg tilted) frame so they fit the ribs; open at the pad's bottom, closed 0.2 mm
// over the rib top (the comb hangs on the ribs)
module v18_j15_grooves(s) for (i=[0:n-1], x=xB) if ((i%2==0) == (s==0))
    at_ramp(i) translate([rlx(i, x) < 100 ? v18_j15_x[0] : v18_j15_x[1], -rod_cc(gap), 4+v18_j15_z[1]+0.2-12])
        linear_extrude(12) polygon(v18_dove(v18_j15_c, -2.6+0.01, -1.8-v18_j15_c));
module gd_frame_lo(s) intersection() { gd_body(s); union() { translate([-50, -60, -1]) cube([400, 200, gd_mid[s]+1]); for (x=xB) gd_dove(s, x, 0); } }
module gd_frame_hi(s) difference() { gd_body(s); translate([-50, -60, -1]) cube([400, 200, gd_mid[s]+1]); for (x=xB) gd_dove(s, x, 0.15); }
module gd_frame(s) let(zb=gd_zb(s), yp=gd_yp(s)) {
    color("#59a5c4") { gd_frame_lo(s); gd_frame_hi(s); }
    color("silver") translate([pg_xp, yp, 2.6]) cylinder(d=3, h=20, $fn=16);                      // v5b: 3 x 20 steel pin, down into the slide's cam slot
}
// the slide (moves along X by pg_s(gap)); in slide coordinates u = X at gap 12
module pg_slide(g=gap) pg_slide_s(pg_s(g));
module pg_slide_s(s) color("#d6a648") translate([s, 0, 0]) difference() {
    union() {
        translate([40, -6.6, pg_z[0]]) cube([66, 11.7, pg_z[1]-pg_z[0]]);           // back strip (back cam slot)
        translate([40, 48.9, pg_z[0]]) cube([66, 11.7, pg_z[1]-pg_z[0]]);           // front strip (front cam slot)
        for (u=[40, 98]) translate([u, -6.6, pg_z[0]]) cube([8, 67.2, pg_z[1]-pg_z[0]]);   // cross bars
        translate([40, pg_guideY-6, pg_z[0]]) cube([120, 12, pg_z[1]-pg_z[0]]);     // centre strip (guide slot)
        translate([40, 60, pg_z[0]]) cube([8, 40, pg_z[1]-pg_z[0]]);                // arm forward over the peg plate
        translate([40, 95, pg_z[0]]) cube([8, 5, 5.4]);                              // finger rib (Z up to 7.6: Elevator 1's plate gussets start at Z 8 over it)
    }
    // cam slots: the pin's path in slide coordinates (straight: d2 is linear in the travel)
    for (q=[[pg_yb0, -1], [pg_yf0, 1]]) hull() for (s=[0, 9*pg_p]) translate([pg_xp-s, q[0]+q[1]*pg_k*s, 0]) cylinder(d=pg_slot, h=20, $fn=20);
    hull() for (u=[pg_guide[0]-9*pg_p, pg_guide[1]]) translate([u, pg_guideY, 0]) cylinder(d=3.5, h=20, $fn=16);   // guide slot
    for (y=pg_rowY) translate([pg_uA, y, 0]) cylinder(d=pin_slip, h=20, $fn=fit_fn);    // index holes (rows A, B) (v1.7t: pin_slip)
    for (y=[[65.5, 73.5], [86.5, 94.5]]) translate([41.5, y[0], 0]) cube([5, y[1]-y[0], 20]);   // windows: the set number shows through
}
// fixed parts: the peg plate (on the base, 2 M3 + nuts through the base), the guide bolts with spacers, washers, nuts
module gd_static() {
    color("#4a5360") difference() {
        translate([38, 64, 0]) cube([68, 32, 2]);
        for (row=[0,1], k=[0:(row==0 ? 9 : 8)]) translate([pg_holeX(row, k), pg_rowY[row], -1]) cylinder(d=pin_slip, h=4, $fn=fit_fn);   // (v1.7t: pin_slip)
        for (x=[41, 103]) translate([x, 92.5, -1]) cylinder(d=m3_clear, h=4, $fn=16);
        // numbers (engraved 0.6 mm, paint them): row A under its holes, row B over them; read from the front
        for (k=[0:9]) translate([pg_holeX(0, k), 69.5, 1.4]) linear_extrude(1) rotate(90) text(str(12 + 0.5*k), size=2.4, halign="center", valign="center", font="Liberation Sans:style=Bold");
        for (k=[0:8]) translate([pg_holeX(1, k), 90.5, 1.4]) linear_extrude(1) rotate(90) text(str(12.25 + 0.5*k), size=2.4, halign="center", valign="center", font="Liberation Sans:style=Bold");
    }
    for (x=pg_guide) translate([x, pg_guideY, 0]) {
        color("#4a5360") difference() { cylinder(d=7, h=pg_z[0], $fn=24); translate([0,0,-1]) cylinder(d=m3_clear, h=5, $fn=16); }   // spacer
        color("#4a5360") difference() { cylinder(d=3.3, h=pg_z[1]+0.2, $fn=16); translate([0,0,-1]) cylinder(d=3, h=9, $fn=12); }      // sleeve through the slot
        color("silver") { translate([0,0,-6]) cylinder(d=3, h=16, $fn=12);   // (v1.7t: M3 x 16, was x 14) translate([0,0,pg_z[1]+0.2]) cylinder(d=7, h=0.5, $fn=20);
                          translate([0,0,pg_z[1]+0.7]) cylinder(d=6.35, h=2.4, $fn=6); }                 // M3 x 16 (v1.7t) from under the base, washer, nut
    }
}
// the lock pin (3 x 20 steel) in the hole for the current gap (shown only when the gap is a peg setting)
function pg_hole_of(g) = let(n2=round(4*(g-12))) [n2%2, floor(n2/2)];          // [row, n] of a peg setting
function pg_travel(row, k) = pg_p*k + (row == 1 ? pg_p/2 : 0);                   // slide travel that brings the index hole over it
module pg_lockpin(g=gap, d=3) if (pg_ongrid(g)) let(h=pg_hole_of(g))
    color("silver") translate([pg_holeX(h[0], h[1]), pg_rowY[h[0]], 0]) cylinder(d=d, h=20, $fn=16);
module stack_no_slide() { for (i=[0:n-1]) ramp(i); for (i=[0:n-2]) uturn(i); frame(); gd_frame(0); gd_frame(1); gd_static(); }
// ---------------- ladder channels (fix c: one per elevator) ----------------
// A cage of 4 steel rods (3 mm) the ball falls down in; one carriage locks onto an index hole with a pin and turns the
// ball out through the side that faces the stack, over a short lip into the cup's ladder slot. Channel coordinates:
// local -X faces the stack. RIGHT channel (E2): world (268, 38), feeds the right-end cups (odd ramps 2..18).
// LEFT channel (E1): world (-8.2, 16), mirrored, feeds the left-end cups (even ramps 3..19).
chHalf = 11.75;                                               // rod offset from the centre (ball 19.05 falls inside)
CH = [ [268, 38, 70, v18_tz(367), [for (i=[1:2:n-2]) i], false],      // right: x, y, bottom, top, ladder positions, top ring?
       [-8.2, 16, 52, v18_tz(355.4), [for (i=[2:2:n-1]) i], true] ];  // left   (right top: the E2 tray's end clips onto the rods)
chX = CH[0][0]; chY = CH[0][1]; chZ0 = CH[0][2]; chZ1 = CH[0][3];
function cupEntryZ(i) = entry(i)[2] + 4;                      // ball centre where a carriage hands over (into ramp i's cup)
module at_ch(s) translate([CH[s][0], CH[s][1], 0]) mirror([s==1 ? 1 : 0, 0, 0]) children();
// v1.6 (print fix): rod holes (3.0 mm press) in every ring; the cage prints lying on its side on the strip's outer face
// (+X), so the right cage's bottom ring gets 2 mm more on its +X bar (flush with the strip: it was 2 mm over the bed);
// the left cage's top ring is a separate flat print (it touched the strip over 1 mm only), the strip ends under it.
// In the side pose the rod holes are horizontal: teardrops, point up (-X).
module cage_ring(s, z, ext=0, flat=false) difference() {
    translate([-chHalf-4, -chHalf-4, z]) cube([2*chHalf+8+ext, 2*chHalf+8, 6]);
    translate([-chHalf+2, -chHalf+2, z-1]) cube([2*chHalf-4, 2*chHalf-4, 8]);
    translate([-chHalf-5, -9, z-1]) cube([8, 18, 8]);                       // stack side open: the carriage lip passes
    for (sx=[-1,1], sy=[-1,1]) translate([sx*chHalf, sy*chHalf, z-1])
        linear_extrude(8) union() { circle(d=flat ? pin_press : pin_press_lying, $fn=fit_fn); if (!flat) rotate(135) square(pin_press_lying/2); }   // v1.7t: press by print pose (bottom rings lie, the top ring 23b stands)
}
module cage_strip(s, z0, z1) {
    // index strip with a hole for every ladder position, on the outer side
    // (v3) strip 2 mm further in: the v3 cup's side plate passes at Y 54.4 (right channel, world)
    // v4: the left channel's strip is on its +y side (not the outer -X side): the device is 4 mm shorter
    if (s==0) difference() { translate([chHalf+2, chHalf-3, z0]) cube([4, 7, z1-z0-5]);   // stops 5 below the top (E2's cup passes)
        for (i=CH[s][4]) translate([chHalf+1, chHalf+1, cupEntryZ(i)+1]) rotate([0,90,0]) cylinder(d=pin_slip, h=8, $fn=fit_fn); }   // v1.7t: slip, standing (35 prints on the strip's outer face)
    else difference() { translate([chHalf-3, chHalf+2, z0]) cube([7, 4, z1-z0-6]);         // v1.6: ends under the top ring (was z1 - 5)
        for (i=CH[s][4]) translate([chHalf+1, chHalf+1, cupEntryZ(i)+1]) rotate([-90,0,0]) linear_extrude(8) union() { circle(d=pin_slip, $fn=fit_fn); rotate(135) square(pin_slip/2); }; }   // v1.7t: slip, lying (23a), teardrop up
}
module cage_print(s) let(z0=CH[s][2], z1=CH[s][3]) { cage_ring(s, z0, s==0 ? 2 : 0); cage_strip(s, z0, z1); }   // one printed piece
// v1.7 (J41, J43): the left top ring gets a tab back to the back panel (world X -23..-15, Y -9..0.25) with an M3
// heat-set insert (M3 x 12 from behind the panel), and 2 press holes for the 3 x 12 pins that locate the E1 tray's drop end
module cage_topring(s) let(z1=CH[s][3]) difference() {
    union() { cage_ring(s, z1-6, 0, flat=true); if (s==1) translate([5.8, -25, z1-6]) cube([10, 9.5, 6]); }   // (v1.7t: tab 10 wide for the nut)
    // v1.7t (no heat-set inserts): M3 x 12 from behind the panel, nut dropped into a slot from the top of the tab (flats
    // up and down, prints open at the top: no overhang)
    if (s==1) { translate([10.8, -25-0.01, z1-3]) rotate([-90,0,0]) cylinder(d=m3_clear, h=9.6, $fn=16);
                translate([10.8, -21.4, z1-3]) rotate([-90,0,0]) cylinder(d=m3_nut, h=2.6, $fn=6);
                translate([10.8-m3_nut/2, -21.4, z1-3]) cube([m3_nut, 2.6, 4]);
                for (x=[-6, 6]) translate([x, 12.75, z1-7]) cylinder(d=pin_press, h=8, $fn=fit_fn); }
}
module cage(s) at_ch(s) let(z0=CH[s][2], z1=CH[s][3]) {
    // v1.7: the corner rod (+x, -y) goes 8 mm further down, into the cage stand (press)
    color("silver") for (sx=[-1,1], sy=[-1,1]) let(zz=z0-(sx==1 && sy==-1 ? 8 : 0)) translate([sx*chHalf, sy*chHalf, zz]) cylinder(d=3, h=(s==0 ? e2rodtop : z1)-zz, $fn=12);   // v5b: the right channel's rods go 3 mm higher, into the E2 funnel's sockets
    color("#4a5360") { cage_print(s); if (CH[s][5]) cage_topring(s); }
}
// v1.6 (print fix): the v1.5 carriage printed as 4 loose pieces (the stack-side opening and the index-strip notch cut
// the sleeve in two; the deflector and the lip touched nothing). Now one body, the ball's path unchanged:
//  - webs: the deflector plate goes on to both side walls (|X| < 8, clear of the rods);
//  - a fill under the deflector's high (+X) end joins it to the +X wall (the deflector's top face does not change);
//  - a 45 deg wedge under the deflector's low (-X) end joins the lip to it. The lip's inner end is cut back to the
//    same 45 deg (the ball leaves the deflector edge with its centre at X -17.8, past the lip: it never touches there).
// Print pose: on its +X wall (rotate [0, 90, 0]); see v16_stack_parts.scad.
car_a = -35;                                                     // deflector tilt
module car_plate(y0, y1, z0, z1) rotate([0, car_a, 0]) translate([-14, y0, z0]) cube([28, y1-y0, z1-z0]);
function car_pt(x, zl) = [cos(car_a)*x + sin(car_a)*zl, 2 - sin(car_a)*x + cos(car_a)*zl];   // deflector local (x, z) -> carriage (X, Z)
module carriage_body(s) {
    difference() {                                               // sleeve around the cage
        union() {
            difference() { translate([-chHalf-4, -chHalf-4, -6]) cube([2*chHalf+8, 2*chHalf+8, 14]);
                           translate([-chHalf-2, -chHalf-2, -7]) cube([2*chHalf+4, 2*chHalf+4, 16]); }
            // v1.6 fill: the deflector's +X end to the +X wall, under the deflector's top plane
            intersection() {
                translate([0, 0, 2]) rotate([0, car_a, 0]) translate([-40, -chHalf+1.6, -40]) cube([80, 2*chHalf-3.2, 41.5]);
                translate([9, -chHalf+1.6, -6]) cube([chHalf+4-9, 2*chHalf-3.2, 14]);
            }
        }
        translate([-chHalf-5, -9, -7]) cube([8, 18, 16]);
        if (s==0) translate([chHalf+1.5, chHalf-3.5, -7]) cube([5, 8, 16]);      // notch: slides along the index strip
        else      translate([chHalf-3.5, chHalf+1.5, -7]) cube([8, 5, 16]);
    }
    // v1.7 (J42, J63): the index pin went through the strip only: nothing held the carriage. Now an ear wraps round the
    // strip's outer face; the pin (3 x 8.2) passes the ear (3.30 slip) and the strip: the carriage hangs on the pin.
    difference() {
        if (s==0) union() { translate([chHalf+4-0.01, -chHalf-4, -6]) cube([22.5-chHalf-4+0.01, 2*chHalf+0.5, 14]);
                            translate([18.5, chHalf-3.75, -6]) cube([4, 8.25, 14]); }
        else      union() { translate([-chHalf-4, chHalf+4-0.01, -6]) cube([2*chHalf+0.5, 22.5-chHalf-4+0.01, 14]);
                            translate([chHalf-3.75, 18.5, -6]) cube([8.25, 4, 14]); }
        // v1.7t (fit audit): slip. 36 (s 0): the hole lies in the print (on the -y wall): teardrop, point to +y (up in the
        // print); 24 (s 1): it stands
        if (s==0) translate([chHalf+1, chHalf+1, 1]) rotate([0,90,0]) linear_extrude(14) union() { circle(d=pin_slip, $fn=fit_fn); rotate(45) square(pin_slip/2); }
        else      translate([chHalf+1, chHalf+1, 1]) rotate([-90,0,0]) cylinder(d=pin_slip, h=14, $fn=fit_fn);
    }
    // deflector: a 35 deg ramp across the cage that sends the ball out of the stack side into the cup's slot
    // (v3) 4 mm thick with a flush EVA pad (20 x 16 x 2) where the ball lands: it can fall up to 29 cm (2.4 m/s, sim)
    translate([0, 0, 2]) difference() {
        union() {
            car_plate(-chHalf+1.6, chHalf-1.6, -2.5, 1.5);
            intersection() { car_plate(-chHalf-3, chHalf+3, -2.5, 1.5); translate([-8, -chHalf-3, -8]) cube([16, 2*chHalf+6, 14]); }   // v1.6 webs
        }
        rotate([0, car_a, 0]) translate([-10.2, -8.2, -0.6]) cube([20.4, 16.4, 2.2]);   // pocket 0.2 mm bigger all round than the pad
    }
    // short lip from the cage to the cup's outer wall (the cup wall is 17.6 mm from the channel centre)
    // v1.6: the lip's inner part is a wedge to the deflector's low end: its underside at 45 deg from the low edge A,
    // its top from the edge B down to the lip (behind the edge: the ball leaves B with its centre at X -17.8)
    // (A and B are 0.2 mm inside the plate's faces: no shared plane)
    let(A=car_pt(-14+0.3, -2.3), B=car_pt(-14+0.3, 1.3), zt=-ball_r, zl=-ball_r-2, E=[-14.5, zt], F=[-14.5, zl],
        C=[A[0]-(A[1]-zl), zl]) {
        rotate([90,0,0]) linear_extrude(16, center=true) polygon([A, B, E, [-17.3, zt], [-17.3, zl], C]);   // lip + wedge, one outline
    }
}
module carriage(s, i) at_ch(s) let(z=cupEntryZ(i)) {
    color("#d08a4a") translate([0, 0, z]) carriage_body(s);
    color("silver") if (s==0) translate([chHalf+1.8, chHalf+1, z+1]) rotate([0,90,0]) cylinder(d=3, h=8.2, $fn=12);     // index pin (in the sleeve's height)
    else translate([chHalf+1, chHalf+1.8, z+1]) rotate([-90,0,0]) cylinder(d=3, h=8.2, $fn=12);
    color("#2b2b2b") translate([0, 0, z+2]) rotate([0, -35, 0]) translate([-10, -8, -0.5]) cube([20, 16, 2]);
}

// ---------------- elevator tops: fixed catch ledges and trays (v5b) ----------------
// v4/v5 had a hinged catch flap under each cup's top position: the rising cup lifted it, and at the top it rested ON the
// cup (the simulator found it, OpenSCAD confirmed it). v5b: nothing moves at the hand-over. A fence on the cup floor
// turns the ball off the floor's pour-side edge; it drops about 5 mm onto a FIXED ledge that starts 1 mm outside the cup
// side plate. No part of either elevator is ever on that side of the plate, so the cup passes the ledge at every angle.
//  - E1 (pours to +Y): a V-shaped ledge (Y 116.6..129, X 256..284) into the front tray's mouth at (270, 128.5).
//  - E2 (pours to -Y): a FUNNEL (a 10.9 deg cone round the right channel's centre, X 252..298, Y 24..53.4) with the drop
//    hole into the right channel at (268, 38). It sits on the channel's 4 rods.
E1top = [245.8, 103, 0] + E1_topseat();  E2top = [262, 67, 0] + E2_topseat();   // ball on the seat of the tipped cup at the top
E1end = [245.8, 103, 0] + E1_topend();   E2end = [262, 67, 0] + E2_topend();     // ... and at the open end of its floor (v4 pour; kept for reference)
E1O = [245.8, 103, 0]; E2O = [262, 67, 0];
E1pour = [for (q=E1_pour()) E1O + q];                                    // seat -> fence -> over the edge -> ledge -> tray mouth
E1tr = [for (q=E1_rtray()) E1O + q];
E1land = E1pour[len(E1pour)-3];                                         // where the ball lands on the ledge
// tray axis points (ball centre = axis - 0.8 when it rolls on the trough floor)
E1tray = [E1tr[0], [E1tr[0][0], 135, E1tr[0][2]-0.4], [230, 135, v18_tz(379.4)],   // v5b: mouth at X 270 (was 277), 1.4 mm higher
          [100, 135, v18_tz(375.6)], [-8.2, 135, v18_tz(372.1)],
          [-8.2, 100, v18_tz(370.6)], [-8.2, 50, v18_tz(368.6)], [-8.2, 16, v18_tz(366.7)]];
// the ledge is printed with the tray; it is cut back where the tray's first two runs pass (its -X half would rise into
// the leftward run's ball path)
module e1_ledge() difference() { union() { translate(E1O) E1_ledge(); e1_dot_boss(); }
    for (k=[0:1]) hull() { translate(E1tray[k]-[0,0,0.8]) sphere(r=ball_r+0.5, $fn=32); translate(E1tray[k+1]-[0,0,0.8]) sphere(r=ball_r+0.5, $fn=32); }
    e1_dot_pocket(); }
// v1.7r (FEA, ledge impact SF about 1.7 at 0.5 m/s): an EVA foam dot (10 x 2 mm, as the trough pads) where the ball
// lands on the ledge. The ledge is a 2 mm slab: a boss under it (d 14, 2 mm, clipped to the ledge's footprint: Y >= 116.7,
// the E1 cup's side plates end at Y 115.6) makes it 4 mm there, and a 2 mm pocket that follows the ledge's V top takes
// the dot flush. The ball centre lands at E1land (268.9, 121.8): contact about (269.6, 120.6) on the 7 / 4 deg slopes;
// the dot is centred at Y 122 so the pocket keeps 0.2 mm of ledge at the inner edge (Y 116.6).
e1dot_c = [269.6, 122.0]; e1dot_d = 10.4;
function e1lz(x, y) = E1O[2] + E1_ledgez(x - E1O[0], y - E1O[1]);
e1lxm = E1O[0] + E1_ledge_xm();                                   // the V line (world X 270)
// band between the ledge top + lo and + hi (the two plane halves of the V), over an X / Y box
module e1_band(lo, hi, xr, yr) for (xs=[[xr[0], e1lxm], [e1lxm, xr[1]]]) hull() for (x=xs, y=yr) translate([x, y, e1lz(x, y)+lo]) cube([0.01, 0.01, hi-lo]);
module e1_dot_boss() intersection() { translate([e1dot_c[0], e1dot_c[1], 300]) cylinder(d=14, h=120, $fn=48); e1_band(-4, -1.9, [260, 280], [116.7, 128.4]); }
module e1_dot_pocket() intersection() { translate([e1dot_c[0], e1dot_c[1], 300]) cylinder(d=e1dot_d, h=120, $fn=48); e1_band(-2, 4, [260, 280], [110, 135]); }
module e1_dot() color("#2b2b2b") intersection() { translate([e1dot_c[0], e1dot_c[1], 300]) cylinder(d=pad_dot, h=120, $fn=48); e1_band(-2, 0, [260, 280], [110, 135]); }
// E2 funnel: cone round H (the right channel's centre), ball centre 379.2 at H (as the v5 tray end), slope set so the
// funnel is 5 mm under the floor's pour edge where the ball lands
e2H = [268, 38]; e2Hz = v18_tz(379.2) - ball_r - 0.15;                            // funnel top at the cone's tip (the hole's centre)
e2L0 = [E2O[0]+E2_edge()[0]+7.5, E2O[1]+E2_edge()[1]-8.6];               // landing estimate (the E1 rig: 7.5 on, 8.6 out)
e2tb = (E2_edge()[2] - 5 - e2Hz)/norm(e2L0-e2H);                         // tan of the cone slope
function e2fz(x, y) = e2Hz + e2tb*norm([x-e2H[0], y-e2H[1]]);           // funnel top z, world
e2f_rig = function(x, y) e2fz(x+E2O[0], y+E2O[1]);
e2sock = v18_tz(365.5); e2rodtop = v18_tz(370);                                         // sockets start over the top carriage (its sleeve reaches 365.1); the right channel's rods go up to 370 (were 367)
e2fx = [252, 298]; e2fy = [24, 67-ledge_v0_w()]; e2hole = 10.6;
function ledge_v0_w() = 13.6;                                            // = ledge_v0 in elevator1_test.scad (variables do not cross "use")
E2land = E2O + E2_land(e2f_rig);
E2pour = [for (q=E2_pour(e2f_rig, [])) E2O + q];                         // seat -> fence -> over the edge -> lands on the funnel
E2tray = [for (q=[[E2land[0], E2land[1]], (([E2land[0], E2land[1]]+e2H)/2), e2H]) [q[0], q[1], e2fz(q[0], q[1]) + ball_r + 0.15 + 0.8]];   // straight down the cone to the hole
module e2_funnel() color("#d08a4a") {
    difference() {
        union() {
            intersection() {
                translate([e2H[0], e2H[1], 0]) rotate_extrude($fn=120) polygon([[0, e2Hz-2], [70, e2Hz-2+70*e2tb], [70, e2Hz+70*e2tb], [0, e2Hz]]);
                translate([e2fx[0], e2fy[0], 300]) cube([e2fx[1]-e2fx[0], e2fy[1]-e2fy[0], 200]);
            }
            // rims (6 mm over the funnel) on the outer edges: +X (size box edge) and -Y
            // (v1.6: the rims start 0.1 mm above the funnel's underside: v1.5 shared that edge and left 4 zero-area slivers)
            hull() for (y=e2fy) translate([e2fx[1]-1.6, y-(y==e2fy[1] ? 0.01 : 0), e2fz(e2fx[1], y)-1.9]) cube([1.6, 0.01, 7.9]);
            hull() for (x=e2fx) translate([x-(x==e2fx[1] ? 0.01 : 0), e2fy[0], e2fz(x, e2fy[0])-1.9]) cube([0.01, 1.6, 7.9]);
            // sockets on the 4 rods of the right channel (the rods end at Z 367; 3 mm into the socket)
            for (sx=[-1,1], sy=[-1,1]) let(q=[e2H[0]+sx*chHalf, e2H[1]+sy*chHalf]) translate([q[0], q[1], e2sock]) cylinder(d=7, h=e2fz(q[0], q[1])-e2sock-1, $fn=24);
            e2f_hanger();
        }
        e2f_hanger_holes();
        translate([e2H[0], e2H[1], 300]) cylinder(r=e2hole, h=200, $fn=48);                   // drop hole
        // v1.7t (fit audit): the rods are pressed in; the sockets lie in the print (on its side, Y +90): teardrop, point to
        // world -X (up in the print)
        for (sx=[-1,1], sy=[-1,1]) translate([e2H[0]+sx*chHalf, e2H[1]+sy*chHalf, e2sock-0.1]) linear_extrude(e2rodtop-e2sock+0.1) union() { circle(d=pin_press_lying, $fn=fit_fn); rotate(135) square(pin_press_lying/2); }
    }
}
function down(p) = [for (q=p) q-[0,0,0.8]];
module tray(s) color("#d08a4a") if (s==1) { tray_e1_a(); tray_e1_b(); }
                                 else e2_funnel();
// v1.6 (print fix): the E1 tray (305 x 146 mm) does not fit the bed. Two pieces, split across the front run at X 100
// (the slope break; the front run alone is 296 mm long, so a split at the elbow would still not fit):
//  A = mouth, ledge, label and the front run to X 100; B = the front run from X 100, the elbow and the -Y run.
// Both print channel-up (no support in the ball channel). A flat keel (45 deg flanks, no lower than the trough's
// bottom) fills the belly under the round trough, so it sits on the bed. Joint: the trough butts at X 100; an ear
// on each side (X 88..112, out to 18 mm from the axis, bottom to lip height) is cut by a 45 deg scarf plane (A below,
// B above: both faces print without support) and pinned with one 3 x 10 mm steel pin per ear (2.9 mm holes,
// vertical). Glue the scarf (CA).
tr_x = 100; tr_ear = [88, 112]; tr_ey = [5, 18];
function tr_axz(x) = x >= tr_x ? v18_tz(375.6) + (x-tr_x)*(379.4-375.6)/130 : v18_tz(375.6) + (x-tr_x)*(375.6-372.1)/108.2;   // axis Z on the front run (Y 135)
tr_zc = tr_axz(tr_x) - 12.725/2 - 1;                                     // scarf plane height at X 100 (middle of the ear)
// keel: a flat bottom 10.5 mm wide with 45 deg flanks to the trough's outer surface; its top stays inside the wall
// (the flank's top points are 0.4 mm inside the outer surface: no shared vertex with the round trough's facets)
// pl = the print plane (world z of the bed under the piece, a function of x, y): the keel bottom goes down to it
// (piece B: at most 0.36 mm below the v1.5 trough bottom); undef = the keel bottom is 12.725 mm under the axis.
module tray_kslice(q, a, pl, ro, p) let(zb=function(u) is_undef(pl) ? -ro : pl(q[0]-u*sin(a), q[1]+u*cos(a)) - q[2], zl=zb(-(2*p-ro)), zr=zb(2*p-ro))   // (at the bottom corners)
    translate(q) rotate([0,0,a]) rotate([90,0,90]) linear_extrude(0.01, center=true)
        polygon([[-(2*p+zl), zl], [2*p+zr, zr], [p, -p], [0, -ro+1.2], [-p, -p]]);
function tray_hd(pts, k) = let(d=pts[k+1]-pts[k]) atan2(d[1], d[0]);
module tray_keel(pts, pl=undef, rin=ball_r+0.8, wall=2.4) let(ro=rin+wall, p=(ro-0.4)*sin(45)) {
    for (k=[0:len(pts)-2]) hull() { tray_kslice(pts[k], tray_hd(pts, k), pl, ro, p); tray_kslice(pts[k+1], tray_hd(pts, k), pl, ro, p); }
    for (k=[1:len(pts)-2]) hull() { tray_kslice(pts[k], tray_hd(pts, k-1), pl, ro, p); tray_kslice(pts[k], tray_hd(pts, k), pl, ro, p); }   // corners: under the round turn
}
tr_bB = [(375.6-372.1)/108.2, (372.1-366.7)/119];        // piece B's print plane: slopes along X and Y
function tr_plB(x, y) = v18_tz(375.6) - 12.725 + tr_bB[0]*(x-tr_x) + tr_bB[1]*(y-135);
module tray_e1_full() {
    trough_chain(E1tray, open_start=true, drop_end=true, pads=[1, 4]);
    difference() { union() { tray_keel([for (k=[0:3]) E1tray[k]]); tray_keel([for (k=[3:len(E1tray)-1]) E1tray[k]], function(x, y) tr_plB(x, y)); }
                   let(m=len(E1tray)-1) translate(E1tray[m]-[0,0,40]) cylinder(r=ball_r+0.8+0.3, h=80, $fn=24);
                   tray_e1_chan(0.3, [0:len(E1tray)-2]); }      // the hull of the keel outline fills its notch: keep it 0.3 mm under the channel
    e1_ledge(); e1_label();
    for (x=v17_trayx) tray_tab(x);
}
module tray_e1_chan(g=0.3, ks=[2:3]) for (k=ks) hull() { translate(E1tray[k]) sphere(r=ball_r+0.8+g, $fn=20); translate(E1tray[k+1]) sphere(r=ball_r+0.8+g, $fn=20); }
module tray_e1_outer() { for (k=[2:3]) hull() { translate(E1tray[k]) sphere(r=ball_r+0.8+2.4, $fn=20); translate(E1tray[k+1]) sphere(r=ball_r+0.8+2.4, $fn=20); }
                         tray_keel([E1tray[2], E1tray[3]]); tray_keel([E1tray[3], E1tray[4]], function(x, y) tr_plB(x, y)); }
// ears: A's part (under the scarf) has its bottom on A's print plane (the axis - 12.725 line), B's part (over the
// scarf) on B's print plane (tilted in Y by the -Y run's slope): each piece sits flat on the bed
module tray_e1_ears(side) difference() {
    for (sg=[-1,1]) let(ys=sg > 0 ? [135+tr_ey[0], 135+tr_ey[1]] : [135-tr_ey[1], 135-tr_ey[0]]) {
        if (side == "A") for (xs=[[tr_x-6, tr_x], [tr_x, tr_ear[1]]]) hull() for (x=xs) translate([x-0.005, ys[0], tr_axz(x)-12.725]) cube([0.01, ys[1]-ys[0], 12.725-2]);
        if (side == "B") hull() for (x=[tr_ear[0], tr_x+6], y=ys) translate([x-0.005, y-0.005, tr_plB(x, y)]) cube([0.01, 0.01, tr_axz(x)-2-tr_plB(x, y)]);
    }
    tray_e1_chan();
    for (sg=[-1,1]) translate([tr_x, 135+sg*15, 300]) cylinder(d=pin_press, h=100, $fn=fit_fn);   // pin holes (v1.7t: press, standing)
    // on the other piece's side of X 100 an ear keeps only its outer part (|dy| >= 12.8, outside that piece's trough):
    // no cavity in the ear, so no overhang over the other piece's trough when it prints alone
    translate([side == "A" ? tr_x-50 : tr_x, 135-12.8, 300]) cube([50, 25.6, 200]);
}
module tr_below() translate([tr_x, 135, tr_zc]) rotate([0,-45,0]) translate([-100,-100,-200]) cube([200, 200, 200]);   // under the scarf plane
module tray_e1_a() {   // mouth side (X >= 100)
    intersection() { tray_e1_full(); translate([tr_x+0.006, -100, 0]) cube([400, 400, 600]); }   // (6 um off the keel slices at X 100)
    intersection() { tray_e1_ears("A"); tr_below(); }
}
// B's drop end: the end cap's ring round the drop hole had a flat (horizontal) bottom edge 7 mm over the bed; cut
// under a 45 deg plane that rises away from the end point, so it prints as a 45 deg overhang (the ball falls through
// the hole: it never touches the cut part)
module tray_e1_endcut() let(e=E1tray[len(E1tray)-1]) translate([e[0]-60, e[1], e[2]-12.725]) rotate([-45,0,0]) translate([0, -100, -100]) cube([120, 200, 100]);
module tray_e1_b() {   // elbow side (X < 100)
    difference() { intersection() { tray_e1_full(); translate([tr_x-400-0.006, -100, 0]) cube([400, 400, 600]); }
                   for (sg=[-1,1]) translate([tr_x, 135+sg*15, 300]) cylinder(d=pin_press, h=100, $fn=fit_fn); tray_e1_endcut();
                   at_ch(1) translate([-chHalf-4, -chHalf-4, CH[1][3]-6.01]) cube([2*chHalf+8, 2*chHalf+8, 6.01]);   // v1.7: the 0.8 mm overlap is gone: B sits ON the top ring
                   for (x=[-14.2, -2.2]) translate([x, 28.75, CH[1][3]-0.01]) cylinder(d=pin_slip, h=6, $fn=fit_fn); }   // v1.7: the 2 locating pins (slip, standing)
    difference() { tray_e1_ears("B"); tr_below(); }
}
// v5 (rule 3.j): "ELEVATOR 1 TYPE 1" in 6 mm raised text on a strip on the front of Elevator 1's top tray (the track
// at the top of the elevator), below the tray's rim, seen from the front.
function e1tz(x) = v18_tz(379.4) + (x-230)*(375.6-379.4)/(100-230);   // tray axis height along its front run (Y 135)
module e1_label() {
    hull() for (x=[120, 222]) translate([x, 147.2, e1tz(x)-12.725]) cube([0.01, 1.6, 9.925]);   // v1.6: bottom flush with the keel (was 0.33 mm higher)
    color("#f4f1ea") translate([171, 148.79, e1tz(171)-7.6]) rotate([90,0,180]) linear_extrude(0.81)
        rotate(-atan((375.6-379.4)/(100-230))) text("ELEVATOR 1  TYPE 1", size=6.2, halign="center", valign="center", font="Liberation Sans:style=Bold");
}
module tops() { tray(1); tray(0); }

// ---------------- gate, feeds, finish ----------------
// Gate box at ramp 19's end. First pass: the flap is shut and the floor slopes to the +Y door, the ball rolls out to
// the E2 feed. Second pass: the cord from E2's lever has pulled the flap open, the ball drops to the finish track.
// trough_chain: printed half-pipe along points; open top slot (ball always visible). mouth: open from above at the
// start (ball drops in); drop_end: hole down at the end (ball drops out); open_start/open_end: no end cap;
// pads: indexes of corner points that get an EVA pad pocket in the outer wall.
// EVA pads in the trough corners (same place as the pockets in trough_chain: inner face flush with the trough wall)
module trough_pads(pts, pads, rin=ball_r+0.8) color("#2b2b2b")
    for (k=pads) let(d=pts[k]-pts[k-1], u=d/norm([d[0],d[1]])) translate(pts[k]+[u[0],u[1],0]*(rin+1)) rotate([0,0,atan2(u[1],u[0])]) rotate([0,90,0]) cylinder(d=pad_dot, h=2, center=true, $fn=24);
module pads() { for (i=[0:n-2]) uturn_pad(i); trough_pads(E1tray, [1, 4]); trough_pads(E1feed, [1, 4]); trough_pads(E2feed, [4]); e1_dot(); }   // v1.7r: + the E1 ledge dot   // (the finish end cap holds the felt stop, in feeds())
pad_dot = 10.0;   // v5: EVA dot size (rail_test.scad has it too, but "use" does not import variables: v4 drew no trough pads)
// halfspace() and trough_chain() are in common.scad (v3: the test rigs use them too)
gx0 = 230; gx1 = 258; gy0 = 1; gy1 = 31; gfl = 40;            // gate box outside / floor top (v5: -Y wall 2 mm out: ramp 19's ball at gap 16.5 rubbed the -X door edge by 1.1 mm)
E2feed = [[244, 17, 49.9], [244, 26, 49.6], [243, 36, 48.5], [240, 50, 45.6], [239, 67, 39.6], [250, 67, 37.3]];   // v3: foam corner at [4] (sim: 0.38 m/s into the cup); v5: [3] 3 mm left (the diagonal clipped E2's resting cup corner by 1.7 mm)
// v5 (rule 3.c): the v4 finish track ran under the stack (X 68..244, Y 26), hidden from every side. Now it leaves
// the gate drop forward, swings right under the E2 feed and runs to the front along the right edge (X 287): nothing is
// in front of it or right of it at the end of a run (both elevators are up). Its walls end below the ball centre.
// It passes 0.6 mm under Elevator 2's resting cup (X 250..282, bottom Z 16.4): the ball only runs here after E2 lifted.
finish_pts = [[244, 17, 21], [244, 30, 20.4], [250, 40, 19.6], [266, 45, 17.8], [282, 50, 16.8], [287, 60, 16.2], [287, 100, 15.0], [287, 141, 13.6]];
finish_y = 118;                                              // v5 finish line (rule 3.f): across the track at Y 118
module gate(flap=true) {
    color("#4a5360") difference() {
        union() { translate([gx0, gy0, gfl-6]) cube([gx1-gx0, gy1-gy0, 24]); gate_lugs();
                  // v1.7 FEA (stack side): the +X bar (Z 46..52) over the window took the first-pass ball's hit (14 N est.)
                  // with SF 0.66 (2 mm thick, 16 mm span): now 5 mm thick (out to X 261)
                  translate([gx1-0.01, gy0+2, gfl+6]) cube([3.01, gy1-gy0-4, 6]);
                  gate_bar_v17r(); }
        translate([gx0+2, gy0+2, gfl]) cube([gx1-gx0-4, gy1-gy0-4, 30]);                 // inside 24 x 24
        difference() { translate([232, 6, gfl-7]) cube([23, 23, 8]);                     // drop hole to the finish (v1.7t: to the front wall, Y 29: the flap's hinge edge turns there)
                       gt_ledges(); }                                                     // v1.7t: minus the 2 ledge pads under the shut flap
        gt_hinge_holes(); gt_knuckle_room(); gate_lug_holes();
        translate([233, gate_hinge[1], gate_hinge[2]]) rotate([0, 90, 0]) cylinder(r=2.8, h=22, $fn=48);   // v1.7t: the sill's inner top corner, round the axis (the flap's hinge edge sweeps r 2.5)
        translate([gx0-1, gy0+2, gfl+2]) cube([4, gy1-gy0-4, 30]);                       // -X door: ramp 19 comes in (all gaps)
        translate([232.5, gy1-3, gfl-0.01]) cube([23, 4, 30]);                            // +Y door: out to the E2 feed (floor level)
        translate([gx1-2.5, gy0-1, gfl+12]) cube([4, gy1-gy0+2, 30]);                     // v5: +X wall ends 2 mm over the ball centre (seen from the right)
        translate([gx1-3.5, gt_win_y0, gfl-7]) cube([5, gt_win_y1-gt_win_y0, 13]);      // v5: window under the bar (Z 33..46): the drop shows from the right; (v1.7r: unchanged, Y 9)
                                                                                            // the bar (Z 46..52) still stops the first-pass ball at its centre (Z 49.8)
                                                                                            // (v1.7t: window to Y 22.5, was 25: the hinge pin hole is at Y 25.7)
    }
    if (flap) gate_flap(0);
}
// v1.7 (J77): the gate box touched nothing. Two lugs on its back wall reach the back panel (Y -9); M3 x 16 (v1.7t) from behind
// the panel into heat-set inserts. The panel is solid there (the right bay's diagonal). Lug 2 has a 45 deg underside.
// v1.7r (FEA: the first-pass hit on the +X bar, SF 0.82 at 14 N; the peak was across the layers in the -Y pillar beside
// the window, Y 3..9). The bar gets a haunch outward, X 261..265 over Y 3..19 (tapering to X 261 at Y 22.5, clear of the
// crank's counter-arm, which swings up to Z 45.3 at Y 13.5..22), its underside at 45 deg (prints with no support), and the
// -Y pillar is 2.8 mm thicker (X 258..260.8, Z 34..46, from the box bottom = the bed; 0.7 mm from guide 62's tie tab at
// X 261.5). Nothing grows in Z: the window and the wall top (the views from the right) stay as they were.
// v1.7r (FEA round 2: SF 1.53 with the first haunch; peaks at the bar's top corner on the -Y wall and the -Y pillar):
// haunch to X 266.5; the window stays at Y 9..22.5 (the right view of the drop needs it). (Corner gussets on the bar top,
// tried in round 2, moved the peak into the gusset root: SF 1.04 under the contact-patch load. Not used.)
gt_win_y0 = 9;              // (v1.7r: 10.5 and 12 were tried for a wider pillar; at 10.5 the second-pass drop was hidden from all four views 0.1 % of the k16 run. Kept at 9)
module gate_bar_v17r() {
    module sl(y0, L, w) translate([0, y0, 0]) rotate([90, 0, 0]) mirror([0, 0, 1]) linear_extrude(L) polygon([[260.99, 46], [260.99, 52], [261+w, 52], [261+w, 46+w]]);
    sl(3, 16, 5.5);
    hull() { sl(18.99, 0.01, 5.5); sl(22.49, 0.01, 0.02); }
    translate([257.99, 3, gfl-6]) cube([2.81, gt_win_y0-3, 12.01]);   // (to the window edge)
}
v17_glug = [[236, 38], [252, 50]];
// v1.7t (no heat-set inserts): lugs 8 wide (were 6); M3 x 16 from behind the panel, the nut dropped into a slot from the
// lug's top (hex corner up and down; the box prints as drawn: no overhang)
module gate_lugs() { translate([232, -9, 34]) cube([8, 10.5, 8]);
    hull() { translate([248, -9, 46]) cube([8, 10.5, 8]); translate([248, 1, 36]) cube([8, 0.5, 18]); } }
module gate_lug_holes() for (q=v17_glug) { translate([q[0], -9.01, q[1]]) rotate([-90,0,0]) cylinder(d=m3_clear, h=10.6, $fn=16);
    translate([q[0], -2.2, q[1]]) rotate([-90,0,0]) rotate([0,0,30]) cylinder(d=m3_nut, h=2.6, $fn=6);
    translate([q[0]-m3_nut*cos(30)/2, -2.2, q[1]]) cube([m3_nut*cos(30), 2.6, 10]); }
// v1.7 FEA (stack side): the gate box hung on its 2 lugs only. The first-pass ball's hit on the +X bar (14 N est. at
// 0.5 m/s) bent it: SF 0.68, 1 mm. Part 46b: 2 legs from the base up under the 2 lugs (glue faces 6 x 10 and 6 x 14 on
// the lug undersides, CA), behind the finish trough (Y -9..1), on a base plate with 2 M3 x 12 countersunk from under
// the base (X 230, 244; nuts on the plate).
module gate_legs() difference() {
    union() {
        translate([227, -9, 0]) cube([31, 7, 3]);                                        // base plate (Y -9..-2)
        translate([233, -9, 0]) cube([6, 10, 34]);                                       // leg 1 under lug 1 (lug bottom Z 34)
        difference() { union() { for (x=[233, 249]) hull() { translate([x-2.5, -9, 0]) cube([11, 10, 3]); translate([x, -9, 5.5]) cube([6, 10, 0.01]); } }   // 45 deg roots
                       for (x=v17_gleg) translate([x, -5.5, 2.99]) cylinder(d=7.4, h=10, $fn=24); }
        hull() { translate([249, -9, 0]) cube([6, 10, 0.01]);                            // leg 2 under lug 2's 45 deg underside
                 translate([249, -9, 45.99]) cube([6, 0.01, 0.01]); translate([249, 0.99, 35.99]) cube([6, 0.01, 0.01]); }
    }
    for (x=v17_gleg) translate([x, -5.5, -1]) cylinder(d=m3_clear, h=5, $fn=16);
}
v17_gleg = [230, 244];
// ---- v1.7t gate flap (J58/J78, coordinator's option A, docs/coaster_v1.7_stack.md "Integration") ----
// v1.7 had the flap hinged at its -X edge: its own weight (and the ball's) OPENED it, and a cord over fixed guides
// could only open it about 15 deg. Now:
//  - the hinge is the flap's +Y edge (beside the +Y door), axis along X at Y 27, Z 38.5: 0.47 mm past the falling ball
//    (Y <= 26.53). 2 stub pins (3 mm rod) pressed in the flap's 2 knuckles at its X ends (out of the ball's path), turning
//    in the box's -X and +X walls (pin_turn, teardrop point up: the box prints as drawn). No pin crosses the drop;
//  - the flap opens by lifting its -Y edge and leans into the +Y door (empty on the second pass): about 103 deg at E2's
//    top. It swings free to 120 deg (then its hinge edge meets the door sill), so the lever never pulls on a stop
//    unless the cord is tied more than about 5 mm short;
//  - shut, the flap's -Y edge rests on 2 ledge pads (X ends, out of the falling ball): its weight and the ball's keep it
//    shut on the first pass;
//  - a crank (47b) on the +X stub pin, outside the +X wall (X 258.5..261.7): a cord arm (r 15.5, 30 deg below +Y at rest)
//    with a grooved spool (groove at X 263), and a counter-arm with 1 M3 nut (glued): flap + crank close by weight;
//  - the cord (J58) comes from B along X 263 at Z 4, turns up at guide C1 (now at Y 6), over peg D (Y 6, Z 22) toward +Y,
//    round the crank's spool and back to a tie hole in guide 62's tab (Y 6, Z 33.5): 2:1, the spool moves half the cord
//    travel; the pull is toward -Y, so the spool swings back under the box (away from the finish trough) as it opens.
gate_hinge = [244, 27.0, 38.5];                    // a point on the hinge axis (the axis runs along X)
gate_ax = [-1, 0, 0];                              // opening = turn about -X (the -Y edge lifts)
gt_knk = [[233.2, 237.2], [250.8, 254.8]];        // flap knuckles (X), each on its own stub pin: the falling ball reaches only Y 23.7 at X 237.2 / 250.8 (knuckles from Y 24.3)
gt_kd = 5.6;                                       // knuckle OD (walls >= 1.2 round the 3.05 press hole)
gt_py1 = 27.0;                                     // flap plate Y 6.2 .. 27 (to the axis: no pin between the knuckles)
gt_win_y1 = 22.5;                                  // box window (+X wall) to Y 22.5: 2.9 mm wall round the pin hole
gt_cx = [258.5, 261.7];                            // crank (X): 0.5 mm off the +X wall, the cord plane is X 263
gt_r = 15.5; gt_b0 = -30;                          // cord arm: spool centre radius and angle at rest (from +Y toward +Z)
gt_g0 = -75; gt_gr = 9.5;                          // counter-arm (1 M3 nut): direction at rest and radius (clear of the +X bar to 125 deg)
gt_pins = [[gt_knk[0][1]-7, gt_knk[0][1]], [gt_cx[1]-11, gt_cx[1]]];   // 2 stub pins 3 x 7 (X 230.2..237.2) and 3 x 11 (X 250.7..261.7): no pin crosses the ball's drop
module gt_rot(t) translate(gate_hinge) rotate([-t, 0, 0]) translate(-gate_hinge) children();
// teardrop hole along +X from the origin, point up (+Z), fit resolution
module gt_td_x(d, L) rotate([90, 0, 90]) linear_extrude(L) union() { circle(d=d, $fn=fit_fn); rotate(45) square(d/2); }
module gt_hinge_holes() for (x=[[gx0-1, gx0+2.5], [254.9, gx1+1]]) translate([x[0], gate_hinge[1], gate_hinge[2]]) gt_td_x(pin_turn, x[1]-x[0]);   // (+X: through the floor's end and the wall)
module gt_knuckles(g=0) for (k=gt_knk) translate([k[0]-g, gate_hinge[1], gate_hinge[2]]) rotate([0, 90, 0]) cylinder(d=gt_kd+2*g, h=k[1]-k[0]+2*g, $fn=48);
module gt_knuckle_room() intersection() { gt_knuckles(0.3); translate([230, 28.9, 30]) cube([30, 1.2, 12]); }   // (front wall Y 29..30.05 at the knuckles; 0.95 mm of it stays)
// ledge pads (part of the box): the shut flap's -Y edge rests on them, Z 34..38.5, at the X ends
module gt_ledges() for (x=[[231.99, 234.6], [253.4, 255.01]]) translate([x[0], 5.99, gfl-6.01]) cube([x[1]-x[0], 2.61, 4.51]);
// the printed flap (shut): plate + 2 knuckles - pin holes (press: the flap prints on its -X end, the holes stand)
module gate_flap_part() difference() {
    union() { translate([233.2, 6.2, gfl-1.5]) cube([254.8-233.2, gt_py1-6.2, 1.5]); gt_knuckles(); }
    for (k=gt_knk) translate([k[0]-1, gate_hinge[1], gate_hinge[2]]) rotate([0, 90, 0]) cylinder(d=pin_press, h=k[1]-k[0]+2, $fn=fit_fn);
}
// crank spool and counter-nut centres (Y, Z) at flap angle t
function gt_tip(t) = [gate_hinge[1], gate_hinge[2]] + gt_r*[cos(gt_b0-t), sin(gt_b0-t)];
function gt_cpad(t) = [gate_hinge[1], gate_hinge[2]] + gt_gr*[cos(gt_g0-t), sin(gt_g0-t)];
module gt_disc(p, d, x0=gt_cx[0], x1=gt_cx[1]) translate([x0, p[0], p[1]]) rotate([0, 90, 0]) cylinder(d=d, h=x1-x0, $fn=40);
// the crank (47b), shut pose: hub, cord arm with the spool (groove at X 263), counter-arm with a nut pocket (from +X)
module gate_crank() let(T=gt_tip(0), P=gt_cpad(0)) difference() {
    union() {
        hull() { gt_disc([gate_hinge[1], gate_hinge[2]], 8); gt_disc(T, 6); }
        hull() { gt_disc([gate_hinge[1], gate_hinge[2]], 8); gt_disc(P, 8.6); }
        translate([gt_cx[1]-0.01, T[0], T[1]]) rotate([0, 90, 0]) cg_peg(266-gt_cx[1]+0.01, 263-gt_cx[1]+0.01);   // spool (r 3 groove bottom, cord centre r 3.5)
    }
    translate([gt_cx[0]-1, gate_hinge[1], gate_hinge[2]]) rotate([0, 90, 0]) cylinder(d=pin_press, h=10, $fn=fit_fn);   // press + CA (crank prints on its -X face: standing)
    translate([gt_cx[1]-2.5, P[0], P[1]]) rotate([0, 90, 0]) rotate(30) cylinder(d=m3_nut, h=3, $fn=6);              // M3 nut, CA (counterweight)
}
// the moving gate (flap, crank, stub pins, nut) at flap angle t (0 = shut)
module gate_flap(t=0) color("#e0a040") gt_rot(t) {
    gate_flap_part(); gate_crank();
    color("silver") { for (q=gt_pins) translate([q[0]+0.01, gate_hinge[1], gate_hinge[2]]) rotate([0, 90, 0]) cylinder(d=3, h=q[1]-q[0]-0.02, $fn=16);
        let(P=gt_cpad(0)) translate([gt_cx[1]-2.45, P[0], P[1]]) rotate([0, 90, 0]) rotate(30) cylinder(d=6.35, h=2.4, $fn=6); }
}
// flap angle at E2 lever angle a: the cord (lever tie -> A -> B -> C1 -> D -> spool -> tie) has a fixed length, set with
// 0.5 mm slack with E2 at rest. Bisection on the cord length (gt_len) against the lever's pull (gt_pull). 2D (Y, Z) in the
// cord plane X 263; D is wrapped clockwise, the spool counterclockwise (crossing tangent between them).
gt_C1 = [6, 7.5]; gt_D = [6, 22]; gt_G = [6, 33.5]; gt_slack = 0.5;
function gt_pull(a) = let(f=[128.1, 232.3], A=[146.106, 11]) norm(f+30*[cos(a), sin(a)]-A) - norm(f+30*[cos(e2a), sin(e2a)]-A);
function _cwd(a0, a1) = let(d=(a0-a1)%360) d < 0 ? d+360 : d;                        // clockwise degrees from a0 to a1
function _ang(v) = atan2(v[1], v[0]);
// departure point from the spool (counterclockwise) toward the tie point G
function gt_dep(T) = let(g=gt_G-T, L=norm(g), al=acos(cg_c/L), c1=_ang(g)+al, c2=_ang(g)-al,
        ok=function(c) let(q=T+cg_c*[cos(c), sin(c)], dd=(gt_G-q)/norm(gt_G-q)) dd*[-sin(c), cos(c)] > 0.99) ok(c1) ? c1 : c2;
// [spool centre, D departure angle, spool arrival angle, spool departure angle, cord length D -> tie]
function gt_geo(t) = let(T=gt_tip(t), dd=norm(T-gt_D), d=(T-gt_D)/dd, th=-asin(2*cg_c/dd),
        tv=[d[0]*cos(th)-d[1]*sin(th), d[0]*sin(th)+d[1]*cos(th)], rn=[tv[1], -tv[0]], pD=gt_D-cg_c*rn, pT=T+cg_c*rn,
        c=gt_dep(T), q=T+cg_c*[cos(c), sin(c)], aD=_ang(pD-gt_D), aT=_ang(pT-T))
    [T, aD, aT, c, _cwd(180, aD)*PI/180*cg_c + norm(pT-pD) + _cwd(c, aT)*PI/180*cg_c + norm(gt_G-q)];
function gt_len(t) = gt_geo(t)[4];
function _gt_bis(need, lo, hi, n) = n == 0 ? lo : let(m=(lo+hi)/2) gt_len(0)-gt_len(m) < need ? _gt_bis(need, m, hi, n-1) : _gt_bis(need, lo, m, n-1);
function gate_phi(a) = let(need=gt_pull(a)-gt_slack) need <= 0 ? 0 : _gt_bis(need, 0, 150, 34);
function gate_flap_info() = [gate_hinge, gate_ax, gate_open];
// the flap's swing (0 .. 90 deg, grown by g): v5b cut it out of the finish trough's start; the v1.7t flap swings UP
// (nothing to cut any more; kept so finish_track_body does not change)
module gate_flap_plate(t, g=0) gt_rot(t) translate([233.2-g, 6.2-g, gfl-1.5-g]) cube([21.6+2*g, gt_py1-6.2+2*g, 1.5+2*g]);
module gate_flap_swing(g=0.6) for (t=[0:2.5:87.5]) hull() { gate_flap_plate(t, g); gate_flap_plate(t+2.5, g); }
module feeds() {
    color("#d08a4a") difference() { trough_chain([for (k=[2:len(E2feed)-1]) E2feed[k]], open_start=true, open_end=true, pads=[2]); trip_slot(E2O); }   // pad at E2feed[4]
    color("#d08a4a") finish_track_body();
    finish_line();
    color("#2e343d") let(e=finish_pts[len(finish_pts)-1]) translate([e[0], e[1]+ball_r+0.8+1.0, e[2]]) rotate([90,0,0]) cylinder(d=10, h=2, center=true, $fn=24);   // felt stop (rule 3.h) in the end cap
    color("#d08a4a") finish_feet();   // two feet under the track (v1.7: with M3 ears)
}
// v5 finish line (rule 3.f): a 2 mm bar across the track at Y 118 on two posts (top Z 30, clear over the ball), a red
// groove across both track rims under it, and a sign on the left: "FINISH" in 6 mm raised text with an arrow, facing
// the front. The ball is timed until it has fully crossed (centre at Y 127.5); it stops 23 mm later on the felt.
// v1.6 (print fix): the felt pocket in the end cap (trough_chain's pad pocket, 2.1 deep) went through the faceted end
// cap: a 0.045 mm3 loose crumb was all that was left behind the felt. A 14 mm disc, 1.2 mm behind the pocket, closes it.
fin_e = finish_pts[len(finish_pts)-1];
fin_pk = fin_e + [0, ball_r+0.8+1, 0];                                     // pad pocket centre (as trough_chain)
module fin_pocket() translate(fin_pk) rotate([90,0,0]) cylinder(d=10.4, h=2.1, center=true, $fn=24);
module finish_track_body() difference() {
    union() { trough_chain(finish_pts, mouth=true, pads=[len(finish_pts)-1]);
              translate(fin_pk + [0, -0.825, 0]) rotate([-90,0,0]) cylinder(d=14, h=3.125, $fn=32); }   // Y 151.5..154.6: 1.25 mm behind the pocket
    fin_pocket(); finish_groove();
    translate([229, 4, 16.5]) cube([6.8, 26, 20]); gate_flap_swing();      // the open gate flap hangs here (X 233.2..234.7); v5b: and its whole swing
}
// v1.7 (J80): each foot gets an ear 8 x 6 x 3 on its -X end with an M3 x 12 countersunk up from under the base, nut on top
// v1.8 (grid): feet at Y 70 and 130 (was 125); ears to X 265 (Y 130) / 256 (Y 70: + the locating pin at (260, 70)), bolts at X 270
v18_finY = [70, 130];
module finish_feet() for (y=v18_finY) let(z=finish_pts[6][2]+(y-100)*(13.6-15.0)/41, x0=(y==70 ? 256 : 265)) difference() {
    union() { translate([287-8, y-3, 0]) cube([16, 6, z-ball_r-0.8-1.6+0.3]); translate([x0, y-3, 0]) cube([279.01-x0, 6, 3]);
              if (y==70) translate([260, 70, 0]) cylinder(d=6, h=5, $fn=32); }
    translate([270, y, -1]) cylinder(d=m3_clear, h=5, $fn=16);
    if (y==70) translate([260, 70, -0.01]) cylinder(d=pin_press, h=5, $fn=fit_fn);
}
// v1.7 (J81): a foot flange on the sign's bottom (+Y side, X 244..270), 2 M3 x 12 countersunk up from under the base;
// the right post no longer goes 1.1 mm into the track wall (cut to it: glue face there)
// v1.8c (label fix): the bolt + its nut moved left of the letters to (240, 130) (flange to X 236); the locating pin stays at
// (260, 130) but its boss is gone: a 3 x 7 pin, flush with the flange top (Z -4..3). Nothing stands over Z 3 in front of
// the "< LINE" letters (X 249..266, Z 3.19..7.01), so the label is 100 % seen from the front.
module finish_line() color("#d6a648") difference() { finish_line_body(); finish_track_body(); translate([240, 130, -1]) cylinder(d=m3_clear, h=5, $fn=16);   // v1.8c (grid): bolt (240, 130), pin (260, 130)
    translate([260, 130, -0.01]) linear_extrude(3.02) union() { circle(d=pin_press_lying, $fn=fit_fn); rotate(45) square(pin_press_lying/2); } }   // (lying in its print: pose [90,0,0], +Y up)
// v1.8r (rules audit note): "< LINE" centre Z 3.6 -> 5.1, clear of the J81 foot flange (Z 0..3), fully seen from the front
module finish_line_body() let(zt=15.0+(finish_y-100)*(13.6-15.0)/41) {
    translate([236, finish_y+1-0.01, 0]) cube([28, 16, 3]);   // v1.8c: flange X 236..264, Y 119..135 (grid nodes at Y 130)
    translate([236, finish_y-1, 0]) cube([6.61, 2.01, 3]);    // v1.8c: flange extension down to the sign's back face (flat on the bed in its print pose)
    for (x=[272.6, 298.4]) translate([x, finish_y-1, 0]) cube([1.6, 2, 32]);
    translate([272.6, finish_y-1, 30]) cube([27.4, 2, 2]);
    translate([242.6, finish_y-1, 0]) cube([30, 2, 17]);
    color("#f4f1ea") translate([257.6, finish_y+0.99, 10.5]) rotate([90,0,180]) linear_extrude(0.81) text("FINISH", size=6.2, halign="center", valign="center", font="Liberation Sans:style=Bold");
    color("#f4f1ea") translate([257.6, finish_y+0.99, 5.1]) rotate([90,0,180]) linear_extrude(0.81) text("< LINE", size=4, halign="center", valign="center", font="Liberation Sans:style=Bold");
}
module finish_groove() let(zt=15.0+(finish_y-100)*(13.6-15.0)/41) translate([270, finish_y-0.6, zt-3.5]) cube([34, 1.2, 4]);
// cord: E2 lever (30 mm from its pivot) -> down -> along the base -> up beside the gate box -> the gate flap's tie hole
// v1.7 (J58): the v1.6 corner at (146.1, 63, Z 4) was 2.4 mm from the gap slide's front strip, which moves under it, so
// no eyelet could stand there. Now 4 printed smooth guides (grooved pegs, bend radius 3 mm at the groove bottom; the
// cord is 1 mm):
//  A (60) a post on the base in front of the cord (Y 65.2..71.8): the cord comes straight down from the lever as before
//     and turns round a peg at Z 8..14 (2.2 mm over the slide, 1 mm under the front comb frame's bottom bar at gap 16.5),
//     then runs down a slope to B;
//  B (61) a vertical peg on a base foot at (259.5, 60): the cord turns from +X to -Y at Z 4;
//  C (62) a post on the base at X 264.7..268.2 (right of the gate box) with 2 pegs: C1 along X (the cord turns from -Y
//     to up at X 263, 5.7 mm right of the finish trough's start) and C2 along Y on a short arm under the box's +X
//     window (the cord turns from up toward the flap, under the flap, 1.05 mm right of the flap's swing).
// Everything outside the slide, comb, cup and lever envelopes (cad/v17s_j58_check.py: all gaps, all lever angles).
// The lever end (straight down from the tie hole, Y 63) and the flap end (tie hole) are as v1.6: the cord pulls the
// same length per degree of lever turn.
cg_r = 3;                                                   // bend radius (groove bottom)
cg_c = cg_r + 0.5;                                          // the cord's centre line (cord d 1 on the groove bottom)
CG = [[146.106+cg_c, 63, 11], [259.5, 59.5, 4], [263, 6, 7.5]];   // peg centres A, B, C1 (v1.7t: C2 gone, the cord goes to the gate crank)
gate_open = gate_phi(E2_info()[3]);                // v1.7t: flap angle at E2's top (lever +53.1): about 103 deg (here: needs cg_c)
// v1.7t: from B the cord runs along X 263 at Z 4 to C1 (now at Y 6), up at Y 2.5 to peg D, over D toward +Y, round the
// gate crank's spool and back to the tie hole in guide 62's tab (Y 6, Z 33.5): 2:1. The crank turns with the lever.
function gate_cord_pts(a=e2a) = let(f=[128.1, 67, 232.3], p=f+30*[cos(a), 0, sin(a)], A=CG[0], B=CG[1], C=CG[2],
        sA=atan2(A[2]-cg_c-B[2], B[0]-A[0]),                // slope of the A -> B run (down toward +X)
        g=gt_geo(gate_phi(a)), T=g[0], aD=g[1], aT=g[2], cD=g[3], nD=ceil(_cwd(180, aD)/12), nT=ceil(_cwd(cD, aT)/12))
    concat([[p[0], 63, p[2]]],
        [for (t=[0:15:90+sA]) [A[0]-cg_c*cos(t), 63, A[2]-cg_c*sin(t)]],     // round A (vertical -> the slope)
        [[B[0]-0.01, B[1]+cg_c, B[2]]],
        [for (t=[90:-15:0]) [B[0]+cg_c*cos(t), B[1]+cg_c*sin(t), B[2]]],      // round B (+X -> -Y)
        [for (t=[90:15:180]) [C[0], C[1]+cg_c*cos(t), C[2]-cg_c*sin(t)]],     // round C1 (-Y -> up)
        [for (k=[0:nD]) let(t=180-_cwd(180, aD)*k/nD) [263, gt_D[0]+cg_c*cos(t), gt_D[1]+cg_c*sin(t)]],   // over D (up -> toward +Y)
        [for (k=[0:nT]) let(t=aT+_cwd(cD, aT)*k/nT) [263, T[0]+cg_c*cos(t), T[1]+cg_c*sin(t)]],          // round the crank's spool
        [[263, gt_G[0], gt_G[1]], [263, gt_G[0]-3, gt_G[1]]]);               // into the tie hole (knot behind the tab)
module gate_cord(a=e2a, r=0.5, k0=0) color("white") let(q=gate_cord_pts(a))
    for (k=[k0:len(q)-2]) hull() { translate(q[k]) sphere(r, $fn=8); translate(q[k+1]) sphere(r, $fn=8); }
function gate_cord_len(a=e2a) = let(q=gate_cord_pts(a)) sum_len(q, 0);
function sum_len(q, k) = k >= len(q)-1 ? 0 : norm(q[k+1]-q[k]) + sum_len(q, k+1);
// grooved peg along local Z, length L, groove centre at z g: outer radius ro, V groove (45 deg) down to r 3 (cord 1 mm)
module cg_peg(L, g, ro=4.2) let(d=ro-cg_r) difference() { cylinder(r=ro, h=L, $fn=40);
    rotate_extrude($fn=40) polygon([[cg_r, g-0.5], [cg_r, g+0.5], [ro+0.2, g+0.7+d], [ro+0.2, g-0.7-d]]); }
// teardrop point (up) for a horizontal peg: a triangle over the circle in the plane across the peg
module cg_tip(ro) polygon([[-ro*cos(45), ro*sin(45)], [0, ro/sin(45)], [ro*cos(45), ro*sin(45)]]);
// A: foot 20.5 x 6.6 x 3 (2 M3 into the base), post 8 x 6.6 up to Z 16, peg along -Y from the post. Prints on its
// back face (Y 71.8): the peg stands up
module cord_guide_a() let(A=CG[0], y0=65.2) difference() {
    union() {
        translate([A[0]-11, y0, 0]) cube([20.5, 6.6, 3]);                                   // (the E2 tower's foot starts at Y 72)
        translate([A[0]-4, y0, 0]) cube([8, 6.6, A[2]+5]);                                   // (flush with the foot's back edge: print face)
        translate([A[0], y0+0.01, A[2]]) rotate([90,0,0]) cg_peg(y0+0.01-59.8, y0+0.01-63);
        translate([A[0], 59.9, A[2]]) rotate([90,0,0]) mirror([0,0,1]) linear_extrude(y0+0.2-59.9) cg_tip(4.1);
    }
    for (x=[A[0]-8, A[0]+6.5]) translate([x, 68.5, -1]) cylinder(d=m3_clear, h=5, $fn=16);
}
// B: foot 11 x 11 x 1.7 (2 M3), vertical peg (groove at Z 4)
module cord_guide_b() let(B=CG[1]) difference() {
    union() { translate([B[0]-4, B[1]-8, 0]) cube([11, 11, 1.7]); translate([B[0], B[1], 0]) cg_peg(7.5, B[2]); }
    for (q=[[B[0]+4.5, B[1]-5.5], [B[0]-1.5, B[1]-5.5]]) translate([q[0], q[1], -1]) cylinder(d=m3_clear, h=5, $fn=16);
}
// C: post X 264.7..268.2, Y 10..26 up to Z 40, foot to X 268.7 (2 M3); peg C1 along -X (groove at X 263); an arm at
// Y 10..14 along -X under the box's window carries peg C2 along +Y (Y 14..24.9, groove at Y 20, outer r 3.6)
// v1.7t: guide 62 rebuilt for the gate crank (2:1). Post X 266.6..270.1, Y 1..11, Z 0..36 on a foot (X 262.7..270.1,
// Y -4..15, 2 M3 countersunk from under the base); 3 features along -X to the cord plane X 263: peg C1 (Y 6, Z 7.5: the
// cord from B turns up), peg D (Y 6, Z 22: the cord turns toward the crank) and a tab (Z 31.5..35.5) with the tie hole
// for the cord's end (along Y at Z 33.5). Prints on its +X face: the pegs and the tab stand up, no support.
gt_cfoot = [[262.7, -5.5], [270.1, 15.5]]; gt_cbolt = [[266.4, -2.5], [266.4, 12.8]];   // (post 0.6 mm +X of the spool's swing; bolts in the foot, off the post)
module cord_guide_c() let(x0=266.6, x1=270.1) difference() {
    union() {
        translate([x0, 1, 0]) cube([x1-x0, 10, 36]);                                            // post
        translate([gt_cfoot[0][0], gt_cfoot[0][1], 0]) cube([x1-gt_cfoot[0][0], gt_cfoot[1][1]-gt_cfoot[0][1], 3]);   // foot
        for (q=[gt_C1, gt_D]) translate([x0+1, q[0], q[1]]) rotate([0,-90,0]) cg_peg(x0+1-258.6, x0+1-263);   // C1, D (groove at X 263)
        hull() { translate([261.5, gt_G[0]-2, gt_G[1]-2]) cube([x0+0.01-261.5, 4, 4]);           // tie tab (prints standing on the post)
                 translate([x0-0.01, gt_G[0]-2, gt_G[1]-2-(x0-261.5)]) cube([0.01, 4, x0-261.5+4]); }
    }
    for (q=gt_cbolt) translate([q[0], q[1], -1]) cylinder(d=m3_clear, h=5, $fn=16);
    translate([263, gt_G[0]-3, gt_G[1]]) rotate([-90,0,0]) cylinder(d=1.6, h=6, $fn=16);           // tie hole along Y (cord 1 mm, knot on the -Y side)
}
module cord_guides() color("#4a5360") { cord_guide_a(); cord_guide_b(); cord_guide_c(); }
// loop: POI at X 160, Z 43.6; loop frame (x, y, w) -> world (160 + x, 119 + w, 43.6 + y)
POIx = 145; POIz = 43.6; loopY0 = 119;         // 15 mm left of the sim spot: room for the E1 feed corner
module at_loop() translate([POIx, loopY0, POIz]) mirror([0,1,0]) rotate([90,0,0]) children();
// E1 feed: loop exit (lane B, Y 150.5, X 205) -> felt corner at X 215 (pad on its +X wall; the ball clears the lane's
// end) -> back (-Y), jogging left to X 206.5 so it passes left of E1's latch crank (X >= 219.6, Y 116..120) -> round
// into the cup from -X, 4.5 mm above the seat
E1feed = [[205, 149, 53.8], [215, 149, 53.3], [215, 134.5, 51.4], [206.5, 126, 49.6], [206.5, 102.6, 39.4], [233.8, 102.6, 37.3]];   // v5: starts at Y 149 (lane B moved 1.5 mm in)   // v3: foam corner at [4], 2.1 mm drop after it
// (v3) slot in the end of each feed for the latch trip pin (2 mm inside the end, 0.7 mm up into the ball path)
module trip_slot(o) translate(o + [-14-2.5, -7, 23]) cube([5, 14, 6]);
module e1feed() color("#d08a4a") difference() { trough_chain(E1feed, open_start=true, open_end=true, pads=[1, 4]); trip_slot(E1O); }   // v3: 2nd foam corner just before the cup (sim: the ball came in at 0.42 m/s, the cup holds 0.25)
// ---------------- v5 wood (Kai, 2026-10-28: the v4 woods stay) ----------------
// base and back panel: 6 mm birch plywood (saw + drill: drawing cad/laser/wood_6mm_drawing.svg; the Falcon 5W
// cannot cut 6 mm birch, it can engrave it: cad/laser/base_engrave_6mm.svg).
wood_c = "#c8a979";
// ---------------- v5b loop brackets (Kai, 2026-10-28: no loop board, no laser cutting) ----------------
// The loop's 8 screw tabs (12 x 9.2 x 4 mm, world Y 119..123, outside the track walls) bolt with M3 to Elevator 1's
// pin plate (a printed truss on the base, front face Y 116, 3 mm behind the tabs):
//  - R3, R4, LT, AT: through a 3 mm printed spacer and the plate (M3 x 16, nut in a pocket in the plate's back face);
//  - R2 (ring top) and R1 (right of the plate): through the RIGHT bracket, a 3 mm plate between the loop and the E1
//    plate, bolted to the plate at R2 and at (146, 163). R1's bolt has its nut behind the bracket (M3 x 12, v1.7t);
//  - the chute's CT1 (left of the plate): through the LEFT bracket, bolted to the plate's left bar at (48, 122) and
//    (48, 138). It stays at X >= 24.5, clear of Elevator 1's counterweight pot (X <= 23.5). CT2 (chute top) has no
//    bracket, as in v4/v5 (the pot passes behind it); the chute is held by CT1 and its peg in the ring.
// Everything sits between Y 116 and 119 (behind the track) or on the tabs' outer side: out of the ball's path and of
// the sight lines from the front. The loop's geometry, POI and labels are unchanged.
LB_Y = [116, loopY0];
function loop_tabs() = [for (q=CL_tab_holes()) [POIx+q[0], POIz+q[1]]];   // 0 R1, 1 R2, 2 R3, 3 R4, 4 LT, 5 AT, 6 CT1, 7 CT2
module lb_disc(p, r, y0=LB_Y[0], y1=LB_Y[1]) translate([p[0], y1, p[1]]) rotate([90,0,0]) cylinder(r=r, h=y1-y0, $fn=32);
module lb_hole(p) translate([p[0], 100, p[1]]) rotate([-90,0,0]) cylinder(d=m3_clear, h=40, $fn=16);
// bracket-to-plate bolts: countersunk M3 x 12 (DIN 7991), head flush with the bracket's front face (the loop's back
// face is right in front of it), nut in the plate's back face
module lb_csk(p) translate([p[0], LB_Y[1]-1.7, p[1]]) rotate([-90,0,0]) cylinder(d1=3.4, d2=6.4, h=1.71, $fn=24);
module loop_spacer(p) difference() { lb_disc(p, 4.5); lb_hole(p); }
module loop_bracket_R() let(T=loop_tabs()) difference() {
    hull() { lb_disc(T[0], 6); lb_disc(T[1], 6); lb_disc([146, 163], 4.5); }
    for (p=[T[0], T[1], [146, 163]]) lb_hole(p);
    lb_csk([146, 163]);
}
module loop_bracket_L() let(T=loop_tabs(), c=T[6]) difference() {
    hull() { translate([24.5, LB_Y[0], c[1]-6]) cube([10.5, 3, 12]); lb_disc([48, 122], 4.5); lb_disc([48, 138], 4.5); }
    for (p=[c, [48, 122], [48, 138]]) lb_hole(p);
    for (p=[[48, 122], [48, 138]]) lb_csk(p);
}
// bolts (heads on the tabs' front faces, Y 123..126, outside the track walls) and the nuts behind the brackets at R1 and CT1
module loop_bolts() let(T=loop_tabs()) color("silver") {
    for (p=[T[1], T[2], T[3], T[4], T[5]]) translate([p[0], 107, p[1]]) rotate([-90,0,0]) { cylinder(d=3, h=16, $fn=12); translate([0,0,16]) cylinder(d=5.5, h=3, $fn=16); }
    for (p=[T[0], T[6]]) translate([p[0], 111.0, p[1]]) rotate([-90,0,0]) { cylinder(d=3, h=12, $fn=12); translate([0,0,12]) cylinder(d=5.5, h=3, $fn=16); translate([0,0,1.0]) cylinder(d=6.35, h=2.4, $fn=6); }   // v1.7t: M3 x 12 (were x 10); v1.8: nut in the LS1 leg's back pocket (Y 112..114.4)
    for (p=[[146, 163], [48, 122], [48, 138]]) translate([p[0], 107, p[1]]) rotate([-90,0,0]) { cylinder(d=3, h=12, $fn=12); translate([0,0,12-1.65]) cylinder(d1=3, d2=6, h=1.65, $fn=16); }   // countersunk, flush
}
module loop_brackets() let(T=loop_tabs()) {
    color("#4a5360") { for (p=[T[2], T[3], T[4], T[5]]) loop_spacer(p); loop_bracket_R(); loop_bracket_L(); }
    ls1();   // v1.8
    loop_bolts();
}
module loop_board() loop_brackets();   // v5b: old name kept for scripts; there is no board
// v1.8 (modular): LOOP STAND LS1 = 2 legs, so the loop module stands on its own feet on the grid (it stays screwed to
// Elevator 1's plate too: screws between modules are allowed; unbolt 7 screws and E1 comes out, the loop stays up).
// Each leg: a 10 x 4 column in the band Y 112..116 behind the loop bracket (where the R1 / CT1 nuts sat), glued (CA) to
// the bracket (one module) and on the R1 (right) / CT1 (left) M3 x 12: its nut now sits in a pocket in the leg's back face.
// Foot flange toward +Y (Y 112..124, under the ring, Z 0..4): 1 M3 x 12 countersunk from under the base + 1 locating pin
// 3 x 9 on grid nodes. Prints flat on its back face (Y 112): the Z holes lie (teardrop point +Y), the Y holes stand.
ls1_x = [[26, 36], [176, 186]]; ls1_tab = [6, 0];            // column X; the loop tab it carries (CT1, R1)
ls1_bolt = [[30, 120], [180, 120]]; ls1_pin = [[20, 120], [170, 120]];
ls1_foot = [[16, 38], [166, 188]];   // (left pin at X 20: at X 40 its boss touched the E1 foot)
module ls1_leg(k) let(T=loop_tabs()[ls1_tab[k]], xc=ls1_x[k], f=ls1_foot[k], b=ls1_bolt[k], pn=ls1_pin[k]) difference() {
    union() {
        translate([xc[0], 112, 0]) cube([xc[1]-xc[0], 4, T[1]+8]);
        translate([f[0], 112, 0]) cube([f[1]-f[0], 12, 4]);
        translate([pn[0], pn[1], 0]) cylinder(d=8, h=6, $fn=32);
        hull() { translate([xc[0], 112, 4]) cube([xc[1]-xc[0], 4, 0.01]); translate([xc[0], 112, 0]) cube([xc[1]-xc[0], 10, 4]); }   // root fillet
    }
    translate([b[0], b[1], -1]) cylinder(d=m3_clear, h=6, $fn=16);
    translate([pn[0], pn[1], -0.01]) linear_extrude(6) union() { circle(d=pin_press_lying, $fn=fit_fn); rotate(45) square(pin_press_lying/2); }
    translate([T[0], 110, T[1]]) rotate([-90,0,0]) cylinder(d=m3_clear, h=8, $fn=16);
    translate([T[0], 112-0.01, T[1]]) rotate([-90,0,0]) cylinder(d=m3_nut, h=2.61, $fn=6);   // nut pocket (standing in the print)
}
module ls1() color("#4a5360") { ls1_leg(0); ls1_leg(1); }
// back panel: 6 mm birch, world Y -15..-9 as v4, now a truss (frame + one diagonal per bay): saw the windows.
bp_z1 = v18_tz(402.65); bp_m = 14;
bp_cols = [-26, 34, 222.8, 300]; bp_rows = [0, v18_sz(134), v18_sz(268), bp_z1];
module back_panel_2d() difference() {
    translate([Lx0, 0]) square([L-Lx0, bp_z1]);
    for (w=bp_windows()) polygon(w);
    for (q=v17_panel_m3()) translate(q) circle(d=3.4, $fn=16);   // v1.7: M3 into the frame posts, the E2 post, the left cage, the gate box
}
// windows as plain triangles (straight saw cuts): each bay minus its frame and its diagonal
function bp_windows() = [for (i=[0:2], j=[0:2]) let(x0=bp_cols[i], x1=bp_cols[i+1], z0=bp_rows[j], z1=bp_rows[j+1],
        a=x0+(i==0?bp_m:bp_m/2), b=x1-(i==2?bp_m:bp_m/2), c=z0+(j==0?bp_m:bp_m/2), d=z1-(j==2?bp_m:bp_m/2),
        up=(i+j)%2==0, k=bp_m/2*norm([b-a, d-c])/(b-a), kz=bp_m/2*norm([b-a, d-c])/(d-c))
    each (up ? [[[a, c+k], [a, d], [b-kz, d]], [[a+kz, c], [b, c], [b, d-k]]]
             : [[[a, c], [b-kz, c], [a, d-k]], [[b, c+k], [b, d], [a+kz, d]]])];
module back_panel() color(wood_c) difference() { translate([0, Wy0+6, 0]) rotate([90,0,0]) linear_extrude(6) back_panel_2d();
    for (q=v17_wood) translate([q[0], q[1], -0.01]) cylinder(d=2.5, h=12, $fn=12); }   // v1.7t (J1): 2.5 mm pilot holes: M3 x 16 machine screws cut their thread in the plywood edge (+ wood glue)
// base: 6 mm birch, one sheet. v5: 3 levelling wheels (rule 4.e) in counterbores from below, and a level spot.
LEV = [[-14, 0], [286, 0], [100, 151]];                  // 3 points, no rocking; centre of mass about (99, 71), 47..71 mm inside
LEVEL_SPOT = [240, 145];
module base_outline() translate([Lx0, Wy0]) square([L-Lx0, Wy1-Wy0]);
module base_engrave() { translate(LEVEL_SPOT) difference() { circle(d=18, $fn=48); circle(d=16.6, $fn=48); }
    translate(LEVEL_SPOT+[0,-14.5]) text("LEVEL", size=4, halign="center", font="Liberation Sans:style=Bold");
    for (q=LEV) translate(q+[0,7]) text("ADJ", size=3, halign="center", font="Liberation Sans"); }
// v1.8 (modular, docs/modules_v1.8.md section 3): the base is a GRID of M3 holes, pitch 10 mm, at every world X, Y that is
// a multiple of 10 (d v18_grid_hole: close fit for M3 and the 3 mm locating pins). The frozen parts (plate 1) keep their
// exact v1.7 holes ("pattern holes", d 3.4 + countersink); grid holes closer than 7 mm to a pattern hole, within 14.5 mm of
// a levelling wheel, or under the back panel are left out. A countersink (from below, by hand) only where a module screws
// in (v18_used). v18_grid_on = false gives the v1.7 base back (the hole list as v1.7).
v18_grid_on = true;
v18_pitch = 10; v18_grid_hole = 3.2;          // (hole size: laser test strip first, cad/v18m_base_strip.scad)
function v18_frozen_holes() = concat([[116.1, 87], [140.1, 87], [235.5, 92.6], [244.0, 92.6]],          // E2 tower 26, latch post 31
    [[v17_gleg[0], -5.5], [v17_gleg[1], -5.5]],                                                          // gate legs 46b
    [[CG[0][0]-8, 68.5], [CG[0][0]+6.5, 68.5], [CG[1][0]+4.5, CG[1][1]-5.5], [CG[1][0]-1.5, CG[1][1]-5.5], gt_cbolt[0], gt_cbolt[1]],   // cord guides 60, 61, 62
    [[41, 92.5], [103, 92.5]], pg_guide_xy());                                                           // peg plate 10, slide guide bolts (09, 11)
// not frozen, but off the grid: J1 panel screws (into the panel edge), the E2 bracket foot (the grid node (290, 10) is in the
// levelling wheel's keep-out), and Elevator 1's feet until its file is changed (rules agent first: "go full")
v18_e1_holes = [[219.3, 127.6], [227.8, 127.6]];   // E1 latch post 20: its foot is the same module as E2's frozen latch post 31 (elevator1_test.scad latch_post): pattern
function v18_fixed_holes() = concat(v17_wood, [[296, 10]], v18_e1_holes);
function v18_pattern_holes() = concat(v18_frozen_holes(), v18_fixed_holes());
// grid nodes that carry a screw (countersink) or a locating pin, per module
function v18_used() = concat([for (f=[0,1], k=[0,1]) v18_fbolt[f][k]],                                  // M2 frame feet
    [for (q=E1STAND) each q[5]], E2STAND[5], v18_csR_bolt,                                                // feed stands 57a, 57b, 58; cage stand 53
    [[270, 70], [270, 130], [240, 130]],                                                                  // M9 finish track, finish line (v1.8c: 250 -> 240)
    [[-10, 50], [-10, 100], [-10, 150]],                                                                  // M10 card holder
    [[140, 120], [50, 130]], [[0, 100], [10, 100]],                                                       // M5 E1 foot 12b, post 13
    ls1_bolt);                                                                                            // M8 loop stand LS1
function v18_pins() = concat([v18_fpin[0][0], v18_fpin[1][1]], [for (q=E1STAND) each q[6]], E2STAND[6], [v18_csR_pin],
    [[260, 70], [260, 130]], [[-10, 60], [-10, 140]], [[50, 120], [140, 130], [0, 90]], ls1_pin);
function v18_near(p, L, r) = len([for (q=L) if (norm([p[0]-q[0], p[1]-q[1]]) < r) 1]) > 0;
function v18_grid() = [for (x=[ceil((Lx0+5)/v18_pitch)*v18_pitch : v18_pitch : L-5], y=[ceil((Wy0+5)/v18_pitch)*v18_pitch : v18_pitch : Wy1-5])
    if (y > Wy0+6+1.6 && !v18_near([x, y], v18_pattern_holes(), 7) && !v18_near([x, y], LEV, 14.5)) [x, y]];
// every used node must be a grid node (checked when the base is drawn)
function v18_bad() = [for (p=concat(v18_used(), v18_pins())) if (!v18_near(p, v18_grid(), 0.01)) p];
module v18_csk(q) translate([q[0], q[1], -7]) { cylinder(d=m3_clear, h=8, $fn=16); translate([0,0,0.99]) cylinder(d1=6.5, d2=3.4, h=1.55, $fn=24); }
module base_plate() { assert(!v18_grid_on || len(v18_bad()) == 0, str("v1.8 grid: used node not in the grid: ", v18_bad())); base_plate_v18(); }
module base_plate_v18() color(wood_c) difference() {
    translate([0,0,-6]) linear_extrude(6) base_outline();
    if (v18_grid_on) {
        for (q=v18_grid()) translate([q[0], q[1], -7]) cylinder(d=v18_grid_hole, h=8, $fn=24);
        for (q=v18_used()) translate([q[0], q[1], -7]) translate([0,0,0.99]) cylinder(d1=6.5, d2=3.4, h=1.55, $fn=24);   // countersinks (by hand)
        for (q=concat(pg_guide_xy(), [[41, 92.5], [103, 92.5]])) translate([q[0], q[1], -7]) cylinder(d=m3_clear, h=8, $fn=16);   // frozen: peg plate + slide guide bolts (heads under the base, as v1.7)
        for (q=[for (h=v18_pattern_holes()) if (!v18_near(h, concat(pg_guide_xy(), [[41, 92.5], [103, 92.5]]), 0.01)) h]) v18_csk(q);
    } else {
        for (q=concat(pg_guide_xy(), [[41, 92.5], [103, 92.5]])) translate([q[0], q[1], -7]) cylinder(d=m3_clear, h=8, $fn=16);
        for (q=concat(v17_base_m3(), v17_wood)) v18_csk(q);
    }
    for (q=LEV) translate([q[0], q[1], 0]) {
        translate([0,0,-6.01]) cylinder(d=20, h=3.01, $fn=48);       // counterbore from below, 3 deep: the wheel can go up flush
        translate([0,0,-4]) cylinder(d=m3_clear, h=5, $fn=16);         // v1.7t (owner: no M4): M3 clearance
        translate([0,0,-2.5]) cylinder(d=m3_nut, h=2.6, $fn=6);        // M3 nut, epoxied in a 2.5 mm hex pocket from the top
    }
}
// the locating pins (3 x 9 rod: 5 in the foot, 4 in the base) and, for the pictures, nothing else
v18_short_pins = [[260, 130]];   // v1.8c: the finish sign's pin is 3 x 7, flush with its flange top (no boss)
module v18_grid_pins() color("silver") for (q=v18_pins()) translate([q[0], q[1], -4]) cylinder(d=3, h=v18_near(q, v18_short_pins, 0.01) ? 7 : 9, $fn=16);
// levelling wheel (v1.7t, owner: no M4): printed knurled disc d 18 x 3; an M3 x 12 countersunk screw goes up through it
// (head flush in the wheel's underside: it is the foot; CA so the wheel turns the screw) into the M3 nut epoxied in the
// base top. Set: wheel 3 mm under the base (Z -9, as v1.6); range 0 (in the recess) to 6 mm: +-3 mm. The tip stands
// 3 mm over the base top at the set height (6 mm with the wheel up in its recess; v1.6's M4 x 12: 6 / 9 mm).
lev_set = 3;
module lev_wheels() for (q=LEV) translate([q[0], q[1], -6]) {
    color("#4a5360") translate([0,0,-lev_set]) difference() { cylinder(d=18, h=3, $fn=24); for (a=[0:30:330]) rotate(a) translate([9.3,0,-1]) cylinder(d=1.6, h=5, $fn=8);
        translate([0,0,-1]) cylinder(d=m3_clear, h=5, $fn=16); translate([0,0,-0.01]) cylinder(d1=6.5, d2=3.4, h=1.56, $fn=24); }   // (countersink on the bed side)
    color("silver") translate([0,0,-lev_set]) cylinder(d=3, h=12, $fn=12);                       // M3 x 12 (head in the wheel's underside)
    color("silver") translate([0,0,6-2.5]) cylinder(d=6.35, h=2.4, $fn=6);                         // M3 nut in the base top
}

// ---------------- top frame: Elevator 2's top pulley, the rope anchor and the two tip cams ----------------
// (v3, 2026-10-28) v2's post stood in the gap between the cup sweeps, but the v3 cups carry their real latch tail
// (E2's reaches Y 84) and horn pins (E1's reaches Y 86), so nothing can stand in that gap below the tops. A post at
// the back right (in front of the back panel) carries a beam forward at the top; from it hang the top pulley's cheek,
// the rope anchor and the tip-cam block. The cams sit where only the horn pins pass.
E2P1 = [262, 67, -v18_dZ] + E2_info()[1];  E2ANC = [262, 67, -v18_dZ] + E2_info()[2];   // (v1.8: on the crown, dZ lower with the E2 lift kit)   // from coaster_e2.scad (P1v, anchor), world
bkX = [292, 300]; bkY = [82, 88]; bkZ = E2P1[2] + 6;   // v4: the beam follows the top pulley
function e1sw() = E1_info()[7];  function e2sw() = E2_info()[3];
// cam bands (world Y): E1's pin is exposed at Y 86..90.4, E2's at 79.6..84; a 3 mm rib between them
camY1 = [86.6, 89.7]; camY2 = [80.3, 83.4]; ribY = [83.4, 86.6];
function campts(o, f, sw, span) = [for (a=[sw-span-1.0 : 0.25 : sw]) let(lead = a < sw-span ? (sw-span-a)*2.0 : 0) o + f(a) + [0,0,1.8+lead]];   // cam face points (pin top + 0.3, + lead-in)
module cam_band(pts, y) for (k=[0:len(pts)-2]) hull() for (q=[pts[k], pts[k+1]]) translate([q[0]-0.25, y[0], q[2]-1.3]) cube([0.5, y[1]-y[0], 6.3]);
module pin_clear(pts, y) for (k=[0:len(pts)-2]) hull() for (q=[pts[k], pts[k+1]]) translate([q[0], y[0]-1, q[2]]) rotate([-90,0,0]) cylinder(r=1.9, h=y[1]-y[0]+2, $fn=20);
function pinpts(o, f, sw, span) = [for (a=[sw-span-1.5 : 0.1 : sw+0.2]) o + f(min(a, sw))];
function cam1() = campts(E1O, function(a) E1_hornpin(a), e1sw(), E1_tipspan());
function cam2() = campts(E2O, function(a) E2_hornpin(a), e2sw(), E2_tipspan());
module tipcams() color("#e0a040") difference() {
    c1 = cam1(); c2 = cam2();
    union() {
        cam_band(c1, camY1); cam_band(c2, camY2);
        // rib: joins both cams over X 292..300 and hangs from the beam
        translate([bkX[0], ribY[0], v18_tz(389)]) cube([bkX[1]-bkX[0], ribY[1]-ribY[0], bkZ-v18_tz(389)]);
        for (c=[c1, c2]) hull() for (q=[c[0], c[len(c)-1]]) translate([q[0]-0.25, c==c1 ? camY1[0] : camY2[0], q[2]+5]) cube([0.5, 3.1, 2]);   // stiffening top flange
        // v1.6 (print fix): strut from the E1 cam band's +X end to the rib (the E1 band was a loose second body). It rises
        // at 35 deg from the band to the rib (in the print pose, on the rib's +X face, it needs no support).
        hull() { translate([c1[0][0]-0.25, camY1[0], c1[0][2]-1.3]) cube([0.5, camY1[1]-camY1[0], 8.3]);
                 translate([bkX[0]+4, ribY[0]+1.6, v18_tz(389)]) cube([0.5, ribY[1]-ribY[0]-1.6, 6]); }
        // v1.6: the E2 band's +X end reaches the rib's +X face (X 300, the bed in the print; it ended 0.14 mm short)
        let(q=c2[0]) translate([q[0]-0.25, camY2[0], q[2]-1.3]) cube([bkX[1]-q[0]+0.25, camY2[1]-camY2[0], 6.3]);
        // v1.7 (J60): a 6 mm (v1.7t) flange on the rib top, under the beam; one M3 x 12 (v1.7t) up through it, nut in a pocket in the beam
        // top (flush: the beam top is the coaster's top). Glue face 8 x 13 mm on the beam too.
        translate([bkX[0], 77, bkZ-6]) cube([bkX[1]-bkX[0], 13, 6]);   // (v1.7t: 6 thick: M3 x 12 from under it ends flush with the beam top)
    }
    translate([bk_xm, v17_camy, bkZ-7]) cylinder(d=m3_clear, h=9, $fn=16);
    // 0.4 mm clearance around the pin's real path (pin r 1.5) -> the cam faces
    pin_clear(pinpts(E1O, function(a) E1_hornpin(a), e1sw(), E1_tipspan()), camY1);
    pin_clear(pinpts(E2O, function(a) E2_hornpin(a), e2sw(), E2_tipspan()), camY2);
}
// v1.6 (print fix): the bracket (443 mm tall) is 3 printed pieces: lower post (with the foot), upper post, and the beam
// (with the arm and the pulley cheek). Joints: half laps through the post's X thickness (the lower post and the beam
// keep X 292..296, the upper post X 296..300), 2 countersunk M3 x 12 (v1.7t) each (head flush in the X 300 face: the base
// edge; nut in a pocket in the X 292 face). The lower post prints on its X 292 face, the upper post on its X 300 face,
// the beam upside down: no support. The tip cams are a separate print (part 39); v1.5 cut them out of the bracket,
// which left 24 zero-volume slivers.
bk_L1 = [v18_sz(230), v18_sz(260)];                                   // post lap (Z), clear of the back panel bolts at Z 200 and 340
function bk_L2() = [bkZ-24, bkZ];                     // post / beam lap
bk_xm = (bkX[0]+bkX[1])/2;                            // 296
module e2_bracket_body() {
    translate([bkX[0], -9, 0]) cube([bkX[1]-bkX[0], 8, bkZ+6]);                                      // post, in front of the back panel
    translate([bkX[0], -9, 0]) cube([bkX[1]-bkX[0], 22, 6]);                                          // foot, screwed to the base
    translate([bkX[0], -9, bkZ]) cube([bkX[1]-bkX[0], bkY[1]+9, 6]);                                    // beam forward to the pulley arm
    translate([E2P1[0]-5.5, bkY[0], bkZ]) cube([bkX[1]-E2P1[0]+5.5, bkY[1]-bkY[0], 6]);              // arm to the pulley
    difference() { translate([E2P1[0]-5.5, 70, E2P1[2]-4]) cube([11, bkY[0]-70+0.01, bkZ+6-(E2P1[2]-4)]);   // cheek
                   translate([E2P1[0], 60, E2P1[2]]) rotate([-90,0,0]) linear_extrude(40) union() { circle(d=pin_press_lying, $fn=fit_fn); rotate(45) square(pin_press_lying/2); }; }
    // v1.7t (fit audit): the P1 pin hole lies in the print (the beam prints upside down). rotate(45) puts the teardrop's point
    // at world -Z = UP in the upside-down print (v1.6/v1.7 had rotate(225): point up in the coaster, i.e. DOWN in the print,
    // and the comment said the opposite); size pin_press_lying (lying press, coupon 2 row 3)
}
module bk_bolts(L, top=false) for (z=[L[0]+7, L[1]-7]) translate([0, -5, z]) {
    translate([bkX[0]-1, 0, 0]) rotate([0,90,0]) cylinder(d=m3_clear, h=10, $fn=16);
    if (!top) {
        translate([bkX[1]-1.71, 0, 0]) rotate([0,90,0]) cylinder(d1=3.4, d2=6.4, h=1.72, $fn=24);       // countersink, flush in the X 300 face
        translate([bkX[0]-0.01, 0, 0]) rotate([0,90,0]) rotate([0,0,30]) cylinder(d=m3_nut, h=2.41, $fn=6);   // nut pocket (flats to +-Y)
    } else
        // v1.7 FEA (stack side): the post / beam lap: no nut pocket in the beam's 4 mm tongue (it left 0.7 mm, SF 1.5).
        // v1.7t: an M3 x 12 countersunk from the upper post's X 300 face (flush; a button-head x 10 from X 292 ended at
        // X 302, past the size limit X 300), the nut on the tongue's plain X 292 face (no pocket anywhere).
        translate([bkX[1]-1.71, 0, 0]) rotate([0,90,0]) cylinder(d1=3.4, d2=6.4, h=1.72, $fn=24);
}
// v1.7 (J3): the back panel's M3 x 16 (v1.7t; 4 since the FEA round) go into the post (3.4 along Y), nut in a pocket in the post's front face (Y -1)
// v1.7 FEA (stack side): a 4th bolt at Z 395.6 (the panel's top rail is solid there): a 2 N push on the P1 cheek moved
// it 4 to 7 mm with the top bolt at Z 340 (103 mm of free post)
bk_bpz = [v18_sz(60), v18_sz(200), v18_sz(340), v18_tz(395.6)];
// v1.7t: the pockets lie in both post prints (on their X faces); a hex corner is along world X = up in both prints
module bk_panel_holes() for (z=bk_bpz) { translate([bk_xm, -10, z]) rotate([-90,0,0]) linear_extrude(10) union() { circle(d=m3_clear, $fn=16); rotate(45) square(m3_clear/2); }
    translate([bk_xm, -1-2.6, z]) rotate([-90,0,0]) cylinder(d=m3_nut_lying, h=2.61, $fn=6); }
// v1.7 (J59): one M3 x 12 countersunk up from under the base through the foot, nut in a pocket in the foot top
module bk_foot_hole() { translate([bk_xm, 10, -1]) cylinder(d=m3_clear, h=8, $fn=16); translate([bk_xm, 10, 6-2.6]) cylinder(d=m3_nut_lying, h=2.61, $fn=6); }   // (lying in 38a's print, corner along X = up)
// v1.7: in the beam: the tip cam bolt's nut pocket (top, flush) and 2 heat-set inserts (from below) for the funnel hanger
v17_camy = 79.8;
module bk_beam_holes() { translate([bk_xm, v17_camy, bkZ-1]) cylinder(d=m3_clear, h=8, $fn=16);
    translate([bk_xm, v17_camy, bkZ+6-2.6]) cylinder(d=m3_nut, h=2.7, $fn=6);
    // v1.7t (no heat-set inserts): the funnel hanger's 2 M3 x 16 go DOWN from the beam top (countersunk, flush: the top is
    // the coaster's top) through beam + hanger flange, nuts under the flange
    for (y=v17_fhy) translate([v17_fhx, y, bkZ-1]) { cylinder(d=m3_clear, h=8, $fn=16); translate([0,0,bkZ+6-1.72-(bkZ-1)]) cylinder(d1=3.4, d2=6.4, h=1.73, $fn=24); } }
module bk_box(x0, x1, z0, z1) translate([x0, -20, z0]) cube([x1-x0, 120, z1-z0]);
module e2_bracket_lo() difference() { intersection() { e2_bracket_body(); union() { bk_box(280, 310, -1, bk_L1[0]); bk_box(bkX[0]-1, bk_xm, bk_L1[0]-0.01, bk_L1[1]); } }
                                      bk_bolts(bk_L1); bk_panel_holes(); bk_foot_hole(); }
module e2_bracket_hi() difference() { intersection() { e2_bracket_body(); translate([0, -20, 0]) cube([1000, 19, 1000]);   // the post only (Y < -1)
                                          union() { bk_box(bk_xm, bkX[1]+1, bk_L1[0], bkZ+7); bk_box(280, 310, bk_L1[1], bk_L2()[0]); } }
                                      bk_bolts(bk_L1); bk_bolts(bk_L2(), true); bk_panel_holes(); }
// v1.7 FEA (stack side): under dead x5 the P1 cheek moved 14 mm (beam 8 x 6 mm, 89 mm out from the post): a gusset web
// under the beam from the post face (Y -1, Z 400) to Y 23 (Z 436), behind the funnel hanger flange (Y 24)
// (down to Z 400: it bears on the solid upper post, below the lap)
module bk_gusset() hull() { translate([bkX[0], -1.01, v18_tz(400)]) cube([bkX[1]-bkX[0], 1, 1]); translate([bkX[0], 22, bkZ-1]) cube([bkX[1]-bkX[0], 1, 1.01]); }
module e2_bracket_beam() difference() { union() { intersection() { e2_bracket_body();
                                          union() { bk_box(200, 310, bkZ, bkZ+7); bk_box(240, 280, bkZ-20, bkZ+1); bk_box(bkX[0]-1, bk_xm, bk_L2()[0]-0.01, bkZ+1); } }
                                        bk_gusset(); }
                                        translate([bk_xm, -9.01, bkZ-1]) cube([bkX[1]-bk_xm+1, 8.01, 8]);   // the upper post's half at the corner
                                        bk_bolts(bk_L2(), true); bk_beam_holes(); st_cheek_holes(); lh_arm_hole(); }
// ---- v1.7t (FEA open items, stack side): 2 braces for the E2 top bracket ----
// 38d P1 strut: the bracket's beam is a cantilever 97 mm forward from the post; under dead x5 (P1 rope 7.1 N, T = 1 N)
// it gave SF 0.7..0.9 and 8.8 mm. The strut ties the P1 cheek to the P3 plate (bolted to the front frame, stiff in its
// own plane) under the rope (rope Z >= 440.36; strut Z 423..439.5, over E2's sweep, Z <= 421.2): along the plate's front
// face (Y 64.15..68.15, X 212..238), in front of the P1 pulley (Y >= 70.5) to the cheek's -X face. Fixings: 2 M3 x 12
// through strut + plate (nuts on the plate's back face), 1 M3 x 16 along X through the strut's end flange and the cheek
// (nut in a lying pocket in the cheek's +X face), + CA on both faces. Prints flat on its -Z face (Z 423).
st_z = [v18_tz(423), v18_tz(439.5)]; st_t = 4; st_y2 = 70.5;
st_p3b = [[215.5, v18_tz(431.25)], [223.5, v18_tz(431.25)]];       // M3 through strut + P3 plate (X, Z)
st_ckb = [77, v18_tz(435.5)];                               // M3 along X through flange + cheek (Y, Z): 4.4 mm over the P1 pin
module p1_strut() let(xc=E2P1[0]-5.5) difference() {
    union() {
        translate([212, p3_y1, st_z[0]]) cube([238-212, st_t, st_z[1]-st_z[0]]);
        hull() { translate([236, p3_y1, st_z[0]]) cube([2, st_t, st_z[1]-st_z[0]]); translate([242, st_y2, st_z[0]]) cube([2, st_t, st_z[1]-st_z[0]]); }
        translate([242, st_y2, st_z[0]]) cube([xc-242+0.01, st_t, st_z[1]-st_z[0]]);
        translate([xc-4, st_y2, st_z[0]]) cube([4, 82-st_y2, st_z[1]-st_z[0]]);                 // end flange on the cheek's -X face
    }
    for (q=st_p3b) translate([q[0], 55, q[1]]) rotate([-90,0,0]) cylinder(d=m3_clear, h=20, $fn=16);
    translate([xc-10, st_ckb[0], st_ckb[1]]) rotate([0,90,0]) cylinder(d=m3_clear, h=30, $fn=16);
}
// the strut's holes in the P3 plate (40) and the cheek (38c): clearance + the lying nut pocket in the cheek's +X face
// (38c prints upside down: the hex corner points to world -Z = up in the print)
module st_p3_holes() for (q=st_p3b) translate([q[0], 55, q[1]]) rotate([-90,0,0]) cylinder(d=m3_clear, h=20, $fn=16);
module st_cheek_holes() let(xc=E2P1[0]+5.5) { translate([xc-14, st_ckb[0], st_ckb[1]]) rotate([0,90,0]) cylinder(d=m3_clear, h=20, $fn=16);
    translate([xc-2.6, st_ckb[0], st_ckb[1]]) rotate([0,90,0]) rotate(0) cylinder(d=m3_nut_lying, h=2.61, $fn=6); }   // (rotate(0): a hex corner along local +X = world -Z after rotate([0,90,0]))
// 38e ledge hanger: the E1 ledge (tray A, X 256..284) is the end of a cantilever from the hanger at X 200: the ball's hit
// (14 N est.) gave SF 0.35 and 7.9 mm. The hanger comes from the E2 bracket arm's front face (Y 88..91, over the tip cams,
// Z >= 437.2) forward over E1's sweep (Z >= 395 while Y < 116) to Y 125.5, then down beside the ledge's +X end (X
// 284.3..288.3) to a saddle under the ledge (cut to its underside, CA). 1 M3 x 12 along Y through flange + arm (nut on
// the arm's back face). Prints flat on its +X face (X 288.3).
lh_bx = 285.3; lh_x = [284.3, 288.3]; lh_y = [90.8, 125.5]; lh_z = [v18_tz(395), v18_tz(443.06)]; lh_leg = [117.5, 125.5]; lh_bz = v18_tz(440.06);
module ledge_hanger() difference() {
    union() {
        translate([lh_x[0]-2, lh_y[0], lh_z[0]]) cube([lh_x[1]-lh_x[0]+2, lh_y[1]-lh_y[0], lh_z[1]-lh_z[0]]);   // forward plate (v1.7t FEA: 6 thick, X 282.3..288.3: 2 N side push SF 1.45 with 4)
        translate([lh_x[0]-2, 88, v18_tz(437.2)]) cube([lh_x[1]-lh_x[0]+2, 3.81, lh_z[1]-v18_tz(437.2)]);                  // flange on the arm's front face (X 282.3..288.3: flush with the +X print face)
        translate([lh_x[0], lh_leg[0], v18_tz(362)]) cube([lh_x[1]-lh_x[0], lh_leg[1]-lh_leg[0], lh_z[0]-v18_tz(362)+0.01]); // leg
        translate([278, lh_leg[0], v18_tz(362)]) cube([lh_x[0]-278+0.01, lh_leg[1]-lh_leg[0], 9]);                    // saddle under the ledge (cut below)
    }
    tray_e1_a();
    translate([lh_bx, 80, lh_bz]) rotate([-90,0,0]) cylinder(d=m3_clear, h=20, $fn=16);
}
module lh_arm_hole() translate([lh_bx, 80, lh_bz]) rotate([-90,0,0]) cylinder(d=m3_clear, h=12, $fn=16);
module e2_bracket() color("#4a5360") {
    e2_bracket_lo(); e2_bracket_hi(); e2_bracket_beam(); p1_strut(); ledge_hanger();
    color("silver") translate([E2P1[0], 62, E2P1[2]]) rotate([-90,0,0]) cylinder(d=3, h=bkY[0]-70+8.5+1.5, $fn=12);  // pulley pin (v1.7: 3 x 22)
    tipcams();
}
// v5: P3 bracket on the stack's front top beam: carries Elevator 2's second top pulley (P3) and the rope anchor, and
// the "ELEVATOR 2  TYPE 2" label (6 mm raised text, seen from the front over the gap knob).
E2P3 = [262, 67, -v18_dZ] + E2_info()[7];
// v1.7 FEA (stack side): the v1.6 plate hung on 2 bolts into the 4 x 4 front top beam (bosses at X 80, 190). Dead x5 (P3
// pulley, rope anchor, 2 tray hangers) twisted and bent that beam: SF 0.28, 6.8 mm. Now the plate is the beam: 197 mm wide
// (X 30..226.8), Z 380..443.06, 2.5 mm thick, in FRONT of the doubler strips (Y 61.65..64.15), bolted through plate,
// strip and post at Z 385 on both posts (M3 x 16 (v1.7t), nut on the post's back face) and, as before, to the 2 beam bosses
// (the right one; a spacer block 4 mm behind the plate). A notch X 69..91 under Z 406.5 lets E2's P2 and pot pass. The P3 pin sits in a d 8 boss behind the plate (Y 57.65..61.65) + the plate:
// 6.5 mm pressed (as v1.6); a 0.6 mm recess round the pulley keeps it 0.95 mm off the plate; a d 6 spacer for the bearing.
// Print pose: standing on its bottom edge (Z 380), layers horizontal; the boss, spacer and anchor arm have 45 deg undersides.
p3_y0 = postYf[1] + v17_fdbl; p3_t = 2.5; p3_y1 = p3_y0 + p3_t;     // plate Y 61.65 .. 64.15
p3_sz = v18_tz(385);                                                          // the strip bolts (Z)
module p3_bracket() color("#4a5360") {
    difference() {
        union() {
            translate([postX[0]-4, p3_y0, v18_tz(380)]) cube([postX[1]-postX[0]+8, p3_t, 443.06-380]);              // plate on the strips
            translate([E2P3[0], postYf[1], E2P3[2]]) rotate([-90,0,0]) { cylinder(d=8, h=p3_y0-postYf[1]+0.01, $fn=24);   // P3 pin boss (behind)
                linear_extrude(p3_y0-postYf[1]+0.5) polygon([[-3.9*cos(45), 3.9*sin(45)], [0, 3.9/sin(45)], [3.9*cos(45), 3.9*sin(45)]]); }   // (45 deg point under it: print)
            hull() { translate([v17_p3x[1]-5, postYf[1], v18_tz(389.5)]) cube([10, p3_y0-postYf[1]+0.5, 10.3]);   // spacer on the right beam boss
                     translate([v17_p3x[1]-5, p3_y0+0.5, v18_tz(385.5)]) cube([10, 0.01, 4]); }                      // (45 deg underside: print)
            translate([E2P3[0], p3_y1-0.61, E2P3[2]]) rotate([-90,0,0]) cylinder(d=6, h=64.3-p3_y1+0.61, $fn=24);   // bearing spacer
            hull() { translate([E2ANC[0]-4, p3_y1-0.5, E2ANC[2]-3]) cube([8, 69-p3_y1+0.5, 6]);          // anchor arm
                     translate([E2ANC[0]-4, p3_y1-0.5, E2ANC[2]-3-4.9]) cube([8, 0.01, 4.9]); }          // (45 deg underside: print)
        }
        translate([E2P3[0], p3_y1-0.6, E2P3[2]]) rotate([-90,0,0]) difference() { cylinder(r=11.5, h=1, $fn=48); translate([0,0,-1]) cylinder(d=6, h=3, $fn=24); }   // recess round the pulley
        translate([E2P3[0], 50, E2P3[2]]) rotate([90,0,180]) linear_extrude(30) union() { circle(d=pin_press_lying, $fn=fit_fn); rotate(45) square(pin_press_lying/2); }   // v1.7t: lying press (the plate prints on its bottom edge), point up
        translate([E2ANC[0]-6, 66, E2ANC[2]]) rotate([0,90,0]) cylinder(d=2, h=12, $fn=10);                  // tie hole for the rope end
        translate([E2ANC[0], 67, v18_tz(420)]) cylinder(d=2.6, h=E2ANC[2]-v18_tz(420), $fn=12);                            // (the rope comes up to the tie through the chamfer)
        translate([v17_p3x[1], 50, v18_tz(394.65)]) rotate([-90,0,0]) cylinder(d=m3_clear, h=20, $fn=16);         // M3 into the right beam boss
        translate([0, 70, 0]) rotate([90,0,0]) linear_extrude(20) translate([0, -v18_dZ]) polygon([[69, 379], [91, 379], [91, 406.5], [80, 417.5], [69, 406.5]]);   // notch: E2's P2 and pot pass here (Y 61..64 at X 71.5..88.5); pointed top (print)
        for (x=postX) translate([x, 50, p3_sz]) rotate([-90,0,0]) cylinder(d=m3_clear, h=20, $fn=16);     // M3 through the strips and posts
        for (x=v17_hx, z=v17_hz) translate([x, 50, z]) rotate([-90,0,0]) cylinder(d=m3_clear, h=20, $fn=16);   // tray hangers
        st_p3_holes();                                                                                    // v1.7t: the 38d strut
    }
    color("#f4f1ea") translate([163, p3_y1-0.01, v18_tz(430.5)]) rotate([90,0,180]) linear_extrude(0.81) text("ELEVATOR 2  TYPE 2", size=6.2, halign="center", valign="center", font="Liberation Sans:style=Bold");
    color("silver") translate([E2P3[0], 58, E2P3[2]]) rotate([-90,0,0]) cylinder(d=3, h=14, $fn=12);
}

// ================= v1.7 (stack side): every part held, every joint fixed (docs/coaster_v1.7_stack.md, joints_v1.7.md) ====
// ---- E1 tray (J43): 3 tabs on the tray's back side (Y 116..124.5, 8 mm under the lip, out of the ball channel), each with
// an M3 x 12 down into a heat-set insert in its support: the tray arm on the front-left post (X 34, piece B) and 2
// hangers from the P3 bracket (X 120, 200, piece A). Tab bottoms lie on the piece's print plane (no support).
v17_trayx = [34, 120, 200]; v17_hx = [120, 200]; v17_hz = [v18_tz(405), v18_tz(412)];
function v17_tpl(x, y) = x >= tr_x ? tr_axz(x) - 12.725 : tr_plB(x, y);
module tray_tab(x) difference() {
    hull() for (xx=[x-4.5, x+4.5], yy=[116, 124.5]) translate([xx-0.005, yy-0.005, v17_tpl(xx, yy)]) cube([0.01, 0.01, 7]);
    translate([x, 119.5, 300]) cylinder(d=m3_clear, h=200, $fn=16);
}
// hanger: flange on the P3 bracket's front face (2 M3 x 12, nuts behind the bracket plate), arm forward over the E1
// lever at Z 395..401, drop at Y 109..115 (behind the tray, in front of the E1 lever plane), foot under the tab
module tray_hanger(x) let(kz=tr_axz(x)-12.725) difference() {
    union() {
        translate([x-4, p3_y1, v18_tz(395)]) cube([8, 4, 20]);
        translate([x-4, p3_y1, v18_tz(395)]) cube([8, 115-p3_y1, 6]);
        translate([x-4, 109, kz-7]) cube([8, 6, v18_tz(401)-(kz-7)]);
        hull() for (xx=[x-4, x+4]) translate([xx-0.005, 109, kz-7]) cube([0.01, 15, tr_axz(xx)-12.725-(kz-7)]);
    }
    for (z=v17_hz) translate([x, 59, z]) rotate([-90,0,0]) cylinder(d=m3_clear, h=12, $fn=16);
    translate([x, 119.5, kz-8]) cylinder(d=m3_clear, h=9, $fn=16);                          // v1.7t: M3 x 16 down from the tray tab,
    translate([x, 119.5, kz-7-0.01]) cylinder(d=m3_nut_lying, h=2.61, $fn=6);                // nut in a pocket under the foot (lying in the print, corner up)
}
// tray arm: flange on the front-left post's front face (2 M3 x 16 (v1.7t) through strip and post, nuts behind), arm forward under the tab
module tray_arm() let(kz=min([for (xx=[30, 38], yy=[109, 124]) tr_plB(xx, yy)])) difference() {
    union() {
        translate([30, postYf[1]+v17_fdbl, v18_tz(345)]) cube([8, 4, 23.5]);
        translate([30, postYf[1]+v17_fdbl, kz-7]) cube([8, 109.01-postYf[1]-v17_fdbl, 6.5]);
        hull() for (xx=[30, 38], yy=[109, 124]) translate([xx-0.005, yy-0.005, kz-7]) cube([0.01, 0.01, tr_plB(xx, yy)-(kz-7)]);
    }
    for (z=v17_armz) translate([34, postYf[1]+v17_fdbl-1, z]) rotate([-90,0,0]) cylinder(d=m3_clear, h=6, $fn=16);
    translate([34, 119.5, kz-8]) cylinder(d=m3_clear, h=9, $fn=16);                         // v1.7t: M3 x 16, nut under the foot (as the hangers)
    translate([34, 119.5, kz-7-0.01]) cylinder(d=m3_nut_lying, h=2.61, $fn=6);
}
// ---- cages (J41, J62): each cage stood on nothing. A stand under the corner rod (+x, -y): the rod goes 8 mm into it
// (press). Right: on the base, 2 M3 x 12 countersunk up from under the base. Left: on the base against the back panel,
// 2 M3 x 16 from behind the panel, nuts in pockets (v1.7t; v1.7 had heat-set inserts).
module cage_stand_R() difference() {
    union() { translate([276.75, 23.25, 0]) cube([6, 6, 70]); translate([265, 16, 0]) cube([30, 18, 3]);   // v1.8: foot X 265..295, Y 16..34 (grid nodes)
              translate([v18_csR_pin[0], v18_csR_pin[1], 0]) cylinder(d=8, h=5, $fn=32);
              // v1.7 FEA: a 2 N push on the cage bottom gave SF 1.7 (layers) at the sharp column root: tapered root,
              // 10 x 10 at the foot to 6 x 6 at Z 25 (clear of the 2 bolt heads)
              difference() { hull() { translate([274.75, 21.25, 0]) cube([10, 10, 3]); translate([276.75, 23.25, 25]) cube([6, 6, 0.01]); }
                             for (h=v18_csR_bolt) translate([h[0], h[1], 2.99]) cylinder(d=7.4, h=30, $fn=24); } }   // (nut seats clear)
    translate([279.75, 26.25, 61.99]) cylinder(d=pin_press, h=9, $fn=fit_fn);
    for (h=v18_csR_bolt) translate([h[0], h[1], -1]) cylinder(d=m3_clear, h=5, $fn=16);
    translate([v18_csR_pin[0], v18_csR_pin[1], -0.01]) cylinder(d=pin_press, h=5, $fn=fit_fn);
}
v18_csR_bolt = [[270, 20], [290, 20]]; v18_csR_pin = [270, 30];
// v1.7t (no heat-set inserts): the stand is 9 wide (X -25.95..-16.95, was 6, grown toward -X: the levelling screw at
// X -14 stays 1.45 mm off) for 2 M3 nuts in side-entry pockets from its +X face (hex corner up, M3 x 16 from behind the panel)
module cage_stand_L() difference() {
    translate([-25.95, -9, 0]) cube([9, 16.25, 52]);
    translate([-19.95, 4.25, 43.99]) cylinder(d=pin_press, h=9, $fn=fit_fn);
    for (z=v17_lstz) { translate([-19.95, -9.01, z]) rotate([-90,0,0]) cylinder(d=m3_clear, h=12, $fn=16);
        translate([-19.95, -2.4, z]) rotate([-90,0,0]) rotate([0,0,30]) cylinder(d=m3_nut_lying, h=2.6, $fn=6);
        translate([-19.95, -2.4, z-m3_nut_lying/2]) cube([4, 2.6, m3_nut_lying]); }
}
v17_lstz = [15, 38];
// ---- E1 feed (J39) and E2 feed (J79): they had no support. Printed stands on the base (2 M3 x 12 countersunk from
// under the base each); the top is a saddle cut to the trough's outer surface: glue face (CA), about 60 mm2 each.
// The E2 feed also gets a saddle on the front-right lower post (frame part 06f, glue face about 40 mm2).
module trough_outer(pts, r=ball_r+0.8+2.4) for (k=[0:len(pts)-2]) hull() { translate(pts[k]) sphere(r=r, $fn=20); translate(pts[k+1]) sphere(r=r, $fn=20); }
module feed_stand(c0, c1, zt, f0, f1, holes, pts, pins=[]) difference() {
    union() { translate([c0[0], c0[1], 0]) cube([c1[0]-c0[0], c1[1]-c0[1], zt]); translate([f0[0], f0[1], 0]) cube([f1[0]-f0[0], f1[1]-f0[1], 3]);
              for (p=pins) translate([p[0], p[1], 0]) cylinder(d=8, h=5, $fn=32);   // v1.8: locating pin boss
              // v1.7 FEA: the ball's hit on the E1 feed's felt corner (10 N est.) gave SF 1.2 (layers) at the column's sharp
              // root: a 45 deg root 2.5 mm out, 2.5 mm up, clear of the 2 nut seats (d 7.4)
              difference() { hull() { translate([c0[0]-2.5, c0[1]-2.5, 0]) cube([c1[0]-c0[0]+5, c1[1]-c0[1]+5, 3]);
                                      translate([c0[0], c0[1], 5.5]) cube([c1[0]-c0[0], c1[1]-c0[1], 0.01]); }
                             for (h=holes) translate([h[0], h[1], 2.99]) cylinder(d=7.4, h=10, $fn=24); } }
    trough_outer(pts);
    for (h=holes) translate([h[0], h[1], -1]) cylinder(d=m3_clear, h=5, $fn=16);
    for (p=pins) translate([p[0], p[1], -0.01]) cylinder(d=pin_press, h=5, $fn=fit_fn);   // (standing in the print: foot down)
}
// v1.8 (grid): bolts and locating pins on grid nodes; the feet grow to reach them ([6] = pins)
E1STAND = [[[209, 139], [221, 151], 46, [196, 134], [227, 157], [[200, 140]], [[200, 150]]],   // v1.7 FEA: 57a 12 x 12 (the ball hits the felt corner over it)
           [[202.5, 108], [210.5, 116], 36, [195, 96], [214, 125], [[200, 120]], [[210, 100]]]];
E2STAND = [[235, 65], [243, 73], 31, [226, 65], [248, 84], [[240, 80]], [[230, 80]]];
module e1_feed_stand(k) let(q=E1STAND[k]) feed_stand(q[0], q[1], q[2], q[3], q[4], q[5], E1feed, q[6]);
// v1.7t: the root's -Y side is cut at Y 64.6: the gate cord (Y 63, Z 4) passed it with 0 mm to spare (0.5 mm check)
module e2_feed_stand() let(q=E2STAND) intersection() { feed_stand(q[0], q[1], q[2], q[3], q[4], q[5], [for (k=[2:len(E2feed)-1]) E2feed[k]], q[6]);
    translate([200, 64.6, -1]) cube([100, 60, 100]); }
module e2feed_saddle() difference() { translate([postX[1]+4-0.01, postYf[0], 31.6]) cube([6.21, 4+v17_fdbl, 10]); trough_outer([for (k=[2:len(E2feed)-1]) E2feed[k]]); }
// ---- E2 funnel (J62/J64): the funnel sat on the 4 rods only. A hanger plate up from its +X rim to the E2 bracket's
// beam, flange under the beam, 2 M3 x 12 up into heat-set inserts in the beam
v17_fhx = 295; v17_fhy = [27, 49];
module e2f_hanger() { translate([294.4, 32, e2fz(298, 38)-1.9]) cube([3.6, 12, bkZ-e2fz(298, 38)+1.9]);
                      translate([292, 24, bkZ-7]) cube([6, 28, 7]); }
module e2f_hanger_holes() for (y=v17_fhy) translate([v17_fhx, y, bkZ-8]) cylinder(d=m3_clear, h=9, $fn=16);
// ---- pulley pin collars (J53, J54): d 7 x 2.2, 3.15 press hole (+ CA), 0.3 mm from the pulley
module pulley_collar() rotate([-90,0,0]) difference() { cylinder(d=7, h=2.2, $fn=32); translate([0,0,-1]) cylinder(d=pin_press, h=5, $fn=fit_fn); }
// ---- base and back panel holes
// M3 through the base, 90 deg countersink 6.5 mm from the underside (heads flush under the base)
function v17_base_m3() = concat(
    [[54,125], [136,125], [54,133], [136,133], [20,60], [20,72], [219.3,127.6], [227.8,127.6], [116.1,87], [140.1,87],
     [235.5,92.6], [244.0,92.6], [-13,52], [-13,102], [-13,152]],                     // elevators + card holder (coordinator)
    [for (f=[0,1], k=[0,1]) [postX[k], v17_footY[f]]],                                // J12 frame feet
    [[296, 10]], [[273.5, 19], [288, 29]],                                            // J59 E2 bracket foot, cage stand R
    [for (q=E1STAND) each q[5]], E2STAND[5],                                          // feed stands
    [[275, 70], [275, 125]], [[249, finish_y+4.5], [265, finish_y+4.5]],              // J80 finish track, J81 finish line
    [[v17_gleg[0], -5.5], [v17_gleg[1], -5.5], [CG[0][0]-8, 68.5], [CG[0][0]+6.5, 68.5], [CG[1][0]+4.5, CG[1][1]-5.5], [CG[1][0]-1.5, CG[1][1]-5.5], gt_cbolt[0], gt_cbolt[1]]);   // J58 cord guides (v1.7t: guide 62 moved)
v17_wood = [[-22, -12], [137, -12], [296, -12]];   // J1 (v1.7t): 3 x M3 x 16 countersunk up through the base into the panel's edge (2.5 pilot), + wood glue
function v17_panel_m3() = concat([for (z=fr_bpz(0)) [postX[0], z]], [for (z=fr_bpz(1)) [postX[1], z]], [for (z=bk_bpz) [296, z]],
    [[-8.2-10.8, CH[1][3]-3]], [for (z=v17_lstz) [-19.95, z]], v17_glug);
module v17_ladder_supports() { cage_stand_R(); cage_stand_L(); for (x=v17_hx) tray_hanger(x); tray_arm(); }
// pulley pin collars on P1 (Y 62..64.2) and P3 (Y 69.8..72)
module v17_collars() color("#4a5360") { translate([E2P1[0], 62, E2P1[2]]) pulley_collar(); translate([E2P3[0], 69.8, E2P3[2]]) pulley_collar(); }
module v17_feed_stands() { e1_feed_stand(0); e1_feed_stand(1); e2_feed_stand(); }
// ---------------- base, back panel, feet ----------------
// v5: base front edge at Y 161.5 (the E1 feed's wall reaches 161.7; v4 162)
Lx0 = -26; L = 300; Wy0 = -15; Wy1 = 161.5;     // base from X -26 (left channel) to 300
module base() { base_plate(); back_panel(); v18_grid_pins(); }
module feet() lev_wheels();

// ---------------- elevators (rig coordinates placed) ----------------
module elevators(a1=e1a, a2=e2a) {
    translate([245.8, 103, 0]) E1_v1(a1, ball=false);
    translate([262, 67, 0]) E2_v1(a2);
}

// v5: cords and ropes in world coordinates (checks and pictures)
module E1cords_w(a) translate(E1O) E1_cords(a);
module E2rope_w(a) translate(E2O) E2_rope(a);
// the ES pencil (hex 7.0 / 7.6) in the open-top cradle, seated on the notch's downstream face, for the 4.g check
// (v1.7r; v1.5..v1.7: a 7.5 mm hex at n 11.5, w -40..60, in an 8.4 mm "hole" that cut nothing)
module pencil(dt=0.7, dn=0, w0=-2, len=150) at_loop() CL_pencil(dt, dn, w0, len);
// ---------------- whole coaster ----------------
module v18_stack_hw() { for (i=[0:n-1]) v18_j6_hw(i); for (i=[0:n-2]) v18_j10_hw(i); }   // v1.8: J6 / J10 pins and screws
module stack() { for (i=[0:n-1]) ramp(i); for (i=[0:n-2]) uturn(i); frame(); gapdrive(); v18_stack_hw(); }
module ladders() { cage(0); cage(1); carriage(1, k1); carriage(0, k2); }
echo(E1top=E1top, E1end=E1end, E2top=E2top, E2end=E2end);
module coaster() {
    base(); feet();
    stack();
    ladders(); tops();
    gate(); gate_legs(); feeds(); e1feed(); gate_cord(); cord_guides(); v17_feed_stands(); v17_ladder_supports(); holder(); v17_collars();
    elevators(); e2_bracket(); pads();
    at_loop() CL_v1(); loop_brackets(); p3_bracket();
    color("silver") at_loop() translate(CL_ballstart()) sphere(r=ball_r, $fn=24);                     // ball at the start, resting on the pencil
}
// ---- groups for the collision checks (check_v1.py) ----
// static = never moves during a run. Carriages are static in a run (set before it), checked at every position.
module static_parts(g=gap, skip="", nf=false, nt=false) {   // nf: (v5b: no flaps any more, ignored); nt: the latch trip pins (the ball presses them)
    if (skip!="base")   { base(); feet(); holder(); }
    if (skip!="stack")  { for (i=[0:n-1]) ramp(i); for (i=[0:n-2]) uturn(i); frame(); gapdrive(); v18_stack_hw(); }
    if (skip!="ladder") { cage(0); cage(1); tops(); v17_ladder_supports(); }
    if (skip!="feeds")  { gate(); gate_legs(); feeds(); e1feed(); v17_feed_stands(); cord_guides(); }
    if (skip!="loop")   { at_loop() CL_v1(); loop_brackets(); }
    if (skip!="e1")     translate([245.8, 103, 0]) { if (nt) E1_static_nt(); else E1_static(); }
    if (skip!="e2")     translate([262, 67, 0]) { if (nt) E2_static_nt(); else E2_static(); }
    if (skip!="bracket") { e2_bracket(); p3_bracket(); v17_collars(); }
}
module all_carriages() { for (i=CH[0][4]) carriage(0, i); for (i=CH[1][4]) carriage(1, i); }
if (part=="assembly") coaster();
if (part=="stack") stack();
if (part=="elevators") elevators();
if (part=="ladders") ladders();
if (part=="loop") at_loop() CL_v1();
echo(str("Ztop ", Ztop, "  yS ", yS, "  yK ", yK, "  pitch ", Pp, "  ramp 19 end ", rend(18)));
echo(ladder_right=[ for (i=CH[0][4]) [i+1, cupEntryZ(i)] ], ladder_left=[ for (i=CH[1][4]) [i+1, cupEntryZ(i)] ]);
// v5b printable parts (world pose; lay them flat in the slicer): E1 tray with its ledge, E2 funnel, loop brackets and
// spacer (print 4), gap slide, peg plate
if (part=="tray_e1")        tray(1);
if (part=="e2_funnel")      e2_funnel();
if (part=="loop_bracket_R") loop_bracket_R();
if (part=="loop_bracket_L") loop_bracket_L();
if (part=="loop_spacer")    loop_spacer([0, 0]);
if (part=="gap_slide")      pg_slide_s(0);
if (part=="peg_plate")      intersection() { gd_static(); translate([30, 60, -0.01]) cube([90, 40, 2.02]); }
