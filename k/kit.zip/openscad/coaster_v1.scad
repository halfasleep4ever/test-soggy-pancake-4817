// ROLLER COASTER R3 - full design, now VERSION 5 (2026-10-28; file name kept so the sim export and Fusion scripts still
// run). v4 is in cad/v4/ and in git (ca76ce9). v5 = v4 + the fixes in docs/coaster_v5.md (end-supported ramps, ball in
// view, minimal 3 mm basswood with laser files in cad/laser/, E2 rope in its own plane, touching loop lanes, 6 mm
// labels, pencil on the start line, levelling wheels). Everything in mm.
// World axes: X = length (left to right, 0 = left edge), Y = depth (back panel at the back, Y grows toward the
// viewer), Z = up (0 = top of the plywood base). Same layout as the simulator's R3 (sim cm x10), with the real part
// sizes. Shown with ladder 1 -> ramp 7, ladder 2 -> ramp 6, rail gap 14.3 mm.
//
// Ball path: start (pencil) -> chute -> 12 cm loop -> felt corner -> Elevator 1 (Type 1, front) -> fixed catch ledge ->
// front tray -> LEFT ladder channel -> carriage 1 -> ramp 7 ... ramp 19 (U-turn stop cups) -> bottom gate ->
// Elevator 2 (Type 2, back) -> fixed catch funnel -> RIGHT ladder channel -> carriage 2 -> ramp 6 ... ramp 19 -> gate
// (opened by a cord from Elevator 2's lever) -> finish track -> finish line -> felt stop.
//
// v5b (2026-10-28, docs/coaster_v5.md sections 16 to 18): (1) the hinged catch flaps are gone: a fence on each cup floor
// turns the ball off the floor's side edge onto a FIXED ledge (E1) / funnel (E2) beside the cup, where no part of the
// elevator ever goes; (2) no loop board: the loop bolts to Elevator 1's pin plate with printed brackets; (3) the gap
// knob (gears + lead screw) is replaced by a slide with cam slots and a peg plate (pin in numbered holes).
// part = "assembly" (default) | a printable part name (see the list at the end) | a subsystem for checks.
use <common.scad>
use <rail_test.scad>
use <coaster_e1.scad>
use <coaster_e2.scad>
use <coaster_loop.scad>
include <common.scad>

part = "assembly";
gap  = 14.3;                 // rail gap shown (12 .. 16.5)
k1 = 6; k2 = 5;              // ladder targets (0-based ramp index): ramp 7 (left channel, even) and ramp 6 (right, odd)
e1a = -52.2; e2a = -53.1;    // elevator angles shown (rest)

// ---------------- the stack ----------------
th = 2.5; Lr = 200; n = 19; x0 = 30; xRe = x0 + Lr*cos(th);       // ramp ends at X 30 and 229.8
drop = 8.05;                                                         // ball drop in each U-turn cup (exit 2.5 mm below entry)
Pp = Lr*sin(th) + drop;                                              // level pitch 16.77
Z19 = 56;                                                            // ramp 19 end ball line (16 mm above Elevator 2's cup)
Ztop = Z19 + (n-1)*Pp + Lr*sin(th);                                  // ramp 1 start, 366.7
planeY = [16, 38];                                                   // back / front ramp planes (ball line)
function dirOf(i) = i%2 ? -1 : 1;
function entry(i) = [i%2 ? xRe : x0, planeY[i%2], Ztop - i*Pp];
function rend(i)  = entry(i) + [dirOf(i)*Lr*cos(th), 0, -Lr*sin(th)];
cc12 = rod_cc(12); kR = (ball_r + rod_d/2)/ball_r;
d2 = rod_cc(gap) - cc12;                                             // outer rail moved by the gap knob
ballZ0 = 12 + rod_drop(12);                                          // ball line above the spine bottom (gap 12): 20.57
slabOut = 21.1;                                                      // slab reaches this far outward of the inner rod
// a ramp's spine frame: x along the ramp, y = 0 at the inner (fixed) rod, -y outward, z = 0 at the spine bottom
module at_ramp(i) translate(entry(i)) rotate([0,0, i%2 ? 180 : 0]) rotate([0,th,0]) translate([0, cc12/2, -ballZ0]) children();
// both start 1 mm in: the 2.5 deg tilt otherwise pushes the end face 0.9 mm into the cup before it (Fusion check)
// v5 fix 1: every ramp is held only at its two ends (26 mm spine and carrier pieces, as rail_test spine200e /
// carrier200e). The 3 mm rods span the 148 mm between them (sag under the ball about 0.03 mm). The ball shows between
// the ends from the front. The frame tabs (X 34, 222.8) and the comb-frame arms (X 50, 209.8) both land on the ends.
module stack_spine() ends_only(200) intersection() { spine(200); translate([1, -slabOut, -1]) cube([200, slabOut+3.6, 40]); }
module stack_carrier() ends_only(200) intersection() { carrier(200); translate([1, -3, -1]) cube([200, 5, 30]); }
module ramp(i) at_ramp(i) {
    color("#d08a4a") stack_spine();
    color("#59a5c4") translate([0, -rod_cc(gap), 4]) stack_carrier();
    color("silver") { translate([100, 0, 12]) rotate([0,90,0]) cylinder(d=rod_d, h=196, center=true, $fn=12);
                      translate([100, -rod_cc(gap), 12]) rotate([0,90,0]) cylinder(d=rod_d, h=196, center=true, $fn=12); }
}
// U-turn stop cup after ramp i (rail_test stopcup, placed by its test coordinates: ramp end at x 200, ball line y 0,
// gap-12 ball line z 39.69).
test_ball_z = 39.69; test_cup_in = 35.637;
module uturn(i) translate(rend(i)) rotate([0,0, i%2 ? 180 : 0]) translate([-200, 0, -test_ball_z])
    color("#6cbf8f") stopcup(0.5, "STOP", false, test_cup_in - 2.5, side_in=false, zcut=15, x_in=true, lo_walls=true);   // every cup has the ladder slot (left channel: odd cups, right: even); v5: low walls (ball in view)
module uturn_pad(i) translate(rend(i)) rotate([0,0, i%2 ? 180 : 0]) translate([-200, 0, -test_ball_z]) stoppad(0.5, test_cup_in - 2.5, lo_walls=true);
// frame: 4 posts, tabs from every spine to the posts, top beams
postX = [34, 222.8]; postYb = [-9, -5]; postYf = [53.65, 57.65];   // front posts 1 mm out: the carriers reach Y 52.8 at gap 16.5
yS = Ztop + 16; yBeam = yS + 10; yK = yS + 24;
function ballZat(i, x) = entry(i)[2] - abs(x - entry(i)[0])*tan(th);  // ball line height over X on ramp i
// v1.5 frame, kept for reference (one 397 mm piece: too tall for the 270 mm bed)
module frame_v15() color("#4a5360") {
    for (px=postX) { translate([px-4, postYb[0], 0]) cube([8, 4, yBeam+4]); translate([px-4, postYf[0], 0]) cube([8, 4, yBeam+4]); }
    for (py=[postYb[0], postYf[0]]) translate([postX[0]-4, py, yBeam]) cube([postX[1]-postX[0]+8, 4, 4]);
    for (px=postX) translate([px-4, postYb[0], yBeam]) cube([8, postYf[1]-postYb[0], 4]);
    for (i=[0:n-1], px=postX) let(zb=ballZat(i,px)-ballZ0) {
        if (i%2==0) translate([px-3, postYb[1], zb-1]) cube([6, planeY[0]+cc12/2-slabOut-postYb[1], 4]);
        else        translate([px-3, planeY[1]-cc12/2+slabOut, zb-1]) cube([6, postYf[0]-(planeY[1]-cc12/2+slabOut)+0.5, 4]);
    }
}
// v1.6 (print fix, docs/coaster_v1.6_stack.md): the frame is 8 printed pieces, all printed flat (no support):
//  - 2 ladders (f = 0 back, 1 front): the upper part of both posts + the top beam along X + their ramp tabs;
//  - 4 lower posts (f, k = 0 left, 1 right) with their tabs;
//  - 2 cross bars along Y (k = 0 left, 1 right) on top.
// Post joint: an in-plane half lap, 24 mm long, in a splice that is 4 mm wider toward the middle of the stack (12 x 4 mm),
// cut where no tab is. Each half keeps 6 mm of the width; 2 steel pins 2 x 12 mm go across the seam (along X). The lap
// faces are vertical when the piece lies flat, so both halves print with no overhang.
// Corner joint: half lap in Z (the ladder keeps the lower 2 mm, the cross bar the upper 2 mm) + a 2 x 8 mm steel pin.
fr_lapL = 24;                                              // lap length (Z)
fr_mid = [[229.5, 221.25], [237.9, 212.6]];                // lap centre Z [back, front][left, right]: between two tabs
fr_pinD = 2.1;                                             // 2 mm steel pin (press)
function fr_py(f) = [postYb[0], postYf[0]][f];             // post Y (low face), 4 mm thick
function fr_spl(k) = k==0 ? [postX[0]-4, postX[0]+8] : [postX[1]-8, postX[1]+4];   // splice X range (widened inward)
function fr_seam(k) = (fr_spl(k)[0]+fr_spl(k)[1])/2;
function fr_lap(f, k) = [fr_mid[f][k]-fr_lapL/2, fr_mid[f][k]+fr_lapL/2];
// one post with its tabs, as v1.5
module fr_post(f, k) let(px=postX[k]) {
    translate([px-4, fr_py(f), 0]) cube([8, 4, yBeam+4]);
    for (i=[0:n-1]) if (i%2 == f) let(zb=ballZat(i,px)-ballZ0) {
        if (f==0) translate([px-3, postYb[1], zb-1]) cube([6, planeY[0]+cc12/2-slabOut-postYb[1], 4]);
        else      translate([px-3, planeY[1]-cc12/2+slabOut, zb-1]) cube([6, postYf[0]-(planeY[1]-cc12/2+slabOut)+0.5, 4]);
    }
}
module fr_lap_pins(f, k) let(L=fr_lap(f, k)) for (z=[fr_mid[f][k]-7, fr_mid[f][k]+7])
    translate([fr_spl(k)[0]-1, fr_py(f)+2, z]) rotate([0,90,0]) cylinder(d=fr_pinD, h=14, $fn=16);
module fr_corner_pin(f, k) translate([postX[k], fr_py(f)+2, yBeam-4]) cylinder(d=fr_pinD, h=8.01, $fn=16);
// lower post (f, k): below the lap, plus the outer half of the splice
module frame_post_lo(f, k) let(L=fr_lap(f, k), s=fr_spl(k), o=(k==0 ? [s[0], fr_seam(k)] : [fr_seam(k), s[1]])) difference() {
    union() {
        intersection() { fr_post(f, k); translate([-50, -50, -1]) cube([400, 200, L[0]+1]); }
        translate([o[0], fr_py(f), L[0]]) cube([o[1]-o[0], 4, fr_lapL]);
    }
    fr_lap_pins(f, k);
}
// ladder f: both posts above their laps (+ the inner half of each splice), the top beam, the tabs; corners cut to Z yBeam+2
module frame_ladder(f) difference() {
    union() {
        for (k=[0,1]) let(L=fr_lap(f, k), s=fr_spl(k), o=(k==0 ? [fr_seam(k), s[1]] : [s[0], fr_seam(k)])) {
            intersection() { fr_post(f, k); translate([-50, -50, L[1]]) cube([400, 200, 500]); }
            translate([o[0], fr_py(f), L[0]]) cube([o[1]-o[0], 4, fr_lapL]);
        }
        translate([postX[0]-4, fr_py(f), yBeam]) cube([postX[1]-postX[0]+8, 4, 4]);
    }
    for (k=[0,1]) { fr_lap_pins(f, k); fr_corner_pin(f, k);
        translate([postX[k]-4.01, fr_py(f)-0.01, yBeam+2]) cube([8.02, 4.02, 3]); }
}
// cross bar k: the side beam along Y (v1.5) minus the lower half of the two corner squares
module frame_bar(k) let(px=postX[k]) difference() {
    translate([px-4, postYb[0], yBeam]) cube([8, postYf[1]-postYb[0], 4]);
    for (f=[0,1]) { translate([px-4.01, fr_py(f)-0.01, yBeam-1]) cube([8.02, 4.02, 3]); fr_corner_pin(f, k); }
}
module frame() color("#4a5360") {
    for (f=[0,1]) { frame_ladder(f); for (k=[0,1]) frame_post_lo(f, k); }
    for (k=[0,1]) frame_bar(k);
}
// gap drive. v5b fix 3 (Kai, 2026-10-28): a PEG PLATE instead of the 32:16 gears and the left/right lead screw.
// The 2 comb frames (bars at xB, arms to every carrier, guide-rod stubs) stay. Each frame now has a bottom bar (the
// frame is a closed rectangle) with a pin block and a 3 x 20 steel pin pointing down at X pg_xp. Under the stack, on the
// base, a SLIDE moves along X; its two straight cam slots (5.5 deg) carry the pins: slide travel s moves the back frame
// -Y and the front frame +Y by d2 = s * pg_k, the same outer-rail move as the lead screw made. 6 mm of travel = 0.5 mm of
// gap, exactly linear. The slide's arm reaches forward over a fixed PEG PLATE (in front of the stack, X 38..106); a
// 3 x 20 steel pin through the arm's index hole into a numbered hole locks the setting: row A 12.0 .. 16.5 mm (10 holes,
// 0.5 steps), row B half a step on (12.25 .. 16.25, 9 holes): 0.25 mm steps with one pin. The slide is held by two M3
// bolts with spacers in a long slot. Everything is under Z 20: below every ball path and out of the sight lines.
xB = [50, 209.8]; xm = (x0+xRe)/2;
zBarB = planeY[0] + cc12/2 - slabOut - 2 - d2;  zBarF = planeY[1] - cc12/2 + slabOut + 2 + d2;
yG = Z19 - ballZ0 - 16;
pg_p = 6;                                  // hole pitch (slide travel) per 0.5 mm of gap
pg_k = 0.5*rail_k/pg_p;                    // frame move per mm of slide travel (0.0964: 5.5 deg slots)
function pg_d2(g) = rod_cc(g) - cc12;      // outer-rail (frame) move from gap 12
function pg_s(g) = pg_d2(g)/pg_k;          // slide travel for gap g: 0 at 12, 54 at 16.5
pg_xp = 100;                               // the frames' pins (world X)
pg_yb0 = planeY[0] + cc12/2 - slabOut - 2 + 2;   // back pin Y at gap 12 (2 mm inside the frame bar); it moves -d2
pg_yf0 = planeY[1] - cc12/2 + slabOut + 2 - 2;   // front pin Y at gap 12; it moves +d2
pg_z = [2.2, 4.6];                         // slide (2.4 mm PETG)
pg_slot = pin_hole + 0.05;                 // cam slot width (3 mm pin)
pg_uA = 44; pg_rowY = [76, 84];            // index holes on the arm (slide coordinates), rows A and B
pg_guide = [100, 156]; pg_guideY = 27;     // the slide's two guide bolts (world X), in one long slot
function pg_guide_xy() = [for (x=pg_guide) [x, pg_guideY]];
function pg_gapA(n) = 12 + 0.5*n;          // row A hole n (0..9)
function pg_gapB(n) = 12.25 + 0.5*n;       // row B hole n (0..8)
function pg_holeX(row, n) = pg_uA + pg_p*n + (row == 1 ? pg_p/2 : 0);   // peg plate hole (world X)
function pg_ongrid(g) = abs(4*g - round(4*g)) < 1e-6 && g >= 12 && g <= 16.5;
module gapdrive() { gd_frame(0); gd_frame(1); gd_static(); pg_slide(); pg_lockpin(); }
// one comb frame (s = 0 back, 1 front): bars, guide-rod stubs, arms to its carriers (moves with the gap setting)
// v1.6 (print fix): 377 mm tall, too tall for the bed. Now 2 pieces (lower, upper), each printed flat on its face away
// from the arms (back frame: -Y face; front: +Y face), arms up. Joint: a dovetail key in the plane of the frame in a
// splice 8 mm wide (each vertical bar), 16 mm tall, between two arms; glue it (CA). The face on the bed is flat: the
// foot blocks no longer stick out 1 mm on that side, the pin block reaches it (it was 0.5 mm short). Pin holes 2.9 mm
// (press) for the 3 x 20 frame pin (in the pin block, teardrop: horizontal in the print) and the 3 x 8 guide stubs.
gd_mid = [199, 216.5];                     // dovetail seam Z [back, front] (between two arms on both bars)
gd_sw = 4;                                 // splice half width (X)
function gd_bed(s) = s==0 ? -1 : 1;        // the side that lies on the bed (-Y for the back frame, +Y for the front)
function gd_zb(s) = [zBarB, zBarF][s];
function gd_yp(s) = [pg_yb0 - d2, pg_yf0 + d2][s];
// dovetail in the XZ plane (loop_test.scad dove(): neck 3, head 4.4, 5 long), c = clearance
module gd_dove(s, x, c) let(zb=gd_zb(s)) translate([x, zb+2, gd_mid[s]]) rotate([90,0,0])
    linear_extrude(4) polygon([[-1.5-c, -0.01], [-2.2-c, 5+c], [2.2+c, 5+c], [1.5+c, -0.01]]);
module gd_body(s) let(zb=gd_zb(s), yp=gd_yp(s), sb=gd_bed(s)) difference() {
    union() {
        for (x=xB) {
            translate([x-1.5, zb-1.5, yG]) cube([3, 3, yS-yG]);
            translate([x-2.5, sb < 0 ? zb-1.5 : zb-2.5, yG-2.6]) cube([5, 4, 5.6]);               // foot block: flush on the bed side, 0.6 lower (wall under the stub hole)
            translate([x-gd_sw, zb-1.5, gd_mid[s]-8]) cube([2*gd_sw, 3, 16]);                         // splice
        }
        translate([xB[0]-1.5, zb-1.5, yS-1.5]) cube([xB[1]-xB[0]+3, 3, 3]);                      // top bar
        translate([xB[0]-1.5, zb-1.5, yG-1.5]) cube([xB[1]-xB[0]+3, 3, 3]);                      // v5b: bottom bar
        translate([pg_xp-4, sb < 0 ? yp-3.5 : yp-3, 7.4]) cube([8, 6.5, yG+1.5-7.4]);             // pin block (v1.6: 6.5 deep, flush on the bed side)
        // arms: from each carrier's outer face to its frame bar, just under the rods
        for (i=[0:n-1], x=xB) if ((i%2==0) == (s==0)) let(z=ballZat(i,x)-ballZ0+12-4, back=(i%2==0),
            yo = back ? planeY[0]+cc12/2-rod_cc(gap)-2.6 : planeY[1]-cc12/2+rod_cc(gap)+2.6) {
            if (back) translate([x-1, zBarB+1.5, z]) cube([2, yo-zBarB-1.5, 2]);
            else      translate([x-1, yo, z]) cube([2, zBarF-1.5-yo, 2]);
        }
    }
    // frame pin hole (Z), teardrop: its point is up in the print (away from the bed side)
    translate([pg_xp, yp, 7.4-1]) linear_extrude(yG+1.5-7.4+2) union() { circle(d=2.9, $fn=24); rotate(sb < 0 ? 45 : 225) square(2.9/2); }
    // guide stub holes (Y): vertical in the print
    for (x=xB) translate([x, zb-4, yG]) rotate([-90,0,0]) cylinder(d=2.9, h=8, $fn=24);
}
module gd_frame_lo(s) intersection() { gd_body(s); union() { translate([-50, -60, -1]) cube([400, 200, gd_mid[s]+1]); for (x=xB) gd_dove(s, x, 0); } }
module gd_frame_hi(s) difference() { gd_body(s); translate([-50, -60, -1]) cube([400, 200, gd_mid[s]+1]); for (x=xB) gd_dove(s, x, 0.15); }
module gd_frame(s) let(zb=gd_zb(s), yp=gd_yp(s)) {
    color("#59a5c4") { gd_frame_lo(s); gd_frame_hi(s); }
    color("silver") translate([pg_xp, yp, 2.6]) cylinder(d=3, h=20, $fn=16);                      // v5b: 3 x 20 steel pin, down into the slide's cam slot
    color("silver") for (x=xB) translate([x, zb-3, yG]) rotate([-90,0,0]) cylinder(d=3, h=8, $fn=12);
}
// the slide (moves along X by pg_s(gap)); in slide coordinates u = X at gap 12
module pg_slide(g=gap) pg_slide_s(pg_s(g));
module pg_slide_s(s) color("#d6a648") translate([s, 0, 0]) difference() {
    union() {
        translate([40, -6.6, pg_z[0]]) cube([66, 11.7, pg_z[1]-pg_z[0]]);           // back strip (back cam slot)
        translate([40, 48.9, pg_z[0]]) cube([66, 11.7, pg_z[1]-pg_z[0]]);           // front strip (front cam slot)
        for (u=[40, 98]) translate([u, -6.6, pg_z[0]]) cube([8, 67.2, pg_z[1]-pg_z[0]]);   // cross bars
        translate([40, pg_guideY-6, pg_z[0]]) cube([120, 12, pg_z[1]-pg_z[0]]);     // centre strip (guide slot)
        translate([40, 60, pg_z[0]]) cube([8, 40, pg_z[1]-pg_z[0]]);                // arm forward over the peg plate
        translate([40, 95, pg_z[0]]) cube([8, 5, 5.4]);                              // finger rib (Z up to 7.6: Elevator 1's plate gussets start at Z 8 over it)
    }
    // cam slots: the pin's path in slide coordinates (straight: d2 is linear in the travel)
    for (q=[[pg_yb0, -1], [pg_yf0, 1]]) hull() for (s=[0, 9*pg_p]) translate([pg_xp-s, q[0]+q[1]*pg_k*s, 0]) cylinder(d=pg_slot, h=20, $fn=20);
    hull() for (u=[pg_guide[0]-9*pg_p, pg_guide[1]]) translate([u, pg_guideY, 0]) cylinder(d=3.5, h=20, $fn=16);   // guide slot
    for (y=pg_rowY) translate([pg_uA, y, 0]) cylinder(d=pin_hole, h=20, $fn=20);    // index holes (rows A, B)
    for (y=[[65.5, 73.5], [86.5, 94.5]]) translate([41.5, y[0], 0]) cube([5, y[1]-y[0], 20]);   // windows: the set number shows through
}
// fixed parts: the peg plate (on the base, 2 M3 + nuts through the base), the guide bolts with spacers, washers, nuts
module gd_static() {
    color("#4a5360") difference() {
        translate([38, 64, 0]) cube([68, 32, 2]);
        for (row=[0,1], k=[0:(row==0 ? 9 : 8)]) translate([pg_holeX(row, k), pg_rowY[row], -1]) cylinder(d=pin_hole, h=4, $fn=20);
        for (x=[41, 103]) translate([x, 92.5, -1]) cylinder(d=m3_clear, h=4, $fn=16);
        // numbers (engraved 0.6 mm, paint them): row A under its holes, row B over them; read from the front
        for (k=[0:9]) translate([pg_holeX(0, k), 69.5, 1.4]) linear_extrude(1) rotate(90) text(str(pg_gapA(k)), size=2.4, halign="center", valign="center", font="Liberation Sans:style=Bold");
        for (k=[0:8]) translate([pg_holeX(1, k), 90.5, 1.4]) linear_extrude(1) rotate(90) text(str(pg_gapB(k)), size=2.4, halign="center", valign="center", font="Liberation Sans:style=Bold");
    }
    for (x=pg_guide) translate([x, pg_guideY, 0]) {
        color("#4a5360") difference() { cylinder(d=7, h=pg_z[0], $fn=24); translate([0,0,-1]) cylinder(d=m3_clear, h=5, $fn=16); }   // spacer
        color("#4a5360") difference() { cylinder(d=3.3, h=pg_z[1]+0.2, $fn=16); translate([0,0,-1]) cylinder(d=3, h=9, $fn=12); }      // sleeve through the slot
        color("silver") { translate([0,0,-6]) cylinder(d=3, h=13.6, $fn=12); translate([0,0,pg_z[1]+0.2]) cylinder(d=7, h=0.5, $fn=20);
                          translate([0,0,pg_z[1]+0.7]) cylinder(d=6.35, h=2.4, $fn=6); }                 // M3 x 14 from under the base, washer, nut
    }
}
// the lock pin (3 x 20 steel) in the hole for the current gap (shown only when the gap is a peg setting)
function pg_hole_of(g) = let(n2=round(4*(g-12))) [n2%2, floor(n2/2)];          // [row, n] of a peg setting
function pg_travel(row, k) = pg_p*k + (row == 1 ? pg_p/2 : 0);                   // slide travel that brings the index hole over it
module pg_lockpin(g=gap, d=3) if (pg_ongrid(g)) let(h=pg_hole_of(g))
    color("silver") translate([pg_holeX(h[0], h[1]), pg_rowY[h[0]], 0]) cylinder(d=d, h=20, $fn=16);
module stack_no_slide() { for (i=[0:n-1]) ramp(i); for (i=[0:n-2]) uturn(i); frame(); gd_frame(0); gd_frame(1); gd_static(); }
// ---------------- ladder channels (fix c: one per elevator) ----------------
// A cage of 4 steel rods (3 mm) the ball falls down in; one carriage locks onto an index hole with a pin and turns the
// ball out through the side that faces the stack, over a short lip into the cup's ladder slot. Channel coordinates:
// local -X faces the stack. RIGHT channel (E2): world (268, 38), feeds the right-end cups (odd ramps 2..18).
// LEFT channel (E1): world (-8.2, 16), mirrored, feeds the left-end cups (even ramps 3..19).
chHalf = 11.75;                                               // rod offset from the centre (ball 19.05 falls inside)
CH = [ [268, 38, 70, 367, [for (i=[1:2:n-2]) i], false],      // right: x, y, bottom, top, ladder positions, top ring?
       [-8.2, 16, 52, 355.4, [for (i=[2:2:n-1]) i], true] ];  // left   (right top: the E2 tray's end clips onto the rods)
chX = CH[0][0]; chY = CH[0][1]; chZ0 = CH[0][2]; chZ1 = CH[0][3];
function cupEntryZ(i) = entry(i)[2] + 4;                      // ball centre where a carriage hands over (into ramp i's cup)
module at_ch(s) translate([CH[s][0], CH[s][1], 0]) mirror([s==1 ? 1 : 0, 0, 0]) children();
// v1.6 (print fix): rod holes (3.0 mm press) in every ring; the cage prints lying on its side on the strip's outer face
// (+X), so the right cage's bottom ring gets 2 mm more on its +X bar (flush with the strip: it was 2 mm over the bed);
// the left cage's top ring is a separate flat print (it touched the strip over 1 mm only), the strip ends under it.
// In the side pose the rod holes are horizontal: teardrops, point up (-X).
module cage_ring(s, z, ext=0, flat=false) difference() {
    translate([-chHalf-4, -chHalf-4, z]) cube([2*chHalf+8+ext, 2*chHalf+8, 6]);
    translate([-chHalf+2, -chHalf+2, z-1]) cube([2*chHalf-4, 2*chHalf-4, 8]);
    translate([-chHalf-5, -9, z-1]) cube([8, 18, 8]);                       // stack side open: the carriage lip passes
    for (sx=[-1,1], sy=[-1,1]) translate([sx*chHalf, sy*chHalf, z-1])
        linear_extrude(8) union() { circle(d=3.0, $fn=24); if (!flat) rotate(135) square(1.5); }
}
module cage_strip(s, z0, z1) {
    // index strip with a hole for every ladder position, on the outer side
    // (v3) strip 2 mm further in: the v3 cup's side plate passes at Y 54.4 (right channel, world)
    // v4: the left channel's strip is on its +y side (not the outer -X side): the device is 4 mm shorter
    if (s==0) difference() { translate([chHalf+2, chHalf-3, z0]) cube([4, 7, z1-z0-5]);   // stops 5 below the top (E2's cup passes)
        for (i=CH[s][4]) translate([chHalf+1, chHalf+1, cupEntryZ(i)+1]) rotate([0,90,0]) cylinder(d=3.2, h=8, $fn=12); }
    else difference() { translate([chHalf-3, chHalf+2, z0]) cube([7, 4, z1-z0-6]);         // v1.6: ends under the top ring (was z1 - 5)
        for (i=CH[s][4]) translate([chHalf+1, chHalf+1, cupEntryZ(i)+1]) rotate([-90,0,0]) linear_extrude(8) union() { circle(d=3.2, $fn=12); rotate(135) square(1.6); }; }
}
module cage_print(s) let(z0=CH[s][2], z1=CH[s][3]) { cage_ring(s, z0, s==0 ? 2 : 0); cage_strip(s, z0, z1); }   // one printed piece
module cage_topring(s) let(z1=CH[s][3]) cage_ring(s, z1-6, 0, flat=true);                                       // left only
module cage(s) at_ch(s) let(z0=CH[s][2], z1=CH[s][3]) {
    color("silver") for (sx=[-1,1], sy=[-1,1]) translate([sx*chHalf, sy*chHalf, z0]) cylinder(d=3, h=(s==0 ? e2rodtop : z1)-z0, $fn=12);   // v5b: the right channel's rods go 3 mm higher, into the E2 funnel's sockets
    color("#4a5360") { cage_print(s); if (CH[s][5]) cage_topring(s); }
}
// v1.6 (print fix): the v1.5 carriage printed as 4 loose pieces (the stack-side opening and the index-strip notch cut
// the sleeve in two; the deflector and the lip touched nothing). Now one body, the ball's path unchanged:
//  - webs: the deflector plate goes on to both side walls (|X| < 8, clear of the rods);
//  - a fill under the deflector's high (+X) end joins it to the +X wall (the deflector's top face does not change);
//  - a 45 deg wedge under the deflector's low (-X) end joins the lip to it. The lip's inner end is cut back to the
//    same 45 deg (the ball leaves the deflector edge with its centre at X -17.8, past the lip: it never touches there).
// Print pose: on its +X wall (rotate [0, 90, 0]); see v16_stack_parts.scad.
car_a = -35;                                                     // deflector tilt
module car_plate(y0, y1, z0, z1) rotate([0, car_a, 0]) translate([-14, y0, z0]) cube([28, y1-y0, z1-z0]);
function car_pt(x, zl) = [cos(car_a)*x + sin(car_a)*zl, 2 - sin(car_a)*x + cos(car_a)*zl];   // deflector local (x, z) -> carriage (X, Z)
module carriage_body(s) {
    difference() {                                               // sleeve around the cage
        union() {
            difference() { translate([-chHalf-4, -chHalf-4, -6]) cube([2*chHalf+8, 2*chHalf+8, 14]);
                           translate([-chHalf-2, -chHalf-2, -7]) cube([2*chHalf+4, 2*chHalf+4, 16]); }
            // v1.6 fill: the deflector's +X end to the +X wall, under the deflector's top plane
            intersection() {
                translate([0, 0, 2]) rotate([0, car_a, 0]) translate([-40, -chHalf+1.6, -40]) cube([80, 2*chHalf-3.2, 41.5]);
                translate([9, -chHalf+1.6, -6]) cube([chHalf+4-9, 2*chHalf-3.2, 14]);
            }
        }
        translate([-chHalf-5, -9, -7]) cube([8, 18, 16]);
        if (s==0) translate([chHalf+1.5, chHalf-3.5, -7]) cube([5, 8, 16]);      // notch: slides along the index strip
        else      translate([chHalf-3.5, chHalf+1.5, -7]) cube([8, 5, 16]);
    }
    // deflector: a 35 deg ramp across the cage that sends the ball out of the stack side into the cup's slot
    // (v3) 4 mm thick with a flush EVA pad (20 x 16 x 2) where the ball lands: it can fall up to 29 cm (2.4 m/s, sim)
    translate([0, 0, 2]) difference() {
        union() {
            car_plate(-chHalf+1.6, chHalf-1.6, -2.5, 1.5);
            intersection() { car_plate(-chHalf-3, chHalf+3, -2.5, 1.5); translate([-8, -chHalf-3, -8]) cube([16, 2*chHalf+6, 14]); }   // v1.6 webs
        }
        rotate([0, car_a, 0]) translate([-10.2, -8.2, -0.6]) cube([20.4, 16.4, 2.2]);   // pocket 0.2 mm bigger all round than the pad
    }
    // short lip from the cage to the cup's outer wall (the cup wall is 17.6 mm from the channel centre)
    // v1.6: the lip's inner part is a wedge to the deflector's low end: its underside at 45 deg from the low edge A,
    // its top from the edge B down to the lip (behind the edge: the ball leaves B with its centre at X -17.8)
    // (A and B are 0.2 mm inside the plate's faces: no shared plane)
    let(A=car_pt(-14+0.3, -2.3), B=car_pt(-14+0.3, 1.3), zt=-ball_r, zl=-ball_r-2, E=[-14.5, zt], F=[-14.5, zl],
        C=[A[0]-(A[1]-zl), zl]) {
        rotate([90,0,0]) linear_extrude(16, center=true) polygon([A, B, E, [-17.3, zt], [-17.3, zl], C]);   // lip + wedge, one outline
    }
}
module carriage(s, i) at_ch(s) let(z=cupEntryZ(i)) {
    color("#d08a4a") translate([0, 0, z]) carriage_body(s);
    color("silver") if (s==0) translate([chHalf+1.8, chHalf+1, z+1]) rotate([0,90,0]) cylinder(d=3, h=8.2, $fn=12);     // index pin (in the sleeve's height)
    else translate([chHalf+1, chHalf+1.8, z+1]) rotate([-90,0,0]) cylinder(d=3, h=8.2, $fn=12);
    color("#2b2b2b") translate([0, 0, z+2]) rotate([0, -35, 0]) translate([-10, -8, -0.5]) cube([20, 16, 2]);
}

// ---------------- elevator tops: fixed catch ledges and trays (v5b) ----------------
// v4/v5 had a hinged catch flap under each cup's top position: the rising cup lifted it, and at the top it rested ON the
// cup (the simulator found it, OpenSCAD confirmed it). v5b: nothing moves at the hand-over. A fence on the cup floor
// turns the ball off the floor's pour-side edge; it drops about 5 mm onto a FIXED ledge that starts 1 mm outside the cup
// side plate. No part of either elevator is ever on that side of the plate, so the cup passes the ledge at every angle.
//  - E1 (pours to +Y): a V-shaped ledge (Y 116.6..129, X 256..284) into the front tray's mouth at (270, 128.5).
//  - E2 (pours to -Y): a FUNNEL (a 10.9 deg cone round the right channel's centre, X 252..298, Y 24..53.4) with the drop
//    hole into the right channel at (268, 38). It sits on the channel's 4 rods.
E1top = [245.8, 103, 0] + E1_topseat();  E2top = [262, 67, 0] + E2_topseat();   // ball on the seat of the tipped cup at the top
E1end = [245.8, 103, 0] + E1_topend();   E2end = [262, 67, 0] + E2_topend();     // ... and at the open end of its floor (v4 pour; kept for reference)
E1O = [245.8, 103, 0]; E2O = [262, 67, 0];
E1pour = [for (q=E1_pour()) E1O + q];                                    // seat -> fence -> over the edge -> ledge -> tray mouth
E1tr = [for (q=E1_rtray()) E1O + q];
E1land = E1pour[len(E1pour)-3];                                         // where the ball lands on the ledge
// tray axis points (ball centre = axis - 0.8 when it rolls on the trough floor)
E1tray = [E1tr[0], [E1tr[0][0], 135, E1tr[0][2]-0.4], [230, 135, 379.4],   // v5b: mouth at X 270 (was 277), 1.4 mm higher
          [100, 135, 375.6], [-8.2, 135, 372.1],
          [-8.2, 100, 370.6], [-8.2, 50, 368.6], [-8.2, 16, 366.7]];
// the ledge is printed with the tray; it is cut back where the tray's first two runs pass (its -X half would rise into
// the leftward run's ball path)
module e1_ledge() difference() { translate(E1O) E1_ledge();
    for (k=[0:1]) hull() { translate(E1tray[k]-[0,0,0.8]) sphere(r=ball_r+0.5, $fn=32); translate(E1tray[k+1]-[0,0,0.8]) sphere(r=ball_r+0.5, $fn=32); } }
// E2 funnel: cone round H (the right channel's centre), ball centre 379.2 at H (as the v5 tray end), slope set so the
// funnel is 5 mm under the floor's pour edge where the ball lands
e2H = [268, 38]; e2Hz = 379.2 - ball_r - 0.15;                            // funnel top at the cone's tip (the hole's centre)
e2L0 = [E2O[0]+E2_edge()[0]+7.5, E2O[1]+E2_edge()[1]-8.6];               // landing estimate (the E1 rig: 7.5 on, 8.6 out)
e2tb = (E2_edge()[2] - 5 - e2Hz)/norm(e2L0-e2H);                         // tan of the cone slope
function e2fz(x, y) = e2Hz + e2tb*norm([x-e2H[0], y-e2H[1]]);           // funnel top z, world
e2f_rig = function(x, y) e2fz(x+E2O[0], y+E2O[1]);
e2sock = 365.5; e2rodtop = 370;                                         // sockets start over the top carriage (its sleeve reaches 365.1); the right channel's rods go up to 370 (were 367)
e2fx = [252, 298]; e2fy = [24, 67-ledge_v0_w()]; e2hole = 10.6;
function ledge_v0_w() = 13.6;                                            // = ledge_v0 in elevator1_test.scad (variables do not cross "use")
E2land = E2O + E2_land(e2f_rig);
E2pour = [for (q=E2_pour(e2f_rig, [])) E2O + q];                         // seat -> fence -> over the edge -> lands on the funnel
E2tray = [for (q=[[E2land[0], E2land[1]], (([E2land[0], E2land[1]]+e2H)/2), e2H]) [q[0], q[1], e2fz(q[0], q[1]) + ball_r + 0.15 + 0.8]];   // straight down the cone to the hole
module e2_funnel() color("#d08a4a") {
    difference() {
        union() {
            intersection() {
                translate([e2H[0], e2H[1], 0]) rotate_extrude($fn=120) polygon([[0, e2Hz-2], [70, e2Hz-2+70*e2tb], [70, e2Hz+70*e2tb], [0, e2Hz]]);
                translate([e2fx[0], e2fy[0], 300]) cube([e2fx[1]-e2fx[0], e2fy[1]-e2fy[0], 200]);
            }
            // rims (6 mm over the funnel) on the outer edges: +X (size box edge) and -Y
            // (v1.6: the rims start 0.1 mm above the funnel's underside: v1.5 shared that edge and left 4 zero-area slivers)
            hull() for (y=e2fy) translate([e2fx[1]-1.6, y-(y==e2fy[1] ? 0.01 : 0), e2fz(e2fx[1], y)-1.9]) cube([1.6, 0.01, 7.9]);
            hull() for (x=e2fx) translate([x-(x==e2fx[1] ? 0.01 : 0), e2fy[0], e2fz(x, e2fy[0])-1.9]) cube([0.01, 1.6, 7.9]);
            // sockets on the 4 rods of the right channel (the rods end at Z 367; 3 mm into the socket)
            for (sx=[-1,1], sy=[-1,1]) let(q=[e2H[0]+sx*chHalf, e2H[1]+sy*chHalf]) translate([q[0], q[1], e2sock]) cylinder(d=7, h=e2fz(q[0], q[1])-e2sock-1, $fn=24);
        }
        translate([e2H[0], e2H[1], 300]) cylinder(r=e2hole, h=200, $fn=48);                   // drop hole
        for (sx=[-1,1], sy=[-1,1]) translate([e2H[0]+sx*chHalf, e2H[1]+sy*chHalf, e2sock-0.1]) cylinder(d=rod_hole, h=e2rodtop-e2sock+0.1, $fn=16);
    }
}
function down(p) = [for (q=p) q-[0,0,0.8]];
module tray(s) color("#d08a4a") if (s==1) { tray_e1_a(); tray_e1_b(); }
                                 else e2_funnel();
// v1.6 (print fix): the E1 tray (305 x 146 mm) does not fit the bed. Two pieces, split across the front run at X 100
// (the slope break; the front run alone is 296 mm long, so a split at the elbow would still not fit):
//  A = mouth, ledge, label and the front run to X 100; B = the front run from X 100, the elbow and the -Y run.
// Both print channel-up (no support in the ball channel). A flat keel (45 deg flanks, no lower than the trough's
// bottom) fills the belly under the round trough, so it sits on the bed. Joint: the trough butts at X 100; an ear
// on each side (X 88..112, out to 18 mm from the axis, bottom to lip height) is cut by a 45 deg scarf plane (A below,
// B above: both faces print without support) and pinned with one 3 x 10 mm steel pin per ear (2.9 mm holes,
// vertical). Glue the scarf (CA).
tr_x = 100; tr_ear = [88, 112]; tr_ey = [5, 18];
function tr_axz(x) = x >= tr_x ? 375.6 + (x-tr_x)*(379.4-375.6)/130 : 375.6 + (x-tr_x)*(375.6-372.1)/108.2;   // axis Z on the front run (Y 135)
tr_zc = tr_axz(tr_x) - 12.725/2 - 1;                                     // scarf plane height at X 100 (middle of the ear)
// keel: a flat bottom 10.5 mm wide with 45 deg flanks to the trough's outer surface; its top stays inside the wall
// (the flank's top points are 0.4 mm inside the outer surface: no shared vertex with the round trough's facets)
// pl = the print plane (world z of the bed under the piece, a function of x, y): the keel bottom goes down to it
// (piece B: at most 0.36 mm below the v1.5 trough bottom); undef = the keel bottom is 12.725 mm under the axis.
module tray_kslice(q, a, pl, ro, p) let(zb=function(u) is_undef(pl) ? -ro : pl(q[0]-u*sin(a), q[1]+u*cos(a)) - q[2], zl=zb(-(2*p-ro)), zr=zb(2*p-ro))   // (at the bottom corners)
    translate(q) rotate([0,0,a]) rotate([90,0,90]) linear_extrude(0.01, center=true)
        polygon([[-(2*p+zl), zl], [2*p+zr, zr], [p, -p], [0, -ro+1.2], [-p, -p]]);
function tray_hd(pts, k) = let(d=pts[k+1]-pts[k]) atan2(d[1], d[0]);
module tray_keel(pts, pl=undef, rin=ball_r+0.8, wall=2.4) let(ro=rin+wall, p=(ro-0.4)*sin(45)) {
    for (k=[0:len(pts)-2]) hull() { tray_kslice(pts[k], tray_hd(pts, k), pl, ro, p); tray_kslice(pts[k+1], tray_hd(pts, k), pl, ro, p); }
    for (k=[1:len(pts)-2]) hull() { tray_kslice(pts[k], tray_hd(pts, k-1), pl, ro, p); tray_kslice(pts[k], tray_hd(pts, k), pl, ro, p); }   // corners: under the round turn
}
tr_bB = [(375.6-372.1)/108.2, (372.1-366.7)/119];        // piece B's print plane: slopes along X and Y
function tr_plB(x, y) = 375.6 - 12.725 + tr_bB[0]*(x-tr_x) + tr_bB[1]*(y-135);
module tray_e1_full() {
    trough_chain(E1tray, open_start=true, drop_end=true, pads=[1, 4]);
    difference() { union() { tray_keel([for (k=[0:3]) E1tray[k]]); tray_keel([for (k=[3:len(E1tray)-1]) E1tray[k]], function(x, y) tr_plB(x, y)); }
                   let(m=len(E1tray)-1) translate(E1tray[m]-[0,0,40]) cylinder(r=ball_r+0.8+0.3, h=80, $fn=24);
                   tray_e1_chan(0.3, [0:len(E1tray)-2]); }      // the hull of the keel outline fills its notch: keep it 0.3 mm under the channel
    e1_ledge(); e1_label();
}
module tray_e1_chan(g=0.3, ks=[2:3]) for (k=ks) hull() { translate(E1tray[k]) sphere(r=ball_r+0.8+g, $fn=20); translate(E1tray[k+1]) sphere(r=ball_r+0.8+g, $fn=20); }
module tray_e1_outer() { for (k=[2:3]) hull() { translate(E1tray[k]) sphere(r=ball_r+0.8+2.4, $fn=20); translate(E1tray[k+1]) sphere(r=ball_r+0.8+2.4, $fn=20); }
                         tray_keel([E1tray[2], E1tray[3]]); tray_keel([E1tray[3], E1tray[4]], function(x, y) tr_plB(x, y)); }
// ears: A's part (under the scarf) has its bottom on A's print plane (the axis - 12.725 line), B's part (over the
// scarf) on B's print plane (tilted in Y by the -Y run's slope): each piece sits flat on the bed
module tray_e1_ears(side) difference() {
    for (sg=[-1,1]) let(ys=sg > 0 ? [135+tr_ey[0], 135+tr_ey[1]] : [135-tr_ey[1], 135-tr_ey[0]]) {
        if (side == "A") for (xs=[[tr_x-6, tr_x], [tr_x, tr_ear[1]]]) hull() for (x=xs) translate([x-0.005, ys[0], tr_axz(x)-12.725]) cube([0.01, ys[1]-ys[0], 12.725-2]);
        if (side == "B") hull() for (x=[tr_ear[0], tr_x+6], y=ys) translate([x-0.005, y-0.005, tr_plB(x, y)]) cube([0.01, 0.01, tr_axz(x)-2-tr_plB(x, y)]);
    }
    tray_e1_chan();
    for (sg=[-1,1]) translate([tr_x, 135+sg*15, 300]) cylinder(d=2.9, h=100, $fn=24);   // pin holes
    // on the other piece's side of X 100 an ear keeps only its outer part (|dy| >= 12.8, outside that piece's trough):
    // no cavity in the ear, so no overhang over the other piece's trough when it prints alone
    translate([side == "A" ? tr_x-50 : tr_x, 135-12.8, 300]) cube([50, 25.6, 200]);
}
module tr_below() translate([tr_x, 135, tr_zc]) rotate([0,-45,0]) translate([-100,-100,-200]) cube([200, 200, 200]);   // under the scarf plane
module tray_e1_a() {   // mouth side (X >= 100)
    intersection() { tray_e1_full(); translate([tr_x+0.006, -100, 0]) cube([400, 400, 600]); }   // (6 um off the keel slices at X 100)
    intersection() { tray_e1_ears("A"); tr_below(); }
}
// B's drop end: the end cap's ring round the drop hole had a flat (horizontal) bottom edge 7 mm over the bed; cut
// under a 45 deg plane that rises away from the end point, so it prints as a 45 deg overhang (the ball falls through
// the hole: it never touches the cut part)
module tray_e1_endcut() let(e=E1tray[len(E1tray)-1]) translate([e[0]-60, e[1], e[2]-12.725]) rotate([-45,0,0]) translate([0, -100, -100]) cube([120, 200, 100]);
module tray_e1_b() {   // elbow side (X < 100)
    difference() { intersection() { tray_e1_full(); translate([tr_x-400-0.006, -100, 0]) cube([400, 400, 600]); }
                   for (sg=[-1,1]) translate([tr_x, 135+sg*15, 300]) cylinder(d=2.9, h=100, $fn=24); tray_e1_endcut(); }
    difference() { tray_e1_ears("B"); tr_below(); }
}
// v5 (rule 3.j): "ELEVATOR 1 TYPE 1" in 6 mm raised text on a strip on the front of Elevator 1's top tray (the track
// at the top of the elevator), below the tray's rim, seen from the front.
function e1tz(x) = 379.4 + (x-230)*(375.6-379.4)/(100-230);   // tray axis height along its front run (Y 135)
module e1_label() {
    hull() for (x=[120, 222]) translate([x, 147.2, e1tz(x)-12.725]) cube([0.01, 1.6, 9.925]);   // v1.6: bottom flush with the keel (was 0.33 mm higher)
    color("#f4f1ea") translate([171, 148.79, e1tz(171)-7.6]) rotate([90,0,180]) linear_extrude(0.81)
        rotate(-atan((375.6-379.4)/(100-230))) text("ELEVATOR 1  TYPE 1", size=6.2, halign="center", valign="center", font="Liberation Sans:style=Bold");
}
module tops() { tray(1); tray(0); }

// ---------------- gate, feeds, finish ----------------
// Gate box at ramp 19's end. First pass: the flap is shut and the floor slopes to the +Y door, the ball rolls out to
// the E2 feed. Second pass: the cord from E2's lever has pulled the flap open, the ball drops to the finish track.
// trough_chain: printed half-pipe along points; open top slot (ball always visible). mouth: open from above at the
// start (ball drops in); drop_end: hole down at the end (ball drops out); open_start/open_end: no end cap;
// pads: indexes of corner points that get an EVA pad pocket in the outer wall.
// EVA pads in the trough corners (same place as the pockets in trough_chain: inner face flush with the trough wall)
module trough_pads(pts, pads, rin=ball_r+0.8) color("#2b2b2b")
    for (k=pads) let(d=pts[k]-pts[k-1], u=d/norm([d[0],d[1]])) translate(pts[k]+[u[0],u[1],0]*(rin+1)) rotate([0,0,atan2(u[1],u[0])]) rotate([0,90,0]) cylinder(d=pad_dot, h=2, center=true, $fn=24);
module pads() { for (i=[0:n-2]) uturn_pad(i); trough_pads(E1tray, [1, 4]); trough_pads(E1feed, [1, 4]); trough_pads(E2feed, [4]); }   // (the finish end cap holds the felt stop, in feeds())
pad_dot = 10.0;   // v5: EVA dot size (rail_test.scad has it too, but "use" does not import variables: v4 drew no trough pads)
// halfspace() and trough_chain() are in common.scad (v3: the test rigs use them too)
gx0 = 230; gx1 = 258; gy0 = 1; gy1 = 31; gfl = 40;            // gate box outside / floor top (v5: -Y wall 2 mm out: ramp 19's ball at gap 16.5 rubbed the -X door edge by 1.1 mm)
E2feed = [[244, 17, 49.9], [244, 26, 49.6], [243, 36, 48.5], [240, 50, 45.6], [239, 67, 39.6], [250, 67, 37.3]];   // v3: foam corner at [4] (sim: 0.38 m/s into the cup); v5: [3] 3 mm left (the diagonal clipped E2's resting cup corner by 1.7 mm)
// v5 (rule 3.c): the v4 finish track ran under the stack (X 68..244, Y 26), hidden from every side. Now it leaves
// the gate drop forward, swings right under the E2 feed and runs to the front along the right edge (X 287): nothing is
// in front of it or right of it at the end of a run (both elevators are up). Its walls end below the ball centre.
// It passes 0.6 mm under Elevator 2's resting cup (X 250..282, bottom Z 16.4): the ball only runs here after E2 lifted.
finish_pts = [[244, 17, 21], [244, 30, 20.4], [250, 40, 19.6], [266, 45, 17.8], [282, 50, 16.8], [287, 60, 16.2], [287, 100, 15.0], [287, 141, 13.6]];
finish_y = 118;                                              // v5 finish line (rule 3.f): across the track at Y 118
module gate(flap=true) {
    color("#4a5360") difference() {
        translate([gx0, gy0, gfl-6]) cube([gx1-gx0, gy1-gy0, 24]);
        translate([gx0+2, gy0+2, gfl]) cube([gx1-gx0-4, gy1-gy0-4, 30]);                 // inside 24 x 24
        translate([232, 6, gfl-7]) cube([23, 22, 8]);                                     // drop hole to the finish (v5: 1 mm more at the hinge side, the flap swings there)
        translate([gate_hinge[0], gy0-1, gate_hinge[2]]) rotate([-90,0,0]) cylinder(d=2.3, h=gy1-gy0+2, $fn=12);   // v5: hinge pin holes
        translate([gx0-1, gy0+2, gfl+2]) cube([4, gy1-gy0-4, 30]);                       // -X door: ramp 19 comes in (all gaps)
        translate([232.5, gy1-3, gfl-0.01]) cube([23, 4, 30]);                            // +Y door: out to the E2 feed (floor level)
        translate([gx1-2.5, gy0-1, gfl+12]) cube([4, gy1-gy0+2, 30]);                     // v5: +X wall ends 2 mm over the ball centre (seen from the right)
        translate([gx1-3.5, 9, gfl-7]) cube([5, 16, 13]);                                  // v5: window under the bar (Z 33..46): the drop shows from the right;
                                                                                            // the bar (Z 46..52) still stops the first-pass ball at its centre (Z 49.8)
    }
    if (flap) gate_flap(0);
}
// v5: the gate flap's hinge, for the checks and the simulator: a 2 mm pin along Y through the flap's -X edge (in the
// floor, X 233.95, Z 39.25). The cord from E2's lever pulls its +X edge (crank at X 254) down; open = 90 deg, hanging
// at X 233.2..234.7, clear of the falling ball (X >= 235.5). gate_flap_info() = [hinge point, axis, open angle].
gate_hinge = [233.2+0.75, 17, gfl-0.75]; gate_open = 90;
function gate_flap_info() = [gate_hinge, [0, 1, 0], gate_open];
// v5b: the flap's swing (0..90 deg, every 2.5 deg, grown by g mm), cut out of the finish trough's start: the swinging
// +X edge clipped the trough's start cap by 0.39 mm over the last 5 deg (simulator)
module gate_flap_plate(t, g=0) translate(gate_hinge) rotate([0, t, 0]) translate(-gate_hinge) translate([233.2-g, 6.2-g, gfl-1.5-g]) cube([21.6+2*g, 21.6+2*g, 1.5+2*g]);
module gate_flap_swing(g=0.6) for (t=[0:2.5:87.5]) hull() { gate_flap_plate(t, g); gate_flap_plate(t+2.5, g); }
module gate_flap(t=0) color("#e0a040") translate(gate_hinge) rotate([0, t, 0]) translate(-gate_hinge) {
    translate([233.2, 6.2, gfl-1.5]) cube([21.6, 21.6, 1.5]);                              // flap, shut (first pass), flush
    color("silver") translate([gate_hinge[0], 4.2, gate_hinge[2]]) rotate([-90,0,0]) cylinder(d=2, h=25.6, $fn=10);   // hinge pin
}
module feeds() {
    color("#d08a4a") difference() { trough_chain([for (k=[2:len(E2feed)-1]) E2feed[k]], open_start=true, open_end=true, pads=[2]); trip_slot(E2O); }   // pad at E2feed[4]
    color("#d08a4a") finish_track_body();
    finish_line();
    color("#2e343d") let(e=finish_pts[len(finish_pts)-1]) translate([e[0], e[1]+ball_r+0.8+1.0, e[2]]) rotate([90,0,0]) cylinder(d=10, h=2, center=true, $fn=24);   // felt stop (rule 3.h) in the end cap
    color("#d08a4a") for (y=[70, 125]) let(z=finish_pts[6][2]+(y-100)*(13.6-15.0)/41) translate([287-8, y-3, 0]) cube([16, 6, z-ball_r-0.8-1.6+0.3]);   // two feet under the track
}
// v5 finish line (rule 3.f): a 2 mm bar across the track at Y 118 on two posts (top Z 30, clear over the ball), a red
// groove across both track rims under it, and a sign on the left: "FINISH" in 6 mm raised text with an arrow, facing
// the front. The ball is timed until it has fully crossed (centre at Y 127.5); it stops 23 mm later on the felt.
// v1.6 (print fix): the felt pocket in the end cap (trough_chain's pad pocket, 2.1 deep) went through the faceted end
// cap: a 0.045 mm3 loose crumb was all that was left behind the felt. A 14 mm disc, 1.2 mm behind the pocket, closes it.
fin_e = finish_pts[len(finish_pts)-1];
fin_pk = fin_e + [0, ball_r+0.8+1, 0];                                     // pad pocket centre (as trough_chain)
module fin_pocket() translate(fin_pk) rotate([90,0,0]) cylinder(d=10.4, h=2.1, center=true, $fn=24);
module finish_track_body() difference() {
    union() { trough_chain(finish_pts, mouth=true, pads=[len(finish_pts)-1]);
              translate(fin_pk + [0, -0.825, 0]) rotate([-90,0,0]) cylinder(d=14, h=3.125, $fn=32); }   // Y 151.5..154.6: 1.25 mm behind the pocket
    fin_pocket(); finish_groove();
    translate([229, 4, 16.5]) cube([6.8, 26, 20]); gate_flap_swing();      // the open gate flap hangs here (X 233.2..234.7); v5b: and its whole swing
}
module finish_line() color("#d6a648") let(zt=15.0+(finish_y-100)*(13.6-15.0)/41) {
    for (x=[272.6, 298.4]) translate([x, finish_y-1, 0]) cube([1.6, 2, 32]);
    translate([272.6, finish_y-1, 30]) cube([27.4, 2, 2]);
    translate([242.6, finish_y-1, 0]) cube([30, 2, 17]);
    color("#f4f1ea") translate([257.6, finish_y+0.99, 10.5]) rotate([90,0,180]) linear_extrude(0.81) text("FINISH", size=6.2, halign="center", valign="center", font="Liberation Sans:style=Bold");
    color("#f4f1ea") translate([257.6, finish_y+0.99, 3.6]) rotate([90,0,180]) linear_extrude(0.81) text("< LINE", size=4, halign="center", valign="center", font="Liberation Sans:style=Bold");
}
module finish_groove() let(zt=15.0+(finish_y-100)*(13.6-15.0)/41) translate([270, finish_y-0.6, zt-3.5]) cube([34, 1.2, 4]);
// cord: E2 lever (30 mm from its pivot) -> pulley at the base -> along the base -> up to the gate flap's crank
module gate_cord() color("white") let(f=[128.1, 67, 232.3], p=f+30*[cos(-53.1), 0, sin(-53.1)],
        q=[[p[0], 63, p[2]], [p[0], 63, 4], [259, 63, 4], [259, 20, 4], [259, 20, 38], [254, 17, 38.5]])
    for (k=[0:len(q)-2]) hull() { translate(q[k]) sphere(0.5); translate(q[k+1]) sphere(0.5); }
// loop: POI at X 160, Z 43.6; loop frame (x, y, w) -> world (160 + x, 119 + w, 43.6 + y)
POIx = 145; POIz = 43.6; loopY0 = 119;         // 15 mm left of the sim spot: room for the E1 feed corner
module at_loop() translate([POIx, loopY0, POIz]) mirror([0,1,0]) rotate([90,0,0]) children();
// E1 feed: loop exit (lane B, Y 150.5, X 205) -> felt corner at X 215 (pad on its +X wall; the ball clears the lane's
// end) -> back (-Y), jogging left to X 206.5 so it passes left of E1's latch crank (X >= 219.6, Y 116..120) -> round
// into the cup from -X, 4.5 mm above the seat
E1feed = [[205, 149, 53.8], [215, 149, 53.3], [215, 134.5, 51.4], [206.5, 126, 49.6], [206.5, 102.6, 39.4], [233.8, 102.6, 37.3]];   // v5: starts at Y 149 (lane B moved 1.5 mm in)   // v3: foam corner at [4], 2.1 mm drop after it
// (v3) slot in the end of each feed for the latch trip pin (2 mm inside the end, 0.7 mm up into the ball path)
module trip_slot(o) translate(o + [-14-2.5, -7, 23]) cube([5, 14, 6]);
module e1feed() color("#d08a4a") difference() { trough_chain(E1feed, open_start=true, open_end=true, pads=[1, 4]); trip_slot(E1O); }   // v3: 2nd foam corner just before the cup (sim: the ball came in at 0.42 m/s, the cup holds 0.25)
// ---------------- v5 wood (Kai, 2026-10-28: the v4 woods stay) ----------------
// base and back panel: 6 mm birch plywood (saw + drill: drawing cad/laser/wood_6mm_drawing.svg; the Falcon 5W
// cannot cut 6 mm birch, it can engrave it: cad/laser/base_engrave_6mm.svg).
wood_c = "#c8a979";
// ---------------- v5b loop brackets (Kai, 2026-10-28: no loop board, no laser cutting) ----------------
// The loop's 8 screw tabs (12 x 9.2 x 4 mm, world Y 119..123, outside the track walls) bolt with M3 to Elevator 1's
// pin plate (a printed truss on the base, front face Y 116, 3 mm behind the tabs):
//  - R3, R4, LT, AT: through a 3 mm printed spacer and the plate (M3 x 16, nut in a pocket in the plate's back face);
//  - R2 (ring top) and R1 (right of the plate): through the RIGHT bracket, a 3 mm plate between the loop and the E1
//    plate, bolted to the plate at R2 and at (146, 163). R1's bolt has its nut behind the bracket (M3 x 10);
//  - the chute's CT1 (left of the plate): through the LEFT bracket, bolted to the plate's left bar at (48, 122) and
//    (48, 138). It stays at X >= 24.5, clear of Elevator 1's counterweight pot (X <= 23.5). CT2 (chute top) has no
//    bracket, as in v4/v5 (the pot passes behind it); the chute is held by CT1 and its peg in the ring.
// Everything sits between Y 116 and 119 (behind the track) or on the tabs' outer side: out of the ball's path and of
// the sight lines from the front. The loop's geometry, POI and labels are unchanged.
LB_Y = [116, loopY0];
function loop_tabs() = [for (q=CL_tab_holes()) [POIx+q[0], POIz+q[1]]];   // 0 R1, 1 R2, 2 R3, 3 R4, 4 LT, 5 AT, 6 CT1, 7 CT2
module lb_disc(p, r, y0=LB_Y[0], y1=LB_Y[1]) translate([p[0], y1, p[1]]) rotate([90,0,0]) cylinder(r=r, h=y1-y0, $fn=32);
module lb_hole(p) translate([p[0], 100, p[1]]) rotate([-90,0,0]) cylinder(d=m3_clear, h=40, $fn=16);
// bracket-to-plate bolts: countersunk M3 x 12 (DIN 7991), head flush with the bracket's front face (the loop's back
// face is right in front of it), nut in the plate's back face
module lb_csk(p) translate([p[0], LB_Y[1]-1.7, p[1]]) rotate([-90,0,0]) cylinder(d1=3.4, d2=6.4, h=1.71, $fn=24);
module loop_spacer(p) difference() { lb_disc(p, 4.5); lb_hole(p); }
module loop_bracket_R() let(T=loop_tabs()) difference() {
    hull() { lb_disc(T[0], 6); lb_disc(T[1], 6); lb_disc([146, 163], 4.5); }
    for (p=[T[0], T[1], [146, 163]]) lb_hole(p);
    lb_csk([146, 163]);
}
module loop_bracket_L() let(T=loop_tabs(), c=T[6]) difference() {
    hull() { translate([24.5, LB_Y[0], c[1]-6]) cube([10.5, 3, 12]); lb_disc([48, 122], 4.5); lb_disc([48, 138], 4.5); }
    for (p=[c, [48, 122], [48, 138]]) lb_hole(p);
    for (p=[[48, 122], [48, 138]]) lb_csk(p);
}
// bolts (heads on the tabs' front faces, Y 123..126, outside the track walls) and the nuts behind the brackets at R1 and CT1
module loop_bolts() let(T=loop_tabs()) color("silver") {
    for (p=[T[1], T[2], T[3], T[4], T[5]]) translate([p[0], 107, p[1]]) rotate([-90,0,0]) { cylinder(d=3, h=16, $fn=12); translate([0,0,16]) cylinder(d=5.5, h=3, $fn=16); }
    for (p=[T[0], T[6]]) translate([p[0], 113.6, p[1]]) rotate([-90,0,0]) { cylinder(d=3, h=9.4, $fn=12); translate([0,0,9.4]) cylinder(d=5.5, h=3, $fn=16); cylinder(d=6.35, h=2.4, $fn=6); }
    for (p=[[146, 163], [48, 122], [48, 138]]) translate([p[0], 107, p[1]]) rotate([-90,0,0]) { cylinder(d=3, h=12, $fn=12); translate([0,0,12-1.65]) cylinder(d1=3, d2=6, h=1.65, $fn=16); }   // countersunk, flush
}
module loop_brackets() let(T=loop_tabs()) {
    color("#4a5360") { for (p=[T[2], T[3], T[4], T[5]]) loop_spacer(p); loop_bracket_R(); loop_bracket_L(); }
    loop_bolts();
}
module loop_board() loop_brackets();   // v5b: old name kept for scripts; there is no board
// back panel: 6 mm birch, world Y -15..-9 as v4, now a truss (frame + one diagonal per bay): saw the windows.
bp_z1 = 402.65; bp_m = 14;
bp_cols = [-26, 34, 222.8, 300]; bp_rows = [0, 134, 268, bp_z1];
module back_panel_2d() difference() {
    translate([Lx0, 0]) square([L-Lx0, bp_z1]);
    for (w=bp_windows()) polygon(w);
    for (x=[34, 222.8, 296], z=[60, 200, 340]) translate([x, z]) circle(d=3.4, $fn=16);   // M3 into the posts (34, 222.8) and the E2 post (296)
}
// windows as plain triangles (straight saw cuts): each bay minus its frame and its diagonal
function bp_windows() = [for (i=[0:2], j=[0:2]) let(x0=bp_cols[i], x1=bp_cols[i+1], z0=bp_rows[j], z1=bp_rows[j+1],
        a=x0+(i==0?bp_m:bp_m/2), b=x1-(i==2?bp_m:bp_m/2), c=z0+(j==0?bp_m:bp_m/2), d=z1-(j==2?bp_m:bp_m/2),
        up=(i+j)%2==0, k=bp_m/2*norm([b-a, d-c])/(b-a), kz=bp_m/2*norm([b-a, d-c])/(d-c))
    each (up ? [[[a, c+k], [a, d], [b-kz, d]], [[a+kz, c], [b, c], [b, d-k]]]
             : [[[a, c], [b-kz, c], [a, d-k]], [[b, c+k], [b, d], [a+kz, d]]])];
module back_panel() color(wood_c) translate([0, Wy0+6, 0]) rotate([90,0,0]) linear_extrude(6) back_panel_2d();
// base: 6 mm birch, one sheet. v5: 3 levelling wheels (rule 4.e) in counterbores from below, and a level spot.
LEV = [[-14, 0], [286, 0], [100, 151]];                  // 3 points, no rocking; centre of mass about (99, 71), 47..71 mm inside
LEVEL_SPOT = [240, 145];
module base_outline() translate([Lx0, Wy0]) square([L-Lx0, Wy1-Wy0]);
module base_engrave() { translate(LEVEL_SPOT) difference() { circle(d=18, $fn=48); circle(d=16.6, $fn=48); }
    translate(LEVEL_SPOT+[0,-14.5]) text("LEVEL", size=4, halign="center", font="Liberation Sans:style=Bold");
    for (q=LEV) translate(q+[0,7]) text("ADJ", size=3, halign="center", font="Liberation Sans"); }
module base_plate() color(wood_c) difference() {
    translate([0,0,-6]) linear_extrude(6) base_outline();
    for (q=concat(pg_guide_xy(), [[41, 92.5], [103, 92.5]])) translate([q[0], q[1], -7]) cylinder(d=m3_clear, h=8, $fn=16);   // v5b: peg plate + slide guide bolts (M3 + nuts)
    for (q=LEV) translate([q[0], q[1], 0]) {
        translate([0,0,-6.01]) cylinder(d=20, h=3.01, $fn=48);       // counterbore from below, 3 deep: the wheel can go up flush
        translate([0,0,-4]) cylinder(d=4.5, h=5, $fn=16);              // M4 clearance
        translate([0,0,-3.3]) cylinder(d=8.1, h=3.4, $fn=6);           // M4 nut, epoxied in a 3.3 mm hex pocket from the top
    }
}
// levelling wheel: printed knurled disc d 18 x 3 with an M4 x 12 screw pressed in, threaded into the glued nut.
// Set: wheel 3 mm under the base (tip Z -9, as the v4 feet); range 0 (in the recess) to 6 mm: +-3 mm.
lev_set = 3;
module lev_wheels() for (q=LEV) translate([q[0], q[1], -6]) {
    // v1.6: 3.5 mm hole for the M4 screw (it cuts its own thread in the wheel; add a drop of CA so the wheel turns the screw)
    color("#4a5360") translate([0,0,-lev_set]) difference() { cylinder(d=18, h=3, $fn=24); for (a=[0:30:330]) rotate(a) translate([9.3,0,-1]) cylinder(d=1.6, h=5, $fn=8);
        translate([0,0,-1]) cylinder(d=3.5, h=5, $fn=24); }
    color("silver") translate([0,0,-lev_set+3]) cylinder(d=4, h=12, $fn=12);
    color("silver") translate([0,0,2.71]) cylinder(d=8.08, h=3.2, $fn=6);
}

// ---------------- top frame: Elevator 2's top pulley, the rope anchor and the two tip cams ----------------
// (v3, 2026-10-28) v2's post stood in the gap between the cup sweeps, but the v3 cups carry their real latch tail
// (E2's reaches Y 84) and horn pins (E1's reaches Y 86), so nothing can stand in that gap below the tops. A post at
// the back right (in front of the back panel) carries a beam forward at the top; from it hang the top pulley's cheek,
// the rope anchor and the tip-cam block. The cams sit where only the horn pins pass.
E2P1 = [262, 67, 0] + E2_info()[1];  E2ANC = [262, 67, 0] + E2_info()[2];   // from coaster_e2.scad (P1v, anchor), world
bkX = [292, 300]; bkY = [82, 88]; bkZ = E2P1[2] + 6;   // v4: the beam follows the top pulley
function e1sw() = E1_info()[7];  function e2sw() = E2_info()[3];
// cam bands (world Y): E1's pin is exposed at Y 86..90.4, E2's at 79.6..84; a 3 mm rib between them
camY1 = [86.6, 89.7]; camY2 = [80.3, 83.4]; ribY = [83.4, 86.6];
function campts(o, f, sw, span) = [for (a=[sw-span-1.0 : 0.25 : sw]) let(lead = a < sw-span ? (sw-span-a)*2.0 : 0) o + f(a) + [0,0,1.8+lead]];   // cam face points (pin top + 0.3, + lead-in)
module cam_band(pts, y) for (k=[0:len(pts)-2]) hull() for (q=[pts[k], pts[k+1]]) translate([q[0]-0.25, y[0], q[2]-1.3]) cube([0.5, y[1]-y[0], 6.3]);
module pin_clear(pts, y) for (k=[0:len(pts)-2]) hull() for (q=[pts[k], pts[k+1]]) translate([q[0], y[0]-1, q[2]]) rotate([-90,0,0]) cylinder(r=1.9, h=y[1]-y[0]+2, $fn=20);
function pinpts(o, f, sw, span) = [for (a=[sw-span-1.5 : 0.1 : sw+0.2]) o + f(min(a, sw))];
function cam1() = campts(E1O, function(a) E1_hornpin(a), e1sw(), E1_tipspan());
function cam2() = campts(E2O, function(a) E2_hornpin(a), e2sw(), E2_tipspan());
module tipcams() color("#e0a040") difference() {
    c1 = cam1(); c2 = cam2();
    union() {
        cam_band(c1, camY1); cam_band(c2, camY2);
        // rib: joins both cams over X 292..300 and hangs from the beam
        translate([bkX[0], ribY[0], 389]) cube([bkX[1]-bkX[0], ribY[1]-ribY[0], bkZ-389]);
        for (c=[c1, c2]) hull() for (q=[c[0], c[len(c)-1]]) translate([q[0]-0.25, c==c1 ? camY1[0] : camY2[0], q[2]+5]) cube([0.5, 3.1, 2]);   // stiffening top flange
        // v1.6 (print fix): strut from the E1 cam band's +X end to the rib (the E1 band was a loose second body). It rises
        // at 35 deg from the band to the rib (in the print pose, on the rib's +X face, it needs no support).
        hull() { translate([c1[0][0]-0.25, camY1[0], c1[0][2]-1.3]) cube([0.5, camY1[1]-camY1[0], 8.3]);
                 translate([bkX[0]+4, ribY[0]+1.6, 389]) cube([0.5, ribY[1]-ribY[0]-1.6, 6]); }
        // v1.6: the E2 band's +X end reaches the rib's +X face (X 300, the bed in the print; it ended 0.14 mm short)
        let(q=c2[0]) translate([q[0]-0.25, camY2[0], q[2]-1.3]) cube([bkX[1]-q[0]+0.25, camY2[1]-camY2[0], 6.3]);
    }
    // 0.4 mm clearance around the pin's real path (pin r 1.5) -> the cam faces
    pin_clear(pinpts(E1O, function(a) E1_hornpin(a), e1sw(), E1_tipspan()), camY1);
    pin_clear(pinpts(E2O, function(a) E2_hornpin(a), e2sw(), E2_tipspan()), camY2);
}
// v1.6 (print fix): the bracket (443 mm tall) is 3 printed pieces: lower post (with the foot), upper post, and the beam
// (with the arm and the pulley cheek). Joints: half laps through the post's X thickness (the lower post and the beam
// keep X 292..296, the upper post X 296..300), 2 countersunk M3 x 10 each (head flush in the X 300 face: the base
// edge; nut in a pocket in the X 292 face). The lower post prints on its X 292 face, the upper post on its X 300 face,
// the beam upside down: no support. The tip cams are a separate print (part 39); v1.5 cut them out of the bracket,
// which left 24 zero-volume slivers.
bk_L1 = [230, 260];                                   // post lap (Z), clear of the back panel bolts at Z 200 and 340
function bk_L2() = [bkZ-24, bkZ];                     // post / beam lap
bk_xm = (bkX[0]+bkX[1])/2;                            // 296
module e2_bracket_body() {
    translate([bkX[0], -9, 0]) cube([bkX[1]-bkX[0], 8, bkZ+6]);                                      // post, in front of the back panel
    translate([bkX[0], -9, 0]) cube([bkX[1]-bkX[0], 22, 6]);                                          // foot, screwed to the base
    translate([bkX[0], -9, bkZ]) cube([bkX[1]-bkX[0], bkY[1]+9, 6]);                                    // beam forward to the pulley arm
    translate([E2P1[0]-5.5, bkY[0], bkZ]) cube([bkX[1]-E2P1[0]+5.5, bkY[1]-bkY[0], 6]);              // arm to the pulley
    difference() { translate([E2P1[0]-5.5, 70, E2P1[2]-4]) cube([11, bkY[0]-70+0.01, bkZ+6-(E2P1[2]-4)]);   // cheek
                   translate([E2P1[0], 60, E2P1[2]]) rotate([-90,0,0]) linear_extrude(40) union() { circle(d=3.2, $fn=16); rotate(225) square(1.6); }; }   // v1.6: teardrop (point up in the upside-down print)
}
module bk_bolts(L) for (z=[L[0]+7, L[1]-7]) translate([0, -5, z]) {
    translate([bkX[0]-1, 0, 0]) rotate([0,90,0]) cylinder(d=m3_clear, h=10, $fn=16);
    translate([bkX[1]-1.71, 0, 0]) rotate([0,90,0]) cylinder(d1=3.4, d2=6.4, h=1.72, $fn=24);       // countersink, flush in the X 300 face
    translate([bkX[0]-0.01, 0, 0]) rotate([0,90,0]) rotate([0,0,30]) cylinder(d=m3_nut, h=2.41, $fn=6);   // nut pocket (flats to +-Y)
}
module bk_box(x0, x1, z0, z1) translate([x0, -20, z0]) cube([x1-x0, 120, z1-z0]);
module e2_bracket_lo() difference() { intersection() { e2_bracket_body(); union() { bk_box(280, 310, -1, bk_L1[0]); bk_box(bkX[0]-1, bk_xm, bk_L1[0]-0.01, bk_L1[1]); } }
                                      bk_bolts(bk_L1); }
module e2_bracket_hi() difference() { intersection() { e2_bracket_body(); translate([0, -20, 0]) cube([1000, 19, 1000]);   // the post only (Y < -1)
                                          union() { bk_box(bk_xm, bkX[1]+1, bk_L1[0], bkZ+7); bk_box(280, 310, bk_L1[1], bk_L2()[0]); } }
                                      bk_bolts(bk_L1); bk_bolts(bk_L2()); }
module e2_bracket_beam() difference() { intersection() { e2_bracket_body();
                                          union() { bk_box(200, 310, bkZ, bkZ+7); bk_box(240, 280, bkZ-20, bkZ+1); bk_box(bkX[0]-1, bk_xm, bk_L2()[0]-0.01, bkZ+1); } }
                                        translate([bk_xm, -9.01, bkZ-1]) cube([bkX[1]-bk_xm+1, 8.01, 8]);   // the upper post's half at the corner
                                        bk_bolts(bk_L2()); }
module e2_bracket() color("#4a5360") {
    e2_bracket_lo(); e2_bracket_hi(); e2_bracket_beam();
    color("silver") translate([E2P1[0], 63.5, E2P1[2]]) rotate([-90,0,0]) cylinder(d=3, h=bkY[0]-70+8.5, $fn=12);  // pulley pin
    tipcams();
}
// v5: P3 bracket on the stack's front top beam: carries Elevator 2's second top pulley (P3) and the rope anchor, and
// the "ELEVATOR 2  TYPE 2" label (6 mm raised text, seen from the front over the gap knob).
E2P3 = [262, 67, 0] + E2_info()[7];
module p3_bracket() color("#4a5360") {
    difference() {
        union() {
            translate([62, postYf[1], 390]) cube([153, 3, 443.06-390]);                                     // plate, bolted to the beam's front face
            translate([E2P3[0], postYf[1]+3, E2P3[2]]) rotate([-90,0,0]) cylinder(d=8, h=64.3-postYf[1]-3, $fn=24);   // P3 pin boss
            translate([E2ANC[0]-4, postYf[1]+3, E2ANC[2]-3]) cube([8, 69-postYf[1]-3, 6]);                     // anchor arm
        }
        translate([E2P3[0], 50, E2P3[2]]) rotate([-90,0,0]) cylinder(d=pin_hole-0.15, h=30, $fn=16);
        translate([E2ANC[0]-6, 66, E2ANC[2]]) rotate([0,90,0]) cylinder(d=2, h=12, $fn=10);                  // tie hole for the rope end
        for (x=[80, 190]) translate([x, 50, 394.65]) rotate([-90,0,0]) cylinder(d=m3_clear, h=20, $fn=16);   // M3 into the beam
    }
    color("#f4f1ea") translate([163, postYf[1]+3-0.01, 430.5]) rotate([90,0,180]) linear_extrude(0.81) text("ELEVATOR 2  TYPE 2", size=6.2, halign="center", valign="center", font="Liberation Sans:style=Bold");
    color("silver") translate([E2P3[0], 58, E2P3[2]]) rotate([-90,0,0]) cylinder(d=3, h=14, $fn=12);
}
// ---------------- base, back panel, feet ----------------
// v5: base front edge at Y 161.5 (the E1 feed's wall reaches 161.7; v4 162)
Lx0 = -26; L = 300; Wy0 = -15; Wy1 = 161.5;     // base from X -26 (left channel) to 300
module base() { base_plate(); back_panel(); }
module feet() lev_wheels();

// ---------------- elevators (rig coordinates placed) ----------------
module elevators(a1=e1a, a2=e2a) {
    translate([245.8, 103, 0]) E1_v1(a1, ball=false);
    translate([262, 67, 0]) E2_v1(a2);
}

// v5: cords and ropes in world coordinates (checks and pictures)
module E1cords_w(a) translate(E1O) E1_cords(a);
module E2rope_w(a) translate(E2O) E2_rope(a);
// the ES pencil (7.5 mm hex, held across the chute in the hole) and the start line plane, for the 4.g check
module pencil() at_loop() at_station(CL_st(), CL_rp()+9.5, -40) cylinder(d=7.5, h=100, $fn=6);
// ---------------- whole coaster ----------------
module stack() { for (i=[0:n-1]) ramp(i); for (i=[0:n-2]) uturn(i); frame(); gapdrive(); }
module ladders() { cage(0); cage(1); carriage(1, k1); carriage(0, k2); }
echo(E1top=E1top, E1end=E1end, E2top=E2top, E2end=E2end);
module coaster() {
    base(); feet();
    stack();
    ladders(); tops();
    gate(); feeds(); e1feed(); gate_cord();
    elevators(); e2_bracket(); pads();
    at_loop() CL_v1(); loop_brackets(); p3_bracket();
    color("silver") at_loop() translate(CL_ballstart()) sphere(r=ball_r, $fn=24);                     // ball at the start, resting on the pencil
}
// ---- groups for the collision checks (check_v1.py) ----
// static = never moves during a run. Carriages are static in a run (set before it), checked at every position.
module static_parts(g=gap, skip="", nf=false, nt=false) {   // nf: (v5b: no flaps any more, ignored); nt: the latch trip pins (the ball presses them)
    if (skip!="base")   { base(); feet(); }
    if (skip!="stack")  { for (i=[0:n-1]) ramp(i); for (i=[0:n-2]) uturn(i); frame(); gapdrive(); }
    if (skip!="ladder") { cage(0); cage(1); tops(); }
    if (skip!="feeds")  { gate(); feeds(); e1feed(); }
    if (skip!="loop")   { at_loop() CL_v1(); loop_brackets(); }
    if (skip!="e1")     translate([245.8, 103, 0]) { if (nt) E1_static_nt(); else E1_static(); }
    if (skip!="e2")     translate([262, 67, 0]) { if (nt) E2_static_nt(); else E2_static(); }
    if (skip!="bracket") { e2_bracket(); p3_bracket(); }
}
module all_carriages() { for (i=CH[0][4]) carriage(0, i); for (i=CH[1][4]) carriage(1, i); }
if (part=="assembly") coaster();
if (part=="stack") stack();
if (part=="elevators") elevators();
if (part=="ladders") ladders();
if (part=="loop") at_loop() CL_v1();
echo(str("Ztop ", Ztop, "  yS ", yS, "  yK ", yK, "  pitch ", Pp, "  ramp 19 end ", rend(18)));
echo(ladder_right=[ for (i=CH[0][4]) [i+1, cupEntryZ(i)] ], ladder_left=[ for (i=CH[1][4]) [i+1, cupEntryZ(i)] ]);
// v5b printable parts (world pose; lay them flat in the slicer): E1 tray with its ledge, E2 funnel, loop brackets and
// spacer (print 4), gap slide, peg plate
if (part=="tray_e1")        tray(1);
if (part=="e2_funnel")      e2_funnel();
if (part=="loop_bracket_R") loop_bracket_R();
if (part=="loop_bracket_L") loop_bracket_L();
if (part=="loop_spacer")    loop_spacer([0, 0]);
if (part=="gap_slide")      pg_slide_s(0);
if (part=="peg_plate")      intersection() { gd_static(); translate([30, 60, -0.01]) cube([90, 40, 2.02]); }
