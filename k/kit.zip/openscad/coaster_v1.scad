// ROLLER COASTER R3 - v1 full design (2026-10-27). Everything in mm.
// World axes: X = length (left to right, 0 = left edge), Y = depth (back panel at the back, Y grows toward the
// viewer), Z = up (0 = top of the plywood base). Same layout as the simulator's R3 (sim cm x10), with the real part
// sizes. Shown with ladder 1 -> ramp 7, ladder 2 -> ramp 6, rail gap 14.3 mm.
//
// Ball path: start (pencil) -> chute -> 12 cm loop -> felt corner -> Elevator 1 (Type 1, front) -> catch flap ->
// front tray -> LEFT ladder channel -> carriage 1 -> ramp 7 ... ramp 19 (U-turn stop cups) -> bottom gate ->
// Elevator 2 (Type 2, back) -> catch flap -> RIGHT ladder channel -> carriage 2 -> ramp 6 ... ramp 19 -> gate (opened
// by a cord from Elevator 2's lever) -> finish track -> finish line -> felt stop.
//
// Fix (c), 2026-10-27 night (replaces the shared channel): near the top of a lift the cup comes up from below and to
// the RIGHT (its arc), and the lever fills the space on its left. A fixed tray at the pour side is hit by the cup, and
// E1's tray could not cross E2's swing to a shared channel. So each elevator pours onto a light hinged CATCH FLAP: the
// rising cup lifts it, at the top the flap falls back under the cup's lip. E1's ball runs along a tray in front of
// everything to a channel on the LEFT end; E2's ball drops into the RIGHT channel. One carriage per channel: no
// ladder flap, no square shaft. The gate flap is opened by a cord from E2's lever.
//
// part = "assembly" (default) | a printable part name (see the list at the end) | a subsystem for checks.
use <common.scad>
use <rail_test.scad>
use <coaster_e1.scad>
use <coaster_e2.scad>
use <coaster_loop.scad>
include <common.scad>

part = "assembly";
gap  = 14.3;                 // rail gap shown (12 .. 16.5)
k1 = 6; k2 = 5;              // ladder targets (0-based ramp index): ramp 7 (left channel, even) and ramp 6 (right, odd)
e1a = -52.2; e2a = -53.1;    // elevator angles shown (rest)

// ---------------- the stack ----------------
th = 2.5; Lr = 200; n = 19; x0 = 30; xRe = x0 + Lr*cos(th);       // ramp ends at X 30 and 229.8
drop = 8.05;                                                         // ball drop in each U-turn cup (exit 2.5 mm below entry)
Pp = Lr*sin(th) + drop;                                              // level pitch 16.77
Z19 = 56;                                                            // ramp 19 end ball line (16 mm above Elevator 2's cup)
Ztop = Z19 + (n-1)*Pp + Lr*sin(th);                                  // ramp 1 start, 366.7
planeY = [16, 38];                                                   // back / front ramp planes (ball line)
function dirOf(i) = i%2 ? -1 : 1;
function entry(i) = [i%2 ? xRe : x0, planeY[i%2], Ztop - i*Pp];
function rend(i)  = entry(i) + [dirOf(i)*Lr*cos(th), 0, -Lr*sin(th)];
cc12 = rod_cc(12); kR = (ball_r + rod_d/2)/ball_r;
d2 = rod_cc(gap) - cc12;                                             // outer rail moved by the gap knob
ballZ0 = 12 + rod_drop(12);                                          // ball line above the spine bottom (gap 12): 20.57
slabOut = 21.1;                                                      // slab reaches this far outward of the inner rod
// a ramp's spine frame: x along the ramp, y = 0 at the inner (fixed) rod, -y outward, z = 0 at the spine bottom
module at_ramp(i) translate(entry(i)) rotate([0,0, i%2 ? 180 : 0]) rotate([0,th,0]) translate([0, cc12/2, -ballZ0]) children();
// both start 1 mm in: the 2.5 deg tilt otherwise pushes the end face 0.9 mm into the cup before it (Fusion check)
module stack_spine() intersection() { spine(200); translate([1, -slabOut, -1]) cube([200, slabOut+3.6, 40]); }
module stack_carrier() intersection() { carrier(200); translate([1, -3, -1]) cube([200, 5, 30]); }
module ramp(i) at_ramp(i) {
    color("#d08a4a") stack_spine();
    color("#59a5c4") translate([0, -rod_cc(gap), 4]) stack_carrier();
    color("silver") { translate([100, 0, 12]) rotate([0,90,0]) cylinder(d=rod_d, h=196, center=true, $fn=12);
                      translate([100, -rod_cc(gap), 12]) rotate([0,90,0]) cylinder(d=rod_d, h=196, center=true, $fn=12); }
}
// U-turn stop cup after ramp i (rail_test stopcup, placed by its test coordinates: ramp end at x 200, ball line y 0,
// gap-12 ball line z 39.69).
test_ball_z = 39.69; test_cup_in = 35.637;
module uturn(i) translate(rend(i)) rotate([0,0, i%2 ? 180 : 0]) translate([-200, 0, -test_ball_z])
    color("#6cbf8f") stopcup(0.5, "STOP", false, test_cup_in - 2.5, side_in=false, zcut=15, x_in=true);   // every cup has the ladder slot (left channel: odd cups, right: even)
module uturn_pad(i) translate(rend(i)) rotate([0,0, i%2 ? 180 : 0]) translate([-200, 0, -test_ball_z]) stoppad(0.5, test_cup_in - 2.5);
// frame: 4 posts, tabs from every spine to the posts, top beams
postX = [34, 222.8]; postYb = [-9, -5]; postYf = [53.65, 57.65];   // front posts 1 mm out: the carriers reach Y 52.8 at gap 16.5
yS = Ztop + 16; yBeam = yS + 10; yK = yS + 24;
function ballZat(i, x) = entry(i)[2] - abs(x - entry(i)[0])*tan(th);  // ball line height over X on ramp i
module frame() color("#4a5360") {
    for (px=postX) { translate([px-4, postYb[0], 0]) cube([8, 4, yBeam+4]); translate([px-4, postYf[0], 0]) cube([8, 4, yBeam+4]); }
    for (py=[postYb[0], postYf[0]]) translate([postX[0]-4, py, yBeam]) cube([postX[1]-postX[0]+8, 4, 4]);
    for (px=postX) translate([px-4, postYb[0], yBeam]) cube([8, postYf[1]-postYb[0], 4]);
    for (i=[0:n-1], px=postX) let(zb=ballZat(i,px)-ballZ0) {
        // tabs butt against the spine's base plate, 1 mm low: the carriers pass over them at every gap
        if (i%2==0) translate([px-3, postYb[1], zb-1]) cube([6, planeY[0]+cc12/2-slabOut-postYb[1], 4]);
        else        translate([px-3, planeY[1]-cc12/2+slabOut, zb-1]) cube([6, postYf[0]-(planeY[1]-cc12/2+slabOut)+0.5, 4]);
    }
}
// gap drive (as in the simulator): 2 comb frames (bars at xB), arms to every carrier, lead screw with opposite
// threads, 16T pinion on the screw, 32T gear + knob + dial above, guide rods at the bottom
xB = [50, 209.8]; xm = (x0+xRe)/2; LEAD = 0.8;
zBarB = planeY[0] + cc12/2 - slabOut - 2 - d2;  zBarF = planeY[1] - cc12/2 + slabOut + 2 + d2;
zG = planeY[1] - cc12/2 + slabOut + 2 + 11.5;   yG = Z19 - ballZ0 - 16;
module gapdrive() { gd_frame(0); gd_frame(1); gd_static(); }
// one comb frame (s = 0 back, 1 front): bars, guide-rod stubs, arms to its carriers (moves with the gap knob)
module gd_frame(s) let(zb=[zBarB, zBarF][s]) {
    color("#59a5c4") {
        for (x=xB) { translate([x-1.5, zb-1.5, yG]) cube([3, 3, yS-yG]); translate([x-2.5, zb-2.5, yG-2]) cube([5, 5, 5]); }
        difference() {
            union() { translate([xB[0]-1.5, zb-1.5, yS-1.5]) cube([xB[1]-xB[0]+3, 3, 3]);
                      translate([xm-4, zb-3, yS-4]) cube([8, 6, 8]); }   // top bar + screw nut block (6 deep: clears the back panel at gap 16.5)
            translate([xm, zb-4, yS]) rotate([-90,0,0]) cylinder(d=4.4, h=8, $fn=16);   // the lead screw passes through (M4 nut inside the block)
        }
    }
    // arms: from each carrier's outer face to its frame bar, just under the rods
    color("#59a5c4") for (i=[0:n-1], x=xB) if ((i%2==0) == (s==0)) let(z=ballZat(i,x)-ballZ0+12-4, back=(i%2==0),
        yo = back ? planeY[0]+cc12/2-rod_cc(gap)-2.6 : planeY[1]-cc12/2+rod_cc(gap)+2.6) {
        if (back) translate([x-1, zBarB+1.5, z]) cube([2, yo-zBarB-1.5, 2]);
        else      translate([x-1, yo, z]) cube([2, zBarF-1.5-yo, 2]);
    }
    color("silver") for (x=xB) translate([x, zb-3, yG]) rotate([-90,0,0]) cylinder(d=3, h=8, $fn=12);
}
// fixed part of the gap drive: lead screw, gears, bracket, knob, dial
module gd_static() {
    color("silver") translate([xm, -8.5, yS]) rotate([-90,0,0]) cylinder(d=4, h=zG+0.5+8.5, $fn=16);
    sa = -d2/LEAD*360;
    color("#c9a25a") { translate([xm, zG, yS]) rotate([-90,0,0]) rotate([0,0,sa]) gear(16, 1, 3, 4);
                       translate([xm, zG, yK]) rotate([-90,0,0]) rotate([0,0,-sa/2+11.25]) gear(32, 1, 3, 3.25); }
    color("#4a5360") translate([xm-4, zG-4, yBeam]) cube([8, 3, yK-yBeam+4]);              // gear bracket
    color("#d08a4a") translate([xm, zG+5.3, yK]) rotate([-90,0,0]) { cylinder(r=11, h=6, $fn=40); translate([-1,0,6]) cube([2, 10, 1]); }   // knob + pointer
    color("#2e343d") translate([xm, zG+4.4, yK]) rotate([-90,0,0]) cylinder(r=15.5, h=0.8, $fn=48);      // dial (clear of the 32T gear)                                     // dial
}

// ---------------- ladder channels (fix c: one per elevator) ----------------
// A cage of 4 steel rods (3 mm) the ball falls down in; one carriage locks onto an index hole with a pin and turns the
// ball out through the side that faces the stack, over a short lip into the cup's ladder slot. Channel coordinates:
// local -X faces the stack. RIGHT channel (E2): world (268, 38), feeds the right-end cups (odd ramps 2..18).
// LEFT channel (E1): world (-8.2, 16), mirrored, feeds the left-end cups (even ramps 3..19).
chHalf = 11.75;                                               // rod offset from the centre (ball 19.05 falls inside)
CH = [ [268, 38, 70, 367, [for (i=[1:2:n-2]) i], false],      // right: x, y, bottom, top, ladder positions, top ring?
       [-8.2, 16, 52, 355.4, [for (i=[2:2:n-1]) i], true] ];  // left   (right top: the E2 tray's end clips onto the rods)
chX = CH[0][0]; chY = CH[0][1]; chZ0 = CH[0][2]; chZ1 = CH[0][3];
function cupEntryZ(i) = entry(i)[2] + 4;                      // ball centre where a carriage hands over (into ramp i's cup)
module at_ch(s) translate([CH[s][0], CH[s][1], 0]) mirror([s==1 ? 1 : 0, 0, 0]) children();
module cage(s) at_ch(s) let(z0=CH[s][2], z1=CH[s][3]) {
    color("silver") for (sx=[-1,1], sy=[-1,1]) translate([sx*chHalf, sy*chHalf, z0]) cylinder(d=3, h=z1-z0, $fn=12);
    color("#4a5360") for (z=CH[s][5] ? [z0, z1-6] : [z0]) difference() {      // rod rings at the ends (the carriage slides between)
        translate([-chHalf-4, -chHalf-4, z]) cube([2*chHalf+8, 2*chHalf+8, 6]);
        translate([-chHalf+2, -chHalf+2, z-1]) cube([2*chHalf-4, 2*chHalf-4, 8]);
        translate([-chHalf-5, -9, z-1]) cube([8, 18, 8]);                       // stack side open: the carriage lip passes
    }
    // index strip with a hole for every ladder position, on the outer side
    // (v3) strip 2 mm further in: the v3 cup's side plate passes at Y 54.4 (right channel, world)
    color("#4a5360") difference() { translate([chHalf+2, chHalf-3, z0]) cube([4, 7, z1-z0-5]);   // stops 5 below the top (E2's cup passes)
        for (i=CH[s][4]) translate([chHalf+1, chHalf+1, cupEntryZ(i)+1]) rotate([0,90,0]) cylinder(d=3.2, h=8, $fn=12); }
}
module carriage(s, i) at_ch(s) let(z=cupEntryZ(i)) {
    color("#d08a4a") difference() {                            // sleeve around the cage
        translate([-chHalf-4, -chHalf-4, z-6]) cube([2*chHalf+8, 2*chHalf+8, 14]);
        translate([-chHalf-2, -chHalf-2, z-7]) cube([2*chHalf+4, 2*chHalf+4, 16]);
        translate([-chHalf-5, -9, z-7]) cube([8, 18, 16]);
        translate([chHalf+1.5, chHalf-3.5, z-7]) cube([5, 8, 16]);                // notch: slides along the index strip
    }
    color("silver") translate([chHalf+1.8, chHalf+1, z+1]) rotate([0,90,0]) cylinder(d=3, h=8.2, $fn=12);     // index pin (in the sleeve's height)
    // deflector: a 35 deg ramp across the cage that sends the ball out of the stack side into the cup's slot
    // (v3) 4 mm thick with a flush EVA pad (20 x 16 x 2) where the ball lands: it can fall up to 29 cm (2.4 m/s, sim)
    color("#d08a4a") translate([0, 0, z+2]) rotate([0, -35, 0]) difference() { translate([-14, -chHalf+1.6, -2.5]) cube([28, 2*chHalf-3.2, 4]);
        translate([-10.2, -8.2, -0.6]) cube([20.4, 16.4, 2.2]); }   // pocket 0.2 mm bigger all round than the pad
    color("#2b2b2b") translate([0, 0, z+2]) rotate([0, -35, 0]) translate([-10, -8, -0.5]) cube([20, 16, 2]);
    // short lip from the cage to the cup's outer wall (the cup wall is 17.6 mm from the channel centre)
    color("#d08a4a") translate([-17.3, -8, z-ball_r-2]) cube([17.3-chHalf+1.5, 16, 2]);
}

// ---------------- elevator tops: catch flaps and trays ----------------
// Flap = 2 mm plate on a hinge pin along X at its far edge. Shown DOWN (resting on its stop): at the top the cup's
// lowest point is 1.4 mm above it. While the cup rises it lifts the flap (not part of the static checks).
E1top = [245.8, 103, 0] + E1_topseat();  E2top = [262, 67, 0] + E2_topseat();   // ball on the seat of the tipped cup at the top
E1end = [245.8, 103, 0] + E1_topend();   E2end = [262, 67, 0] + E2_topend();     // ... and at the open end of its floor
function flapz(f, x, y) = f[0] + (y - f[1])*f[2] + (x - f[3])*f[4];    // top surface: z at (x,y)
F1 = [374.0, 94, -tan(5.3), 253, -tan(1)];                       // E1 flap: x 253..274, y 94 -> 128.5 (falls toward +Y)
F2 = [375.0, 80,  tan(7.0), 266, -tan(1)];                     // E2 flap: x 266..290, y 80 -> 50 (falls toward -Y)
module flap(f, x0, x1, y0, y1, hy) color("#e0a040") {
    hull() for (x=[x0, x1], y=[y0, y1]) translate([x, y, flapz(f, x, y) - 2]) cube([0.01, 0.01, 2]);
    let(py=hy + 2*sign(y0-hy)) color("silver") translate([x0, py, flapz(f, x0, py) - 3]) rotate([0,90,0]) cylinder(d=2, h=x1-x0, $fn=10);   // hinge pin
}
module flaps() { flap(F1, 253, 274, 94, 128, 128); flap(F2, 266, 290, 80, 50, 50); }
// tray axis points (ball centre = axis - 0.8 when it rolls on the trough floor)
E1tray = [[264, 128.5, 380.8], [264, 135, 380.4], [230, 135, 379.4], [100, 135, 375.6], [-8.2, 135, 372.1],
          [-8.2, 100, 370.6], [-8.2, 50, 368.6], [-8.2, 16, 366.7]];   // v3: 1.5 mm lower with the flap (tipped cup)
E2tray = [[275, 49.5, 381.4], [275, 41.5, 380.7], [268, 38, 380.0]];   // the drop column (r 9.5 at x 268, y 38) clears the flap's hinge pin (y 51)
// ball path over each flap (from the cup lip to the tray)
E1pour = [E1top, E1end, E1end+[3.3, 1, -1.9], [263, 108, 383.1], [264, 118, 382.0], E1tray[0]-[0,0,0.8]];
E2pour = [E2top, E2end, E2end+[2.6, -4, -2.7], [276.5, 60, 382.7], [275.5, 54, 381.9], E2tray[0]-[0,0,0.8]];
function down(p) = [for (q=p) q-[0,0,0.8]];
module tray(s) color("#d08a4a") if (s==1) trough_chain(E1tray, open_start=true, drop_end=true, pads=[1, 4]);
                                 else trough_chain(E2tray, open_start=true, drop_end=true);
module tops() { tray(1); tray(0); }

// ---------------- gate, feeds, finish ----------------
// Gate box at ramp 19's end. First pass: the flap is shut and the floor slopes to the +Y door, the ball rolls out to
// the E2 feed. Second pass: the cord from E2's lever has pulled the flap open, the ball drops to the finish track.
// trough_chain: printed half-pipe along points; open top slot (ball always visible). mouth: open from above at the
// start (ball drops in); drop_end: hole down at the end (ball drops out); open_start/open_end: no end cap;
// pads: indexes of corner points that get an EVA pad pocket in the outer wall.
// EVA pads in the trough corners (same place as the pockets in trough_chain: inner face flush with the trough wall)
module trough_pads(pts, pads, rin=ball_r+0.8) color("#2b2b2b")
    for (k=pads) let(d=pts[k]-pts[k-1], u=d/norm([d[0],d[1]])) translate(pts[k]+[u[0],u[1],0]*(rin+1)) rotate([0,0,atan2(u[1],u[0])]) rotate([0,90,0]) cylinder(d=pad_dot, h=2, center=true, $fn=24);
module pads() { for (i=[0:n-2]) uturn_pad(i); trough_pads(E1tray, [1, 4]); trough_pads(E1feed, [1, 4]); trough_pads(E2feed, [4]); }
// halfspace() and trough_chain() are in common.scad (v3: the test rigs use them too)
gx0 = 230; gx1 = 258; gy0 = 3; gy1 = 31; gfl = 40;            // gate box outside / floor top
E2feed = [[244, 17, 49.9], [244, 26, 49.6], [243, 36, 48.5], [243, 50, 45.6], [239, 67, 39.6], [250, 67, 37.3]];   // v3: foam corner at [4] (sim: 0.38 m/s into the cup)
finish_pts = [[244, 17, 21], [244, 24, 19.8], [236, 26, 19.2], [200, 26, 17.6], [120, 26, 14.8], [68, 26, 13.2]];
finish_x = 100;                                              // finish line (rule 3.f) across the finish track
module gate(flap=true) {
    color("#4a5360") difference() {
        translate([gx0, gy0, gfl-6]) cube([gx1-gx0, gy1-gy0, 24]);
        translate([gx0+2, gy0+2, gfl]) cube([gx1-gx0-4, gy1-gy0-4, 30]);                 // inside 24 x 24
        translate([233, 6, gfl-7]) cube([22, 22, 8]);                                     // drop hole to the finish
        translate([gx0-1, gy0+2, gfl+2]) cube([4, gy1-gy0-4, 30]);                       // -X door: ramp 19 comes in (all gaps)
        translate([232.5, gy1-3, gfl-0.01]) cube([23, 4, 30]);                            // +Y door: out to the E2 feed (floor level)
    }
    if (flap) color("#e0a040") translate([233.2, 6.2, gfl-1.5]) cube([21.6, 21.6, 1.5]);   // flap, shut (first pass), flush
}
module feeds() {
    color("#d08a4a") difference() { trough_chain([for (k=[2:len(E2feed)-1]) E2feed[k]], open_start=true, open_end=true, pads=[2]); trip_slot(E2O); }   // pad at E2feed[4]
    color("#d08a4a") trough_chain(finish_pts, mouth=true);
    color("#d6a648") { for (y=[26-ball_r-6.5, 26+ball_r+4.5]) translate([finish_x-1, y, 0]) cube([2, 2, 31]);   // finish line gantry
                       translate([finish_x-1, 26-ball_r-6.5, 29]) cube([2, 2*ball_r+13, 2]); }
    color("#2e343d") translate([68-ball_r-0.8-1.0, 26, 13.2]) rotate([0,90,0]) cylinder(d=10, h=2, center=true, $fn=24);   // felt stop (rule 3.h) in the end cap
}
// cord: E2 lever (30 mm from its pivot) -> pulley at the base -> along the base -> up to the gate flap's crank
module gate_cord() color("white") let(f=[128.1, 67, 232.3], p=f+30*[cos(-53.1), 0, sin(-53.1)],
        q=[[p[0], 63, p[2]], [p[0], 63, 4], [259, 63, 4], [259, 20, 4], [259, 20, 38], [254, 17, 38.5]])
    for (k=[0:len(q)-2]) hull() { translate(q[k]) sphere(0.5); translate(q[k+1]) sphere(0.5); }
// loop: POI at X 160, Z 43.6; loop frame (x, y, w) -> world (160 + x, 119 + w, 43.6 + y)
POIx = 145; POIz = 43.6; loopY0 = 119;         // 15 mm left of the sim spot: room for the E1 feed corner
module at_loop() translate([POIx, loopY0, POIz]) mirror([0,1,0]) rotate([90,0,0]) children();
// E1 feed: loop exit (lane B, Y 150.5, X 205) -> felt corner at X 215 (pad on its +X wall; the ball clears the lane's
// end) -> back (-Y), jogging left to X 206.5 so it passes left of E1's latch crank (X >= 219.6, Y 116..120) -> round
// into the cup from -X, 4.5 mm above the seat
E1feed = [[205, 150.5, 53.8], [215, 150.5, 53.3], [215, 136, 51.4], [206.5, 126, 49.6], [206.5, 102.6, 39.4], [233.8, 102.6, 37.3]];   // v3: foam corner at [4], 2.1 mm drop after it
// (v3) slot in the end of each feed for the latch trip pin (2 mm inside the end, 0.7 mm up into the ball path)
module trip_slot(o) translate(o + [-14-2.5, -7, 23]) cube([5, 14, 6]);
module e1feed() color("#d08a4a") difference() { trough_chain(E1feed, open_start=true, open_end=true, pads=[1, 4]); trip_slot(E1O); }   // v3: 2nd foam corner just before the cup (sim: the ball came in at 0.42 m/s, the cup holds 0.25)
// loop board: 3 mm plywood in front of Elevator 1's plate, the loop pieces screw to it
module loop_board() color("#c8a979") translate([25, loopY0-3, 28]) cube([165, 3, 235]);

// ---------------- top frame: Elevator 2's top pulley, the rope anchor and the two tip cams ----------------
// (v3, 2026-10-28) v2's post stood in the gap between the cup sweeps, but the v3 cups carry their real latch tail
// (E2's reaches Y 84) and horn pins (E1's reaches Y 86), so nothing can stand in that gap below the tops. A post at
// the back right (in front of the back panel) carries a beam forward at the top; from it hang the top pulley's cheek,
// the rope anchor and the tip-cam block. The cams sit where only the horn pins pass.
E2P1 = [259.435, 67, 470.066];  E2ANC = [299, 134, 475.066];   // from coaster_e2.scad (P1v, anchor), world
bkX = [292, 300]; bkY = [82, 88]; bkZ = 476;
E1O = [245.8, 103, 0]; E2O = [262, 67, 0];
function e1sw() = E1_info()[7];  function e2sw() = E2_info()[3];
// cam bands (world Y): E1's pin is exposed at Y 86..90.4, E2's at 79.6..84; a 3 mm rib between them
camY1 = [86.6, 89.7]; camY2 = [80.3, 83.4]; ribY = [83.4, 86.6];
function campts(o, f, sw, span) = [for (a=[sw-span-1.0 : 0.25 : sw]) let(lead = a < sw-span ? (sw-span-a)*2.0 : 0) o + f(a) + [0,0,1.8+lead]];   // cam face points (pin top + 0.3, + lead-in)
module cam_band(pts, y) for (k=[0:len(pts)-2]) hull() for (q=[pts[k], pts[k+1]]) translate([q[0]-0.25, y[0], q[2]-1.3]) cube([0.5, y[1]-y[0], 6.3]);
module pin_clear(pts, y) for (k=[0:len(pts)-2]) hull() for (q=[pts[k], pts[k+1]]) translate([q[0], y[0]-1, q[2]]) rotate([-90,0,0]) cylinder(r=1.9, h=y[1]-y[0]+2, $fn=20);
function pinpts(o, f, sw, span) = [for (a=[sw-span-1.5 : 0.1 : sw+0.2]) o + f(min(a, sw))];
function cam1() = campts(E1O, function(a) E1_hornpin(a), e1sw(), E1_tipspan());
function cam2() = campts(E2O, function(a) E2_hornpin(a), e2sw(), E2_tipspan());
module tipcams() color("#e0a040") difference() {
    c1 = cam1(); c2 = cam2();
    union() {
        cam_band(c1, camY1); cam_band(c2, camY2);
        // rib: joins both cams over X 292..300 and hangs from the beam
        translate([bkX[0], ribY[0], 389]) cube([bkX[1]-bkX[0], ribY[1]-ribY[0], bkZ-389]);
        for (c=[c1, c2]) hull() for (q=[c[0], c[len(c)-1]]) translate([q[0]-0.25, c==c1 ? camY1[0] : camY2[0], q[2]+5]) cube([0.5, 3.1, 2]);   // stiffening top flange
    }
    // 0.4 mm clearance around the pin's real path (pin r 1.5) -> the cam faces
    pin_clear(pinpts(E1O, function(a) E1_hornpin(a), e1sw(), E1_tipspan()), camY1);
    pin_clear(pinpts(E2O, function(a) E2_hornpin(a), e2sw(), E2_tipspan()), camY2);
}
module e2_bracket() color("#4a5360") {
    translate([bkX[0], -9, 0]) cube([bkX[1]-bkX[0], 8, bkZ+6]);                                      // post, in front of the back panel
    translate([bkX[0], -9, 0]) cube([bkX[1]-bkX[0], 22, 6]);                                          // foot, screwed to the base
    translate([bkX[0], -9, bkZ]) cube([bkX[1]-bkX[0], E2ANC[1]+3+9, 6]);                               // beam forward to the anchor
    translate([E2P1[0]-5.5, bkY[0], bkZ]) cube([bkX[1]-E2P1[0]+5.5, bkY[1]-bkY[0], 6]);              // arm to the pulley
    difference() { translate([E2P1[0]-5.5, 70, E2P1[2]-4]) cube([11, bkY[0]-70+0.01, bkZ+6-(E2P1[2]-4)]);   // cheek
                   translate([E2P1[0], 60, E2P1[2]]) rotate([-90,0,0]) cylinder(d=3.2, h=40, $fn=16); }
    color("silver") translate([E2P1[0], 63.5, E2P1[2]]) rotate([-90,0,0]) cylinder(d=3, h=bkY[0]-70+8.5, $fn=12);  // pulley pin
    difference() { translate([E2ANC[0]-3, E2ANC[1]-3, E2ANC[2]-5]) cube([6, 6, 5.01]);                // anchor hook
                   translate([E2ANC[0]-4, E2ANC[1], E2ANC[2]-2.5]) rotate([0,90,0]) cylinder(d=2, h=8, $fn=10); }
    tipcams();
}
// ---------------- base, back panel, feet ----------------
Lx0 = -26; L = 300; Wy0 = -15; Wy1 = 162;       // base from X -26 (left channel) to 300
module base() color("#c8a979") { translate([Lx0, Wy0, -6]) cube([L-Lx0, Wy1-Wy0, 6]); translate([Lx0, Wy0, 0]) cube([L-Lx0, 6, yBeam+10]); }
module feet() color("#4a5360") for (x=[Lx0+12, L-12], y=[Wy0+10, Wy1-10]) translate([x, y, -6-8]) cylinder(d=18, h=8, $fn=24);

// ---------------- elevators (rig coordinates placed) ----------------
module elevators(a1=e1a, a2=e2a) {
    translate([245.8, 103, 0]) E1_v1(a1, ball=false);
    translate([262, 67, 0]) E2_v1(a2);
}

// ---------------- whole coaster ----------------
module stack() { for (i=[0:n-1]) ramp(i); for (i=[0:n-2]) uturn(i); frame(); gapdrive(); }
module ladders() { cage(0); cage(1); carriage(1, k1); carriage(0, k2); }
echo(E1top=E1top, E1end=E1end, E2top=E2top, E2end=E2end);
module coaster() {
    base(); feet();
    stack();
    ladders(); tops(); flaps();
    gate(); feeds(); e1feed(); gate_cord();
    elevators(); e2_bracket(); pads();
    at_loop() CL_v1(); loop_board();
    color("silver") at_loop() translate(CL_ballstart()) sphere(r=ball_r, $fn=24);                     // ball at the start, resting on the pencil
}
// ---- groups for the collision checks (check_v1.py) ----
// static = never moves during a run. Carriages are static in a run (set before it), checked at every position.
module static_parts(g=gap, skip="", nf=false, nt=false) {   // nf: leave out the catch flaps (the cups lift them); nt: the latch trip pins (the ball presses them)
    if (skip!="base")   { base(); feet(); }
    if (skip!="stack")  { for (i=[0:n-1]) ramp(i); for (i=[0:n-2]) uturn(i); frame(); gapdrive(); }
    if (skip!="ladder") { cage(0); cage(1); tops(); }
    if (skip!="flaps" && !nf) flaps();
    if (skip!="feeds")  { gate(); feeds(); e1feed(); }
    if (skip!="loop")   { at_loop() CL_v1(); loop_board(); }
    if (skip!="e1")     translate([245.8, 103, 0]) { if (nt) E1_static_nt(); else E1_static(); }
    if (skip!="e2")     translate([262, 67, 0]) { if (nt) E2_static_nt(); else E2_static(); }
    if (skip!="bracket") e2_bracket();
}
module all_carriages() { for (i=CH[0][4]) carriage(0, i); for (i=CH[1][4]) carriage(1, i); }
if (part=="assembly") coaster();
if (part=="stack") stack();
if (part=="elevators") elevators();
if (part=="ladders") ladders();
if (part=="loop") at_loop() CL_v1();
echo(str("Ztop ", Ztop, "  yS ", yS, "  yK ", yK, "  pitch ", Pp, "  ramp 19 end ", rend(18)));
echo(ladder_right=[ for (i=CH[0][4]) [i+1, cupEntryZ(i)] ], ladder_left=[ for (i=CH[1][4]) [i+1, cupEntryZ(i)] ]);
