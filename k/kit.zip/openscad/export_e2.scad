// Elevator 2: each printed part in its assembled position. -D 'p="lever"'
include <elevator2_test.scad>
part2 = "none"; p = "lever"; a2 = -53.1;
en = EN(a2); up = en[2]-EN(-SW)[2]; p2 = [P3[0]+9, 0, P2top - up/2];
if (p=="base_a") base2_half("a");
if (p=="base_b") base2_half("b");
if (p=="tower") tower();
if (p=="lever") translate(F) rotate([0,-a2,0]) rotate([90,0,0]) lever2();
if (p=="cup") translate(E(a2)) cup();
if (p=="crank") translate(H) crank();
if (p=="latch_post") translate([H[0],0,0]) latch_post();
if (p=="feed_hi") feed_riser(-100);
if (p=="feed_lo") feed_riser(-40);
if (p=="post_a1") tall_post(post_x,0,215);
if (p=="post_a2") tall_post(post_x,215,P1[2]+20);
if (p=="post_b1") tall_post(140,0,215);
if (p=="post_b2") tall_post(140,215,P1[2]+20);
if (p=="tray") tray_bracket();
if (p=="top_beam") top_beam();
if (p=="pulley1") translate(P1) pulley();
if (p=="pulley3") translate(P3) pulley();
if (p=="pulley2") translate(p2) pulley();
if (p=="p2_block") translate(p2) p2_block();
if (p=="cw_pot2") translate([p2[0], 0, p2[2]-18-46]) cw_pot2();
