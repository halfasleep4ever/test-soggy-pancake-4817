// TEST 3: Elevator 1 (Type 1: first-class lever + wheel and axle) at R3 size, with the ball-triggered latch.
// Simulator numbers: ball arm 205 mm, effort arm 50 mm, swing +/-52.2 deg, lift 324 mm, IMA = 50/205 * 10/25 = 0.098,
// counterweight about 556 g (falls 32 mm).
// Axes: X right, Z up, the lever swings in the plane Y = 0. The tower plate stands behind it (Y = -20..-12).
//
// How the latch works (v3): a hook holds a ball-bearing roller on the lever, so the lever cannot rise.
// The ball leaves the feed over a trip pin on the hook's crank and presses it down; the hook swings off the roller,
// the ball drops into the cup and the counterweight lifts it. At the top the cup's horn pin runs under a fixed cam,
// the cup tips 28 deg and the ball rolls out of the open end of its floor.
include <common.scad>

part = "assembly";   // assembly | base | plate | gusset | lever | cup | wheel | idler | crank | latch_post |
                     // feed_riser_hi | feed_riser_lo | post_lower | post_upper | rig_flap | rig_cam | rig_top_post | rig_tray | cw_pot | spacers
show_angle = -52.2;  // lever angle in the assembly view (-52.2 = waiting for the ball, +52.2 = top)

A   = 205;  LS = 50;  SW = 52.2;
cs = cos(SW); sn = sin(SW);
E0z = 54;                                   // cup pin height at the bottom
P   = [-A*cs, 0, E0z + A*sn];               // lever pivot (-125.6, 0, 216)
function E(a)  = [P[0]+A*cos(a), 0, P[2]+A*sin(a)];      // cup pin
function S(a)  = [P[0]-LS*cos(a), 0, P[2]-LS*sin(a)];    // effort-arm end (cord)
S1  = S(SW);
W   = [S1[0]-25, 0, S1[2]-35];              // wheel centre (wheel R 25, drum r 10)
cw_drop = 2*A*sn * (LS/A) * (10/25);        // 31.6 mm
I   = [W[0]-41.5, -6.5, W[2]+32+cw_drop+35];  // idler (r 6.5): far enough out that the pot hangs clear of the wheel
R_local = A - 26/cos(SW);                   // v3: roller 26 mm left of the cup pin at rest (trip arm 12 mm long)
R0  = [P[0]+R_local*cos(-SW), 0, P[2]+R_local*sin(-SW)]; // roller at rest (-26, 0, about 87)
roller_r = 3; roller_y = 15.25;             // MR63 used as a roller, centre plane y = 15.25
crank_y0 = 13; crank_y1 = 17;
H   = [R0[0], 0, R0[2] + roller_r - 26.8];  // crank pivot (directly under the roller: the roller force makes no torque)
plate_y0 = -20; plate_y1 = -12;
base_x0 = -262; base_x1 = 50; base_split = -100;

// ---------------- parts ----------------
module base() {
    difference() {
        translate([base_x0, -40, -6]) cube([base_x1-base_x0, 75, 6]);
        translate([-240, plate_y0-0.2, -4]) cube([120, plate_y1-plate_y0+0.4, 5]);          // plate slot
        for (x=[-230,-190,-140]) translate([x, (plate_y0+plate_y1)/2, -7]) cylinder(d=m3_clear, h=8);
        for (y=[-30, 25]) translate([base_split, y, -7]) cylinder(d=m3_clear, h=8);           // half-lap bolts
        translate([40-8.2, -33.2, -4]) cube([16.4,16.4,5]);                                 // post socket
        translate([40, -25, -7]) cylinder(d=m3_clear, h=8);
        translate([R0[0]+4.0, crank_y1+0.4, -4]) cube([8.4, 3.4, 5]);                        // latch post socket (v3: 3 mm plate, 8 mm +x)
        for (x=[-140, -40]) translate([x, 0, -4]) cube([20.4, 30.4, 5], center=false);        // feed riser pads (marks)
        translate([-60, -30, -0.6]) linear_extrude(1) text("ELEVATOR 1 TEST", size=6);
    }
}
module base_half(which) {
    lap = 10;
    intersection() {
        base();
        if (which=="a") union() { translate([base_x0-1,-50,-10]) cube([base_split-lap/2-base_x0+1, 100, 20]);
                                   translate([base_split-lap/2-0.01,-50,-10]) cube([lap, 100, 7]); }
        else            union() { translate([base_split+lap/2,-50,-10]) cube([base_x1-base_split, 100, 20]);
                                   translate([base_split-lap/2,-50,-3]) cube([lap+0.01, 100, 10]); }
    }
}
module plate() {
    difference() {
        union() {
            translate([-240, plate_y0, 0]) cube([130, plate_y1-plate_y0, 252]);
            translate([-240, plate_y0, -4]) cube([120, plate_y1-plate_y0, 4]);              // tab into the base slot
            // stop block for the effort arm at the top position (lever angle +52.2)
            translate([S1[0]-6, plate_y1, S1[2]-6-4]) cube([12, 14, 4]);
        }
        for (p=[P, W, I]) translate([p[0], plate_y0-1, p[2]]) rotate([-90,0,0]) cylinder(d=pin_hole-0.15, h=20);
        for (x=[-230,-190,-140]) translate([x, (plate_y0+plate_y1)/2, -5]) cylinder(d=m3_clear, h=12);
        // lighten
        translate([-185, plate_y0-1, 30]) cube([45, 10, 70]);
        translate([-232, plate_y0-1, 30]) cube([30, 10, 120]);
        translate([-140, plate_y0-1, 150]) rotate([-90,0,0]) cylinder(r=12, h=10);
    }
}
module gusset() { difference() { linear_extrude(6) polygon([[0,0],[40,0],[0,60]]); translate([12,0,3]) rotate([-90,0,0]) cylinder(d=m3_clear,h=40,center=true); } }

module lever() {        // in lever coordinates: pivot at the origin, ball arm along +X
    difference() {
        union() {
            hull() { cylinder(d=18, h=8, center=true); translate([-LS,0,0]) cylinder(d=9, h=6, center=true); }
            // (v3) the last 30 mm bow 5 mm to the lever's +y side (up-left at the top): it passes over the ball near the top
            hull() { cylinder(d=14, h=6, center=true); translate([A-30,0,0]) cylinder(d=9, h=6, center=true); }
            hull() { translate([A-30,0,0]) cylinder(d=9, h=6, center=true); translate([A-12,lev_knee,0]) cylinder(d=9, h=6, center=true); }
            hull() { translate([A-12,lev_knee,0]) cylinder(d=9, h=6, center=true); translate([A,0,0]) cylinder(d=9, h=5.6, center=true); }
            translate([A,0,0]) cylinder(d=9, h=5.6, center=true);                         // tongue between the cup ears
            translate([R_local,0,0]) cylinder(d=9, h=6, center=true);
        }
        cylinder(d=4.5, h=20, center=true);
        for (z=[-4.01, 4.01-brg_h]) translate([0,0,z]) brg_pocket();                       // two MR63 bearings
        translate([-LS+2.5,0,0]) cylinder(d=2.2, h=20, center=true);                       // cord hole
        translate([A,0,0]) cylinder(d=pin_hole+0.3, h=20, center=true);                    // cup pin: loose (cup turns on it)
        translate([R_local,0,0]) cylinder(d=pin_hole-0.15, h=20, center=true);             // roller pin: press fit
        translate([60,0,2.4]) linear_extrude(1) text("ELEVATOR 1 - TYPE 1", size=4.5, valign="center");   // rule label, in view
    }
}
// Cup v3 (2026-10-28). The v1/v2 cup was a round pocket 0.7 mm bigger than the ball: tipped, it keeps the ball until
// about 100 deg; its open-top cut also removed the ears and the latch tail. A whole cup that tips swings its bowl into
// the lever arm (it hangs 22 mm under the pin). So the v3 cup stays level and only its FLOOR tips (a seesaw):
//  - cup frame: two side plates at |y| 10.4..12.6 (outside the ball) on the lever pin, an entry lip wall at -x,
//  - floor: a 2 mm plate on its own pin, 4 mm +x of the ball. At rest it slopes 10 deg down to the lip, the ball rests
//    against the lip (the ball's weight holds the floor on its stop);
//  - a horn on the floor's +x end, outside the plates, with a 3 mm steel pin. At the top the pin runs under a fixed cam:
//    the floor turns 14 deg, slopes 4 deg down to its open +x end, and the ball rolls out onto the catch flap.
//    The ball is only 2.6 mm from the floor pin, so the cam needs about 0.03 N (the lever has 0.14 N to spare).
horn_s = -1;                                   // side of the horn (-y or +y), set per elevator
fl_slope = 10; fl_rot = 14; tip_span = 3.0;    // floor slope at rest; floor turn at the top; over the last 3 deg of lever travel (the cams stay inside X 300)
flF0 = [0, 0, -31.6];                          // floor top surface under the pin at rest
flU = [cos(fl_slope), 0, sin(fl_slope)];  flN = [-sin(fl_slope), 0, cos(fl_slope)];
function fl_top(x) = flF0[2] + x*tan(fl_slope);
lipX = -9.5; lipZ = -29.0;                     // entry lip: inner face and top (2.3 mm under the feed ball; 4 mm over the floor)
Pv = [0, 0, fl_top(0) - 2.5];                  // floor pin, under the floor, 2.6 mm +x of the ball (its weight holds the floor down)
flX1 = 24;                                     // floor's open end
hornP = [25.5, -21.0];                         // horn pin centre (x, z), cup frame at rest
function smooth01(t) = let(u=max(0,min(1,t))) u*u*(3-2*u);
function cup_tilt(a) = fl_rot * smooth01((a - (SW - tip_span)) / tip_span);   // floor turn at lever angle a (name kept)
function rotY(p, t) = [p[0]*cos(t) + p[2]*sin(t), p[1], -p[0]*sin(t) + p[2]*cos(t)];   // = rotate([0,t,0])
function about_pv(p, t) = Pv + rotY(p - Pv, t);
function horn_pin(a) = E(a) + about_pv([hornP[0], horn_s*13.4, hornP[1]], cup_tilt(a));   // horn pin centre, rig coordinates
// ball at rest: on the floor and against the lip's top edge
function _bc(s) = flF0 + s*flU + ball_r*flN;
_bs = [for (s=[-12:0.02:4]) abs(norm([_bc(s)[0]-lipX, _bc(s)[2]-lipZ]) - ball_r)];
lev_knee = 5;                                  // lever bow near the cup pin (mm)
cup_seat = _bc(-12 + 0.02*search(min(_bs), _bs)[0]);         // about [-1.4, 0, -23.4]: almost under the pin
cup_end  = _bc(flX1/cos(fl_slope));                            // ball centre at the open end of the floor (floor frame)
cup_drop = -cup_seat[2];
module cup_frame() difference() {
    union() {
        for (s=[-1,1]) translate([0, s > 0 ? 10.4 : -12.6, 0]) rotate([90,0,0]) translate([0,0,-2.2]) linear_extrude(2.2)
            polygon([[-12,-37.6], [-12,-6], [-5,4.5], [5,4.5], [20,-10], [20,-34.0], [3.8,-34.2], [3.8,-37.0], [-4,-37.0], [-4,-37.6]]);   // bottom at -34.2 under the flaps; tab for the floor pin
        for (s=[-1,1]) translate([0, s*(3.0+10.4)/2, 0]) rotate([90,0,0]) cylinder(d=8, h=10.4-3.0, center=true);   // collars to the lever tongue
        translate([-11.8, -10.5, -37.6]) cube([lipX+11.8, 21, lipZ+37.6]);                        // entry lip wall
        translate([lipX-0.01, -10.5, -37.6]) cube([2.5, 21, fl_top(lipX+2.5)-2.5+37.6]);           // floor stop (ledge)
        translate([-16, -4, -38]) cube([4.2, 8, 4]);                                               // weight lug under the lip
    }
    rotate([90,0,0]) cylinder(d=pin_hole, h=30, center=true);
    translate(Pv) rotate([90,0,0]) cylinder(d=pin_hole-0.15, h=30, center=true);                   // floor pin (press in the plates)
    translate([-14, 0, -36]) cylinder(d=m3_nut, h=2.6, center=true, $fn=6);                        // nut pocket to trim the balance
    translate([lipX, 0, lipZ]) rotate([0,45,0]) cube([3, 22, 3], center=true);                     // 2 mm chamfer on the lip edge: the dropping ball rolls off it
}
module cup_floor() difference() {                     // the seesaw floor (at rest), with its horn
    union() {
        hull() for (x=[lipX+0.3, flX1]) translate([x, -10.2, fl_top(x)-2]) cube([0.01, 20.4, 2]);
        translate(Pv) rotate([90,0,0]) cylinder(d=4.9, h=20.4, center=true);
        hull() for (x=[21, flX1+3]) translate([x, horn_s > 0 ? 10.2 : -13.0, fl_top(x)-1.2]) cube([0.01, 2.8, 2.2]);    // horn foot (0.8 mm up: clears the E2 flap)
        hull() { translate([21, horn_s > 0 ? 10.2 : -13.0, fl_top(21)-1.2]) cube([flX1+3-21, 2.8, 2.2]);
                 translate([hornP[0], horn_s > 0 ? 10.2 : -13.0, hornP[1]]) rotate([-90,0,0]) cylinder(d=6, h=2.8); }  // horn
        hull() for (x=[20.4, flX1]) translate([x, horn_s > 0 ? 9.6 : -10.2, fl_top(x)-2]) cube([0.01, 0.6, 2]);         // joins the horn foot
    }
    translate(Pv) rotate([90,0,0]) cylinder(d=pin_hole+0.2, h=30, center=true);                    // turns on the pin
    translate([hornP[0], horn_s*11.6, hornP[1]]) rotate([90,0,0]) cylinder(d=2.9, h=3, center=true);  // horn pin (3 mm steel, press)
}
module horn_pin_part(t=0) color("silver") translate(about_pv([hornP[0], horn_s*13.4, hornP[1]], t)) rotate([90,0,0]) cylinder(d=3, h=6.4, center=true, $fn=16);   // |y| 10.2..16.6
module cup_asm(t=0) { cup_frame(); translate(Pv) rotate([0,t,0]) translate(-Pv) cup_floor(); horn_pin_part(t);
    color("silver") translate(Pv) rotate([90,0,0]) cylinder(d=3, h=25.2, center=true, $fn=12); }
module cup() cup_asm(0);
module cup_tipped(a) translate(E(a)) cup_asm(cup_tilt(a));
function ball_top_seat(a) = E(a) + about_pv(cup_seat, cup_tilt(a));   // ball on the floor at lever angle a (before it rolls)
function ball_top_end(a)  = E(a) + about_pv(cup_end, cup_tilt(a));    // ball at the open end of the turned floor
module wheel() {        // wheel coordinates: axis along Y, wheel disc at y = 0, drum behind it
    difference() {
        union() {
            rotate([90,0,0]) cylinder(r=25, h=5, center=true, $fn=96);
            translate([0,-6.3,0]) rotate([90,0,0]) cylinder(r=10, h=8.2, center=true, $fn=64);    // drum, joined to the disc
            translate([0,-10.4,0]) rotate([90,0,0]) cylinder(r=12.5, h=1.2, center=true, $fn=64); // flange
        }
        rotate([90,0,0]) rotate_extrude($fn=96) translate([25,0]) circle(r=1.1);                 // cord groove on the rim
        translate([0,-6.5,0]) rotate([90,0,0]) rotate_extrude($fn=64) translate([10,0]) circle(r=1.1);
        rotate([90,0,0]) cylinder(d=4.5, h=40, center=true);
        for (y=[2.5+0.01, -11+brg_h-0.01]) translate([0,y,0]) rotate([90,0,0]) brg_pocket();
        for (a=[0,120,240]) rotate([0,a,0]) translate([16,0,0]) rotate([90,0,0]) cylinder(d=1.6, h=8, center=true); // cord tie holes
        for (a=[60,180,300]) rotate([0,a,0]) translate([16,0,0]) rotate([90,0,0]) cylinder(d=10, h=8, center=true); // lighten
    }
}
module idler() {
    difference() {
        rotate([90,0,0]) cylinder(r=6.5, h=4, center=true, $fn=48);
        rotate([90,0,0]) rotate_extrude($fn=48) translate([6.5,0]) circle(r=1.0);
        rotate([90,0,0]) cylinder(d=brg_od, h=10, center=true);
    }
}
// Latch v3 (2026-10-28). v1/v2 had the cup's tail press the paddle, but the tail sat 2 mm from the cup pin, so the
// ball's 6-9 deg tip moved it only 0.3 mm; and the post overlapped the crank. Now the BALL trips the latch on its way
// in: a 3 mm steel trip pin from the crank lies across the ball path just past the end of the feed (0.7 mm into it).
// The ball rolls over it and presses it down; the crank turns, the nose slides off the roller. The roller pushes
// straight up through the crank pivot (no torque), so the trip only has to beat the crank's own balance (nut slot).
// The ball is already dropping into the cup: the cup needs about 0.1 s to move 15 mm, the ball lands in 0.03 s.
trip_d = [-14 - R0[0], 26.2 - H[2]];            // trip pin centre from the crank pivot: 2 mm inside the feed's end, 0.7 mm into the ball path
module crank() {        // crank coordinates: pivot at the origin, axis along Y, part spans y = crank_y0..crank_y1
    t = crank_y1-crank_y0;
    noseZ = (R0[2]+roller_r) - H[2];          // nose underside, above the pivot
    difference() {
        translate([0, crank_y0, 0]) rotate([90,0,0]) mirror([0,0,1]) linear_extrude(t) union() {
            circle(d=9);
            translate([roller_r+0.6, -2]) square([3, noseZ+6]);                    // hook arm, right of the roller
            hull() { translate([-3, noseZ]) square([9.6, 2.5]); translate([-1.5, noseZ+4]) square([8.1, 0.01]); }   // nose: underside on the roller's top; chamfered top (reset: push the lever down, it snaps in)
            hull() { circle(d=6); translate(trip_d) circle(d=6); }                 // trip arm
            translate([-14, -2]) square([14, 4]);                                  // balance arm (nut slot)
        }
        rotate([90,0,0]) cylinder(d=brg_od, h=60, center=true);                    // bearing seat (MR63 on the pin)
        hull() for (x=[-12,-6]) translate([x, (crank_y0+crank_y1)/2, 0]) cylinder(d=m3_clear, h=10, center=true);   // nut slot: slide to trim
        translate([trip_d[0], 0, trip_d[1]]) rotate([90,0,0]) cylinder(d=2.9, h=60, center=true);   // trip pin (press)
    }
}
module trip_pin() color("silver") translate([trip_d[0], (crank_y0-3)/2 + 0.5, trip_d[1]]) rotate([90,0,0]) cylinder(d=3, h=crank_y0+3+1, center=true, $fn=16);   // y -3 .. crank_y0+1
module latch_post() {   // a 3 mm plate beside the crank; (v3) the upright stands 8 mm +x of the pivot (the E1 feed passes left of it), an arm carries the pin
    difference() {
        union() {
            translate([4.2, crank_y1+0.6, 0]) cube([8, 3, H[2]+4]);                      // upright
            translate([-4, crank_y1+0.6, H[2]-4]) cube([16.2, 3, 8]);                    // arm to the crank pin
            translate([4.2, crank_y1+0.6, -4]) cube([8, 3, 4]);                          // tenon (rig base)
            translate([4.2, crank_y1+0.6, 0]) cube([8, 8, 4]);                           // foot
        }
        translate([0, 10, H[2]]) rotate([-90,0,0]) cylinder(d=pin_hole-0.15, h=20);
    }
}
// feed track risers: hold two 3 mm rods (gap 12) sloping 2.5 deg down toward the cup
feed_end_x = -12;  feed_z_end = E0z - 17.5;               // ball centre at the end of the feed (v3: 1.1 mm over the cup's entry lip)
function feed_z(x) = feed_z_end + (feed_end_x - x)*tan(2.5);
module feed_riser(x) {
    cc = rod_cc(12); dz = rod_drop(12);
    difference() {
        translate([x-6, -cc/2-6, 0]) cube([12, cc+12, feed_z(x)-dz]);
        for (s=[-1,1]) translate([x, s*cc/2, feed_z(x)-dz]) rotate([0,90,0]) cylinder(d=rod_hole, h=20, center=true);
        // ball path
        translate([x, 0, feed_z(x)]) rotate([0,90,0]) cylinder(r=ball_r+0.6, h=20, center=true);
    }
}
post_x = 40; post_y = -25;
module post(z0, z1) {
    difference() {
        translate([post_x-8, post_y-8, z0]) cube([16,16,z1-z0]);
        if (z0>0) translate([post_x-4.2, post_y-4.2, z0-0.01]) cube([8.4,8.4,30]);    // socket for the lower section's tenon
        translate([post_x, post_y, z0-1]) cylinder(d=m3_clear, h=12);
    }
    if (z0==0) translate([post_x-4, post_y-4, z1]) cube([8,8,29.5]);                    // tenon
}
// Rig top v3 (2026-10-28): the same top as the coaster's Elevator 1 (v1/v2 rig: a fixed tray and a pour finger that
// the rising cup and lever both hit). Relative to the cup pin at the top, T = E(SW):
//  - tip cam on the post (the horn pin runs under it, the cup tips 28 deg),
//  - catch flap hinged at its far edge (+y), lifted by the rising cup, falls back under it,
//  - short trough tray along +y then +x to a foam end stop (the ball waits there: pick it up, run again).
T = E(SW);
rF = [T[2]-37.15, -9, -tan(5.3), 7.2, -tan(1)];                        // flap top: z at (x, y) as in the coaster (rel. x, y)
function rflapz(x, y) = rF[0] + (y - rF[1])*rF[2] + (x - rF[3])*rF[4];
rtray = [[18.2, 25.5, T[2]-30.35], [18.2, 38, T[2]-30.95], [45, 38, T[2]-32.1]];   // trough axis points
module rig_flap() color("#e0a040") {
    hull() for (x=[7.2, 28.2], y=[-9, 25]) translate([x, y, rflapz(x, y) - 2]) cube([0.01, 0.01, 2]);
    color("silver") translate([7.2, 23, rflapz(7.2, 23) - 3]) rotate([0,90,0]) cylinder(d=2, h=21, $fn=10);   // hinge pin
}
rcY = [-16.4, -13.3];                                                // cam band (the horn pin is out at |y| 12.6..16.6)
function rcam() = [for (a=[SW-tip_span-1.0 : 0.25 : SW]) let(lead = a < SW-tip_span ? (SW-tip_span-a)*2.0 : 0) horn_pin(a) + [0,0,1.8+lead]];
function rpin() = [for (a=[SW-tip_span-1.5 : 0.1 : SW+0.2]) horn_pin(min(a, SW))];
module rig_cam() color("#e0a040") difference() {
    c = rcam();
    union() {
        for (k=[0:len(c)-2]) hull() for (q=[c[k], c[k+1]]) translate([q[0]-0.25, rcY[0], q[2]-1.3]) cube([0.5, rcY[1]-rcY[0], 6.3]);
        hull() for (q=[c[0], c[len(c)-1]]) translate([q[0]-0.25, rcY[0]-0.61, q[2]+5]) cube([0.5, rcY[1]-rcY[0]+0.61, 2]);   // flange, glued to the post's face
        for (q=c) if (q[0] > post_x-8 && q[0] < post_x+8) translate([q[0]-0.25, post_y+8, q[2]-1.3]) cube([0.5, rcY[0]-post_y-8+0.01, 8.3]);   // web to the post
    }
    p = rpin(); for (k=[0:len(p)-2]) hull() for (q=[p[k], p[k+1]]) translate([q[0], rcY[0]-1, q[2]]) rotate([-90,0,0]) cylinder(r=1.9, h=rcY[1]-rcY[0]+2, $fn=20);
}
module rig_top_post() color("#4a5360") difference() {                // holds the flap hinge and the tray (on the base, +y side)
    hz = rflapz(7.2, 23) - 3;                                          // hinge pin height
    union() {
        translate([4, 26, 0]) cube([45, 9, rtray[1][2] - 8]);
        for (x=[4, 28.4]) translate([x, 20.5, 0]) cube([1.8, 5.5, hz + 3]);                       // hinge cheeks (outside the flap)
    }
    translate([2, 23, hz]) rotate([0,90,0]) cylinder(d=2.2, h=40, $fn=12);
    for (k=[0:len(rtray)-2]) hull() for (q=[rtray[k], rtray[k+1]]) translate(q) sphere(r=ball_r+0.8+2.4+0.2, $fn=24);   // the tray sits in it
    hull() for (x=[7.0, 28.4], y=[-9, 26]) translate([x, y, rflapz(x, y) - 2.5]) cube([0.01, 0.01, 40]);                 // the flap swings up here
}
module rig_tray() color("#d08a4a") trough_chain(rtray, open_start=true, pads=[1]);
module rig_top() { rig_flap(); rig_cam(); rig_top_post(); rig_tray(); }
module cw_pot() {       // open pot for about 560 g of steel nuts (or lead / tungsten shot); bail across the top for the cord
    difference() {
        union() {
            difference() { cylinder(d=40, h=110, $fn=64); translate([0,0,2]) cylinder(d=36, h=120, $fn=64); }
            translate([-20,-3,104]) cube([40,6,6]);                                             // bail
        }
        translate([0,0,107]) rotate([90,0,0]) cylinder(d=3, h=20, center=true);               // cord hole in the bail
    }
}
module spacers() { for (i=[0:5]) translate([i*10,0,0]) difference() { cylinder(d=7, h=(i<3?2:4)); translate([0,0,-1]) cylinder(d=3.4, h=6); } }

// ---------------- assembly ----------------
module at(p) translate(p) children();
module asm(a=show_angle) {
    color("#4a5360") base_half("a"); color("#56606c") base_half("b");
    color("#59646f") plate();
    color("#59646f") for (x=[-235,-175,-115]) translate([x, plate_y1, 0]) rotate([90,0,90]) gusset();
    // lever
    color("#59a5c4") at(P) rotate([0,-a,0]) rotate([90,0,0]) lever();
    // cup hangs level from the pin (the ball tips it about 9 deg; shown level)
    color("#59a5c4") cup_tipped(a);
    color("silver") at(ball_top_seat(a)) sphere(r=ball_r, $fn=32);
    // roller
    let(r=[P[0]+R_local*cos(a), 0, P[2]+R_local*sin(a)]) color("silver") at([r[0], roller_y, r[2]]) rotate([90,0,0]) cylinder(r=roller_r, h=2.5, center=true);
    color("#d08a4a") at([W[0],0,W[2]]) wheel();
    color("#d08a4a") at(I) idler();
    color("#d08a4a") at(H) { crank(); trip_pin(); }
    color("#4a5360") at([H[0],0,0]) latch_post();
    color("#4a5360") { at([0,0,0]) feed_riser(-130); feed_riser(-40); }
    color("silver") for (s=[-1,1]) hull() for (x=[-140, feed_end_x]) translate([x, s*rod_cc(12)/2, feed_z(x)-rod_drop(12)]) sphere(d=rod_d, $fn=12);
    color("#4a5360") { post(0, 195); post(195, 390); }
    rig_top();
    // counterweight: falls cw_drop while the lever goes from -52.2 to +52.2
    f = (sin(a)+sn)/(2*sn);
    color("#9aa3ad") at([I[0]-6.5, -6.5, I[2]-30-122-f*cw_drop]) cw_pot();   // (pot centre is 6.5 mm left of the idler)
    // cords
    s = S(a);
    color("white") { hull() { at([W[0]+25,0,W[2]]) sphere(0.5); at(s) sphere(0.5); }
                     hull() { at([W[0]-10,-6.5,W[2]]) sphere(0.5); at([I[0]+6.5,-6.5,I[2]]) sphere(0.5); }
                     hull() { at([I[0]-6.5,-6.5,I[2]]) sphere(0.5); at([I[0]-6.5,-6.5,I[2]-30-f*cw_drop]) sphere(0.5); } }
}

if (part=="assembly") asm();
// print orientations (flat side down)
module onbed(z) translate([0,0,-z]) children();
if (part=="base")          base();
if (part=="base_a")        onbed(-6) base_half("a");
if (part=="base_b")        translate([0,0,6]) base_half("b");
if (part=="plate")         rotate([90,0,0]) translate([0,-plate_y0,0]) plate();
if (part=="gusset")        gusset();
if (part=="lever")         onbed(-4) lever();
if (part=="cup")           translate([0,0,12.6]) rotate([90,0,0]) cup();   // on its -y side plate; tree supports under the +y plate
if (part=="wheel")         onbed(-11) rotate([90,0,0]) wheel();
if (part=="idler")         onbed(-2) rotate([90,0,0]) idler();
if (part=="crank")         onbed(-4) rotate([-90,0,0]) translate([0,-crank_y0,0]) crank();   // + 3 mm steel trip pin, 17 mm
if (part=="latch_post")    rotate([0,90,0]) translate([0,0,-H[2]-5]) latch_post();   // lying down
if (part=="feed_riser_hi") feed_riser(-130);
if (part=="feed_riser_lo") feed_riser(-40);
if (part=="post_lower")    translate([0,0,8-post_y]) rotate([0,90,0]) translate([-post_x,0,0]) post(0,195);   // lying down
if (part=="post_upper")    translate([0,0,8-post_y]) rotate([0,90,0]) translate([-post_x,0,0]) post(195,390);
if (part=="rig_flap")      rig_flap();
if (part=="rig_cam")       rig_cam();
if (part=="rig_top_post")  rig_top_post();
if (part=="rig_tray")      rig_tray();
if (part=="cw_pot")        cw_pot();
if (part=="spacers")       spacers();
echo(str("pivot ", P, "  wheel ", W, "  idler ", I, "  roller at rest ", R0, "  cw drop ", cw_drop, "  top pin ", T));
