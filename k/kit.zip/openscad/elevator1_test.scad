// TEST 3: Elevator 1 (Type 1: first-class lever + wheel and axle) at R3 size, with the ball-triggered latch.
// Simulator numbers: ball arm 205 mm, effort arm 50 mm, swing +/-52.2 deg, lift 324 mm, IMA = 50/205 * 10/25 = 0.098,
// counterweight about 556 g (falls 32 mm).
// Axes: X right, Z up, the lever swings in the plane Y = 0. The tower plate stands behind it (Y = -20..-12).
//
// How the latch works: a hook holds a ball-bearing roller on the lever, so the lever cannot rise.
// The cup hangs free on a pin. When the ball lands in it, the ball's weight tips the cup about 9 deg,
// and a tail on the cup presses the hook's paddle. The hook swings off the roller and the counterweight
// lifts the ball. At the top a stop finger tips the cup and the ball rolls out onto the top tray.
include <common.scad>

part = "assembly";   // assembly | base | plate | gusset | lever | cup | wheel | idler | crank | latch_post |
                     // feed_riser_hi | feed_riser_lo | post_lower | post_upper | tray_bracket | cw_pot | spacers
show_angle = -52.2;  // lever angle in the assembly view (-52.2 = waiting for the ball, +52.2 = top)

A   = 205;  LS = 50;  SW = 52.2;
cs = cos(SW); sn = sin(SW);
E0z = 54;                                   // cup pin height at the bottom
P   = [-A*cs, 0, E0z + A*sn];               // lever pivot (-125.6, 0, 216)
function E(a)  = [P[0]+A*cos(a), 0, P[2]+A*sin(a)];      // cup pin
function S(a)  = [P[0]-LS*cos(a), 0, P[2]-LS*sin(a)];    // effort-arm end (cord)
S1  = S(SW);
W   = [S1[0]-25, 0, S1[2]-35];              // wheel centre (wheel R 25, drum r 10)
cw_drop = 2*A*sn * (LS/A) * (10/25);        // 31.6 mm
I   = [W[0]-41.5, -6.5, W[2]+32+cw_drop+35];  // idler (r 6.5): far enough out that the pot hangs clear of the wheel
cup_drop = 22;                              // ball centre below the cup pin (2026-10-27: was 14; the ball entering from
                                            // the feed hit the lever's pin boss; 22 leaves 3.6 mm under the boss)
R_local = 185;                              // roller pin position along the lever
R0  = [P[0]+R_local*cos(-SW), 0, P[2]+R_local*sin(-SW)]; // roller at rest (-12.2, 0, 69.8)
roller_r = 3; roller_y = 15.25;             // MR63 used as a roller, centre plane y = 15.25
crank_y0 = 13; crank_y1 = 17;
H   = [R0[0], 0, 46];                       // crank pivot (directly under the roller: the roller force makes no torque)
plate_y0 = -20; plate_y1 = -12;
base_x0 = -262; base_x1 = 50; base_split = -100;

// ---------------- parts ----------------
module base() {
    difference() {
        translate([base_x0, -40, -6]) cube([base_x1-base_x0, 75, 6]);
        translate([-240, plate_y0-0.2, -4]) cube([120, plate_y1-plate_y0+0.4, 5]);          // plate slot
        for (x=[-230,-190,-140]) translate([x, (plate_y0+plate_y1)/2, -7]) cylinder(d=m3_clear, h=8);
        for (y=[-30, 25]) translate([base_split, y, -7]) cylinder(d=m3_clear, h=8);           // half-lap bolts
        translate([40-8.2, -33.2, -4]) cube([16.4,16.4,5]);                                 // post socket
        translate([40, -25, -7]) cylinder(d=m3_clear, h=8);
        translate([R0[0]-4.2, 13.8, -4]) cube([8.4,8.4,5]);                                  // latch post socket
        for (x=[-140, -40]) translate([x, 0, -4]) cube([20.4, 30.4, 5], center=false);        // feed riser pads (marks)
        translate([-60, -30, -0.6]) linear_extrude(1) text("ELEVATOR 1 TEST", size=6);
    }
}
module base_half(which) {
    lap = 10;
    intersection() {
        base();
        if (which=="a") union() { translate([base_x0-1,-50,-10]) cube([base_split-lap/2-base_x0+1, 100, 20]);
                                   translate([base_split-lap/2-0.01,-50,-10]) cube([lap, 100, 7]); }
        else            union() { translate([base_split+lap/2,-50,-10]) cube([base_x1-base_split, 100, 20]);
                                   translate([base_split-lap/2,-50,-3]) cube([lap+0.01, 100, 10]); }
    }
}
module plate() {
    difference() {
        union() {
            translate([-240, plate_y0, 0]) cube([130, plate_y1-plate_y0, 252]);
            translate([-240, plate_y0, -4]) cube([120, plate_y1-plate_y0, 4]);              // tab into the base slot
            // stop block for the effort arm at the top position (lever angle +52.2)
            translate([S1[0]-6, plate_y1, S1[2]-6-4]) cube([12, 14, 4]);
        }
        for (p=[P, W, I]) translate([p[0], plate_y0-1, p[2]]) rotate([-90,0,0]) cylinder(d=pin_hole-0.15, h=20);
        for (x=[-230,-190,-140]) translate([x, (plate_y0+plate_y1)/2, -5]) cylinder(d=m3_clear, h=12);
        // lighten
        translate([-185, plate_y0-1, 30]) cube([45, 10, 70]);
        translate([-232, plate_y0-1, 30]) cube([30, 10, 120]);
        translate([-140, plate_y0-1, 150]) rotate([-90,0,0]) cylinder(r=12, h=10);
    }
}
module gusset() { difference() { linear_extrude(6) polygon([[0,0],[40,0],[0,60]]); translate([12,0,3]) rotate([-90,0,0]) cylinder(d=m3_clear,h=40,center=true); } }

module lever() {        // in lever coordinates: pivot at the origin, ball arm along +X
    difference() {
        union() {
            hull() { cylinder(d=18, h=8, center=true); translate([-LS,0,0]) cylinder(d=9, h=6, center=true); }
            hull() { cylinder(d=14, h=6, center=true); translate([A-6,0,0]) cylinder(d=9, h=6, center=true); }
            translate([A,0,0]) cylinder(d=9, h=5.6, center=true);                         // tongue between the cup ears
            translate([R_local,0,0]) cylinder(d=9, h=6, center=true);
        }
        cylinder(d=4.5, h=20, center=true);
        for (z=[-4.01, 4.01-brg_h]) translate([0,0,z]) brg_pocket();                       // two MR63 bearings
        translate([-LS+2.5,0,0]) cylinder(d=2.2, h=20, center=true);                       // cord hole
        translate([A,0,0]) cylinder(d=pin_hole+0.3, h=20, center=true);                    // cup pin: loose (cup turns on it)
        translate([R_local,0,0]) cylinder(d=pin_hole-0.15, h=20, center=true);             // roller pin: press fit
        translate([60,0,2.4]) linear_extrude(1) text("E1 LEVER", size=4.5, valign="center");
    }
}
module cup() {          // cup coordinates: pin along Y at the origin, cup hangs down -Z
    seat = [3, 0, -cup_drop];
    rim = -cup_drop + 3.5;
    difference() {
        union() {
            translate(seat) sphere(r=ball_r+0.7+2, $fn=48);
            for (s=[-1,1]) hull() { translate([0, s*4.3, 0]) rotate([90,0,0]) cylinder(d=9, h=2.4, center=true);
                                    translate([seat[0], s*4.3, rim-1]) cube([14, 2.4, 2], center=true); }
            // tail that presses the latch paddle (out at y = 13..17)
            hull() { translate([seat[0]-1, 9, -6]) cube([5,3,5], center=true); translate([seat[0]-1, 15, -6.5]) cube([5,4,4], center=true); }
            translate([seat[0]-1, 6, -6]) cube([5,8,5], center=true);
            // small weight lug on the -x side, keeps the empty cup level (2026-10-27: moved under the entry slot)
            translate([seat[0]-10.5, 0, seat[2]-8]) cube([5, 8, 4], center=true);
        }
        translate(seat) sphere(r=ball_r+0.7, $fn=48);
        translate([-30,-30,rim]) cube([60,60,40]);                                         // open top
        translate([seat[0]+5, -30, rim-3.2]) rotate([0,-25,0]) cube([30,60,30]);           // low lip on +x: the ball pours out here
        translate([0,0,0]) rotate([90,0,0]) cylinder(d=pin_hole, h=30, center=true);
        translate([seat[0]-10.5,0,seat[2]-8]) cylinder(d=m3_nut, h=2.6, center=true, $fn=6);   // nut pocket to trim the balance
        // (2026-10-27) entry slot on the -x side. The feed brings the ball in 4.5 mm above the seat, but the rim is
        // 3.5 mm above the seat, so the ball's lower half met the wall. The slot floor 5.5 mm below the seat makes the
        // lip edge 4.0 mm under the incoming ball's path; to roll back out the ball would have to climb 4 mm.
        translate([seat[0]-30, -10.5, seat[2]-5.5]) cube([26, 21, rim - seat[2] + 7]);
    }
}
module wheel() {        // wheel coordinates: axis along Y, wheel disc at y = 0, drum behind it
    difference() {
        union() {
            rotate([90,0,0]) cylinder(r=25, h=5, center=true, $fn=96);
            translate([0,-6.3,0]) rotate([90,0,0]) cylinder(r=10, h=8.2, center=true, $fn=64);    // drum, joined to the disc
            translate([0,-10.4,0]) rotate([90,0,0]) cylinder(r=12.5, h=1.2, center=true, $fn=64); // flange
        }
        rotate([90,0,0]) rotate_extrude($fn=96) translate([25,0]) circle(r=1.1);                 // cord groove on the rim
        translate([0,-6.5,0]) rotate([90,0,0]) rotate_extrude($fn=64) translate([10,0]) circle(r=1.1);
        rotate([90,0,0]) cylinder(d=4.5, h=40, center=true);
        for (y=[2.5+0.01, -11+brg_h-0.01]) translate([0,y,0]) rotate([90,0,0]) brg_pocket();
        for (a=[0,120,240]) rotate([0,a,0]) translate([16,0,0]) rotate([90,0,0]) cylinder(d=1.6, h=8, center=true); // cord tie holes
        for (a=[60,180,300]) rotate([0,a,0]) translate([16,0,0]) rotate([90,0,0]) cylinder(d=10, h=8, center=true); // lighten
    }
}
module idler() {
    difference() {
        rotate([90,0,0]) cylinder(r=6.5, h=4, center=true, $fn=48);
        rotate([90,0,0]) rotate_extrude($fn=48) translate([6.5,0]) circle(r=1.0);
        rotate([90,0,0]) cylinder(d=brg_od, h=10, center=true);
    }
}
module crank() {        // crank coordinates: pivot at the origin, axis along Y, part spans y = crank_y0..crank_y1
    t = crank_y1-crank_y0;
    noseZ = (R0[2]+roller_r) - H[2];          // nose underside, above the pivot
    difference() {
        translate([0, crank_y0, 0]) rotate([90,0,0]) mirror([0,0,1]) linear_extrude(t) union() {
            circle(d=9);
            translate([2, -2]) square([4, noseZ+8]);                               // hook arm, beside the roller
            translate([-5.2, noseZ]) square([11.2, 4]);                            // nose over the roller
            translate([0,-2]) square([16.5, 4]);                                   // paddle arm under the cup tail
            translate([13, -2]) square([4, 4.5]);
            translate([-14, -2]) square([14, 4]);                                  // balance arm (nut slot)
        }
        rotate([90,0,0]) cylinder(d=brg_od, h=60, center=true);                    // bearing seat (MR63 on the pin)
        hull() for (x=[-12,-6]) translate([x, (crank_y0+crank_y1)/2, 0]) cylinder(d=m3_clear, h=10, center=true);   // nut slot: slide to trim
    }
}
module latch_post() {
    difference() {
        union() { translate([-4, 13.9, 0]) cube([8, 8, H[2]+5]); translate([-4,13.9,-4]) cube([8,8,4]); }
        translate([0, 10, H[2]]) rotate([-90,0,0]) cylinder(d=pin_hole-0.15, h=20);
    }
}
// feed track risers: hold two 3 mm rods (gap 12) sloping 2.5 deg down toward the cup
feed_end_x = -12;  feed_z_end = E0z - cup_drop + 4.5;      // ball centre at the end of the feed (4.5 mm above the cup seat)
function feed_z(x) = feed_z_end + (feed_end_x - x)*tan(2.5);
module feed_riser(x) {
    cc = rod_cc(12); dz = rod_drop(12);
    difference() {
        translate([x-6, -cc/2-6, 0]) cube([12, cc+12, feed_z(x)-dz]);
        for (s=[-1,1]) translate([x, s*cc/2, feed_z(x)-dz]) rotate([0,90,0]) cylinder(d=rod_hole, h=20, center=true);
        // ball path
        translate([x, 0, feed_z(x)]) rotate([0,90,0]) cylinder(r=ball_r+0.6, h=20, center=true);
    }
}
post_x = 40; post_y = -25;
module post(z0, z1) {
    difference() {
        translate([post_x-8, post_y-8, z0]) cube([16,16,z1-z0]);
        if (z0>0) translate([post_x-4.2, post_y-4.2, z0-0.01]) cube([8.4,8.4,30]);    // socket for the lower section's tenon
        translate([post_x, post_y, z0-1]) cylinder(d=m3_clear, h=12);
    }
    if (z0==0) translate([post_x-4, post_y-4, z1]) cube([8,8,29.5]);                    // tenon
}
// top tray: rods from x = tx0 to tx0+88, ball centre about 362 at the start, sloping down 2.5 deg.
// The cup reaches x = 15 at the top, so the tray starts just past its lip.
tray_z0 = E(SW)[2] - cup_drop - 2;
tx0 = 17;
function tz(x) = tray_z0 - (x-tx0)*tan(2.5);
module tray_bracket() {
    cc = rod_cc(12); dz = rod_drop(12); hx = [tx0+5, tx0+53];
    difference() {
        union() {
            translate([post_x-8, post_y-8, tz(hx[0])-dz-14]) cube([16, 34, 10]);                 // arm from the post to the rails
            for (x=hx) translate([x-5, -cc/2-5, tz(x)-dz-14]) cube([10, cc+10, 14]);
            translate([hx[0]-5, -cc/2-5, tz(hx[0])-dz-14]) cube([hx[1]-hx[0]+5, 4, 6]);
            // pour finger: column outside the ball path, beam above it, finger down to just above the cup's +x rim
            translate([hx[0]-5, -cc/2-5, tz(hx[0])-dz-14]) cube([4, 4, 38]);
            translate([7, -cc/2-5, tz(hx[0])-dz+20]) cube([hx[0]-5-7+4, 4, 4]);
            translate([7, -cc/2-5, tz(hx[0])-dz+20]) cube([4, cc/2+8, 4]);
            translate([7, -1, E(SW)[2]-cup_drop+5]) cube([4, 4, tz(hx[0])-dz+24-(E(SW)[2]-cup_drop+5)]);
        }
        for (x=hx, s=[-1,1]) translate([x, s*cc/2, tz(x)-dz]) rotate([0,90-2.5,0]) cylinder(d=rod_hole, h=30, center=true);
        for (x=hx) translate([x, 0, tz(x)]) rotate([0,90,0]) cylinder(r=ball_r+0.6, h=12, center=true);
        translate([post_x-8.1, post_y-8.1, 0]) cube([16.2, 16.2, 500]);                         // clamps around the post
    }
}
module cw_pot() {       // open pot for about 560 g of steel nuts (or lead / tungsten shot); bail across the top for the cord
    difference() {
        union() {
            difference() { cylinder(d=40, h=110, $fn=64); translate([0,0,2]) cylinder(d=36, h=120, $fn=64); }
            translate([-20,-3,104]) cube([40,6,6]);                                             // bail
        }
        translate([0,0,107]) rotate([90,0,0]) cylinder(d=3, h=20, center=true);               // cord hole in the bail
    }
}
module spacers() { for (i=[0:5]) translate([i*10,0,0]) difference() { cylinder(d=7, h=(i<3?2:4)); translate([0,0,-1]) cylinder(d=3.4, h=6); } }

// ---------------- assembly ----------------
module at(p) translate(p) children();
module asm(a=show_angle) {
    color("#4a5360") base_half("a"); color("#56606c") base_half("b");
    color("#59646f") plate();
    color("#59646f") for (x=[-235,-175,-115]) translate([x, plate_y1, 0]) rotate([90,0,90]) gusset();
    // lever
    color("#59a5c4") at(P) rotate([0,-a,0]) rotate([90,0,0]) lever();
    // cup hangs level from the pin (the ball tips it about 9 deg; shown level)
    color("#59a5c4") at(E(a)) cup();
    color("silver") at([E(a)[0]+3, 0, E(a)[2]-cup_drop]) sphere(r=ball_r, $fn=32);
    // roller
    let(r=[P[0]+R_local*cos(a), 0, P[2]+R_local*sin(a)]) color("silver") at([r[0], roller_y, r[2]]) rotate([90,0,0]) cylinder(r=roller_r, h=2.5, center=true);
    color("#d08a4a") at([W[0],0,W[2]]) wheel();
    color("#d08a4a") at(I) idler();
    color("#d08a4a") at(H) crank();
    color("#4a5360") at([H[0],0,0]) latch_post();
    color("#4a5360") { at([0,0,0]) feed_riser(-130); feed_riser(-40); }
    color("silver") for (s=[-1,1]) hull() for (x=[-140, feed_end_x]) translate([x, s*rod_cc(12)/2, feed_z(x)-rod_drop(12)]) sphere(d=rod_d, $fn=12);
    color("#4a5360") { post(0, 195); post(195, 390); }
    color("#d08a4a") tray_bracket();
    color("silver") for (s=[-1,1]) hull() for (x=[tx0, tx0+88]) translate([x, s*rod_cc(12)/2, tz(x)-rod_drop(12)]) sphere(d=rod_d, $fn=12);
    // counterweight: falls cw_drop while the lever goes from -52.2 to +52.2
    f = (sin(a)+sn)/(2*sn);
    color("#9aa3ad") at([I[0]-6.5, -6.5, I[2]-30-122-f*cw_drop]) cw_pot();   // (pot centre is 6.5 mm left of the idler)
    // cords
    s = S(a);
    color("white") { hull() { at([W[0]+25,0,W[2]]) sphere(0.5); at(s) sphere(0.5); }
                     hull() { at([W[0]-10,-6.5,W[2]]) sphere(0.5); at([I[0]+6.5,-6.5,I[2]]) sphere(0.5); }
                     hull() { at([I[0]-6.5,-6.5,I[2]]) sphere(0.5); at([I[0]-6.5,-6.5,I[2]-30-f*cw_drop]) sphere(0.5); } }
}

if (part=="assembly") asm();
// print orientations (flat side down)
module onbed(z) translate([0,0,-z]) children();
if (part=="base")          base();
if (part=="base_a")        onbed(-6) base_half("a");
if (part=="base_b")        translate([0,0,6]) base_half("b");
if (part=="plate")         rotate([90,0,0]) translate([0,-plate_y0,0]) plate();
if (part=="gusset")        gusset();
if (part=="lever")         onbed(-4) lever();
if (part=="cup")           onbed(10.5) rotate([180,0,0]) cup();
if (part=="wheel")         onbed(-11) rotate([90,0,0]) wheel();
if (part=="idler")         onbed(-2) rotate([90,0,0]) idler();
if (part=="crank")         onbed(-4) rotate([-90,0,0]) translate([0,-crank_y0,0]) crank();
if (part=="latch_post")    rotate([0,90,0]) translate([0,0,-H[2]-5]) latch_post();   // lying down
if (part=="feed_riser_hi") feed_riser(-130);
if (part=="feed_riser_lo") feed_riser(-40);
if (part=="post_lower")    translate([0,0,8-post_y]) rotate([0,90,0]) translate([-post_x,0,0]) post(0,195);   // lying down
if (part=="post_upper")    translate([0,0,8-post_y]) rotate([0,90,0]) translate([-post_x,0,0]) post(195,390);
if (part=="tray_bracket")  onbed(tz(tx0+53)-rod_drop(12)-14) tray_bracket();
if (part=="cw_pot")        cw_pot();
if (part=="spacers")       spacers();
echo(str("pivot ", P, "  wheel ", W, "  idler ", I, "  roller at rest ", R0, "  cw drop ", cw_drop, "  top tray z ", tray_z0));
