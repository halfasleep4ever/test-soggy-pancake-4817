// v1.7 FEA (elevators): one E2 part in an FEA pose = its PRINT rotation (Z = layer direction, as E2_print), in WORLD
// coordinates where it matters (no turn about Z, no shift on the bed).
//   e2_tower     : print flat on its back face -> FEA (X, Y, Z) = (Xw, -Zw, Yw)
//   e2_latch_post: print on its +x face        -> FEA (X, Y, Z) = (Zw, Yw, -Xw)
//   other keys: the E2_print pose (local part coordinates)
include <coaster_e2.scad>
part = "none"; part2 = "none";
fk = "e2_tower";
module wld() translate(E2_ORIGIN) children();
if (fk=="e2_tower")      rotate([90,0,0]) wld() E2_tower();
if (fk=="e2_latch_post") rotate([0,90,0]) wld() latch_post_v1();
if (fk!="e2_tower" && fk!="e2_latch_post") E2_print(fk);
if (fk=="e2_cup_frame_pin") translate([0,0,4.5]) rotate([180,0,0]) { cup_frame(); translate(Pv) rotate([90,0,0]) cylinder(d=3.15, h=25.2, center=true, $fn=24); }
