// TEST 4: Elevator 2 (Type 2: second-class lever + pulley) at R3 size, same ball-triggered latch as Elevator 1.
// Simulator numbers: fulcrum at one end, cup 195 mm out, rope 215 mm out (lever IMA 215/195 = 1.10),
// reversed movable pulley (IMA 0.5) -> total 0.55. Swing +/-53.1 deg, ball lift 312 mm, counterweight about 99 g
// (it falls about 172 mm). Reuses the cup, latch crank, latch post, feed risers, post and top tray of elevator1_test.scad.
// Rope: lever end -> up over fixed pulley P1 -> across to fixed pulley P3 -> down around the moving pulley P2
// (counterweight hangs on it) -> up to the anchor. P2 runs beyond the end of the top tray.
include <elevator1_test.scad>

part2 = "assembly";   // assembly | base_a | base_b | tower | lever | pulley | p2_block | top_beam | cw_pot2
show2 = -53.1;
part = "none";        // switch off elevator1's own output

// override the shared geometry (OpenSCAD: the last assignment wins, so elevator1's modules use these)
A  = 195;  SW = 53.1;  R_local = (A*cos(SW) - 12.258) / cos(SW);   // roller lands where elevator1's crank expects it
EF = 215;                                                          // rope point along the lever
F  = P;                                                            // fulcrum (-117.1, 0, 210)
function EN(a) = [F[0]+EF*cos(a), 0, F[2]+EF*sin(a)];
P1 = [EN(SW)[0]+9, 0, EN(SW)[2]+25];          // fixed pulley above the rope point's top position (r 9)
P3 = [P1[0]+118, 0, P1[2]];                    // second fixed pulley
rise = EN(SW)[2]-EN(-SW)[2];                   // 344 mm
P2top = P1[2]-30;                              // moving pulley at the start (high)
anchorX = P3[0]+18;
b2_x0 = -140; b2_x1 = 160; b2_split = 10;

module base2() {
    difference() {
        translate([b2_x0, -40, -6]) cube([b2_x1-b2_x0, 75, 6]);
        translate([F[0]-20, plate_y0-0.2, -4]) cube([40, plate_y1-plate_y0+0.4, 5]);
        for (x=[F[0]-12, F[0]+12]) translate([x, (plate_y0+plate_y1)/2, -7]) cylinder(d=m3_clear, h=8);
        translate([post_x-8.2, -33.2, -4]) cube([16.4,16.4,5]);  translate([post_x, -25, -7]) cylinder(d=m3_clear, h=8);
        translate([140-8.2, -33.2, -4]) cube([16.4,16.4,5]);     translate([140, -25, -7]) cylinder(d=m3_clear, h=8);
        translate([R0[0]-4.2, 13.8, -4]) cube([8.4,8.4,5]);
        for (y=[-30, 25]) translate([b2_split, y, -7]) cylinder(d=m3_clear, h=8);
        translate([-120, -30, -0.6]) linear_extrude(1) text("ELEVATOR 2 TEST", size=6);
    }
}
module base2_half(which) {
    lap = 10;
    intersection() {
        base2();
        if (which=="a") union() { translate([b2_x0-1,-50,-10]) cube([b2_split-lap/2-b2_x0+1,100,20]); translate([b2_split-lap/2-0.01,-50,-10]) cube([lap,100,7]); }
        else            union() { translate([b2_split+lap/2,-50,-10]) cube([b2_x1-b2_split,100,20]);   translate([b2_split-lap/2,-50,-3]) cube([lap+0.01,100,10]); }
    }
}
module tower() {        // fulcrum tower, behind the lever
    difference() {
        union() {
            translate([F[0]-20, plate_y0, 0]) cube([40, plate_y1-plate_y0, F[2]+14]);
            translate([F[0]-20, plate_y0, -4]) cube([40, plate_y1-plate_y0, 4]);
        }
        translate([F[0], plate_y0-1, F[2]]) rotate([-90,0,0]) cylinder(d=pin_hole-0.15, h=20);
        for (x=[F[0]-12, F[0]+12]) translate([x, (plate_y0+plate_y1)/2, -5]) cylinder(d=m3_clear, h=12);
        translate([F[0]-10, plate_y0-1, 40]) cube([20, 10, 120]);
    }
}
module lever2() {       // lever coordinates: fulcrum at the origin, arm along +X
    difference() {
        union() {
            cylinder(d=18, h=8, center=true);
            hull() { cylinder(d=14, h=5.8, center=true); translate([EF,0,0]) cylinder(d=9, h=5.8, center=true); }   // 5.8 thick: passes between the cup ears
            translate([R_local,0,0]) cylinder(d=9, h=6, center=true);
        }
        cylinder(d=4.5, h=20, center=true);
        for (z=[-4.01, 4.01-brg_h]) translate([0,0,z]) brg_pocket();
        translate([A,0,0]) cylinder(d=pin_hole+0.3, h=20, center=true);          // cup pin (loose)
        translate([R_local,0,0]) cylinder(d=pin_hole-0.15, h=20, center=true);  // roller pin (press)
        translate([EF-2.5,0,0]) cylinder(d=2.2, h=20, center=true);             // rope hole
        translate([60,0,2.4]) linear_extrude(1.5) text("E2 LEVER", size=4.5, valign="center");
    }
}
module pulley(r=9) {    // grooved pulley on an MR63 bearing
    difference() {
        rotate([90,0,0]) cylinder(r=r+1.5, h=5, center=true, $fn=64);
        rotate([90,0,0]) rotate_extrude($fn=64) translate([r+1.5,0]) circle(r=1.3);
        rotate([90,0,0]) cylinder(d=brg_od, h=10, center=true);
    }
}
module p2_block() {     // yoke around the moving pulley + hook for the counterweight
    difference() {
        union() {
            for (s=[-1,1]) translate([-6, s*4.6-1.2, -16]) cube([12, 2.4, 20]);
            translate([-6, -5.8, -18]) cube([12, 11.6, 3]);
        }
        rotate([90,0,0]) cylinder(d=pin_hole-0.15, h=20, center=true);
        translate([0,0,-19]) cylinder(d=3, h=6);
    }
}
module top_beam() {     // holds P1 and P3 on pins and the rope anchor; clamps to both posts
    difference() {
        union() {
            translate([P1[0]-10, -5, P1[2]+12]) cube([anchorX-P1[0]+16, 10, 8]);
            for (p=[P1,P3]) translate([p[0]-5, -5, p[2]]) cube([10, 10, 13]);
            translate([anchorX-3, -5, P1[2]+2]) cube([6,10,11]);
            for (x=[post_x, 140]) translate([x-8, -33, P1[2]+12]) cube([16, 30, 8]);
        }
        for (p=[P1,P3]) translate([p[0], 0, p[2]]) { rotate([90,0,0]) cylinder(d=pin_hole-0.15, h=30, center=true); cube([30, 6, 2*11.5], center=true); }
        translate([anchorX, 0, P1[2]+5]) rotate([0,90,0]) cylinder(d=2.2, h=10, center=true);
        for (x=[post_x, 140]) translate([x-8.1, -33.1, 0]) cube([16.2, 16.2, 1000]);
    }
}
module cw_pot2() {      // about 100 g: steel nuts in a small open pot
    difference() { union() { cylinder(d=28, h=45, $fn=48); translate([-14,-2.5,40]) cube([28,5,5]); }
                   translate([0,0,2]) cylinder(d=24.4, h=60, $fn=48); translate([0,0,42.5]) rotate([90,0,0]) cylinder(d=3, h=10, center=true); }
}
module tall_post(x, z0, z1) {
    difference() {
        translate([x-8, post_y-8, z0]) cube([16,16,z1-z0]);
        if (z0>0) translate([x-4.2, post_y-4.2, z0-0.01]) cube([8.4,8.4,30]);
        translate([x, post_y, z0-1]) cylinder(d=m3_clear, h=12);
    }
    if (z0==0) translate([x-4, post_y-4, z1]) cube([8,8,29.5]);
}

module asm2(a=show2) {
    color("#4a5360") base2_half("a"); color("#56606c") base2_half("b");
    color("#59646f") tower();
    color("#59a5c4") translate(F) rotate([0,-a,0]) rotate([90,0,0]) lever2();
    color("#59a5c4") translate(E(a)) cup();
    color("silver") translate([E(a)[0]+3, 0, E(a)[2]-cup_drop]) sphere(r=ball_r, $fn=32);
    let(r=[F[0]+R_local*cos(a), 0, F[2]+R_local*sin(a)]) color("silver") translate([r[0], roller_y, r[2]]) rotate([90,0,0]) cylinder(r=roller_r, h=2.5, center=true);
    color("#d08a4a") translate(H) crank();
    color("#4a5360") translate([H[0],0,0]) latch_post();
    color("#4a5360") { feed_riser(-100); feed_riser(-40); }
    color("silver") for (s=[-1,1]) hull() for (x=[-110, feed_end_x]) translate([x, s*rod_cc(12)/2, feed_z(x)-rod_drop(12)]) sphere(d=rod_d, $fn=12);
    color("#4a5360") { tall_post(post_x,0,215); tall_post(post_x,215,P1[2]+20); tall_post(140,0,215); tall_post(140,215,P1[2]+20); }
    color("#d08a4a") tray_bracket();
    color("silver") for (s=[-1,1]) hull() for (x=[tx0, tx0+88]) translate([x, s*rod_cc(12)/2, tz(x)-rod_drop(12)]) sphere(d=rod_d, $fn=12);
    color("#d08a4a") top_beam();
    color("#d08a4a") for (p=[P1,P3]) translate(p) pulley();
    en = EN(a); up = en[2]-EN(-SW)[2];
    p2 = [P3[0]+9, 0, P2top - up/2];
    color("#d08a4a") translate(p2) { pulley(); p2_block(); }
    color("#9aa3ad") translate([p2[0], 0, p2[2]-18-46]) cw_pot2();
    color("white") {
        hull() { translate(en) sphere(0.5); translate([P1[0]-9,0,P1[2]]) sphere(0.5); }
        hull() { translate([P1[0],0,P1[2]+10.5]) sphere(0.5); translate([P3[0],0,P3[2]+10.5]) sphere(0.5); }
        hull() { translate([P3[0]+9,0,P3[2]]) sphere(0.5); translate([p2[0]-9,0,p2[2]]) sphere(0.5); }
        hull() { translate([p2[0]+9,0,p2[2]]) sphere(0.5); translate([anchorX,0,P1[2]+5]) sphere(0.5); }
    }
}
module onbed2(z) translate([0,0,-z]) children();
if (part2=="assembly") asm2();
if (part2=="base_a")   onbed2(-6) base2_half("a");
if (part2=="base_b")   base2_half("b");
if (part2=="tower")    rotate([90,0,0]) translate([0,-plate_y0,4]) tower();
if (part2=="lever")    onbed2(-4) lever2();
if (part2=="pulley")   onbed2(-2.5) rotate([90,0,0]) pulley();
if (part2=="p2_block") onbed2(-18) p2_block();
if (part2=="top_beam") onbed2(P1[2]) top_beam();
if (part2=="cw_pot2")  cw_pot2();
if (part2=="feed_hi")  feed_riser(-100);
if (part2=="post_lo")  translate([0,0,8-post_y]) rotate([0,90,0]) translate([-140,0,0]) tall_post(140,0,215);
if (part2=="post_hi")  translate([0,0,8-post_y]) rotate([0,90,0]) translate([-140,0,0]) tall_post(140,215,P1[2]+20);
echo(str("E2: fulcrum ", F, "  rope point low/high z ", EN(-SW)[2], " / ", EN(SW)[2], "  P1 ", P1, "  P3 ", P3, "  roller r ", R_local, "  rise ", rise));
