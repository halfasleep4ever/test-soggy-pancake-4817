// v1.7r pictures (docs/coaster_v1.7_rules_fixes.md): pic = "cradle" | "cradle_side" | "ledge" | "gate" | "cupL"
include <coaster_v1.scad>
part = "none"; pic = "cradle";
module ballAt() color("silver") at_loop() at_station(CL_st(), CL_info()[6], CL_info()[3]) translate([0.7-13.025, 0, 0]) sphere(r=ball_r, $fn=64);
if (pic=="cradle" || pic=="cradle_side") {
    intersection() { union() { at_loop() CL_chute(); loop_brackets(); } translate([-30, 100, 190]) cube([90, 70, 80]); }
    color("#e8c547") pencil(0.7, 0, -2, 120);
    ballAt();
}
if (pic=="ledge") { intersection() { tray_e1_a(); translate([250, 105, 355]) cube([40, 35, 30]); } e1_dot(); color("silver", 0.6) translate(E1land) sphere(r=ball_r, $fn=48); }
if (pic=="gate")  { gate(flap=false); gate_flap(0); color("#d47272") gate_bar_v17r(); cord_guides(); color("white") gate_cord(); }
if (pic=="cupL")  { uturn(1); uturn_pad(1); }
