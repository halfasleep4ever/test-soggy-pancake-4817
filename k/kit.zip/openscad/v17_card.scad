// v1.7 timing CARD HOLDER (PETG). Holds the 115 x 72 mm laminated control card (cad/v17_card.py) upright on the
// coaster's X -26 end (START chute end; your RIGHT when standing at the front), card face to -X. World coordinates (same as coaster_v1.scad).
// Position: X -26 .. -6, Y 42 .. 161.5, Z 0 .. 76 (inside the base footprint X -26..300, Y -15..161.5).
//  - From the FRONT the holder is seen edge-on at X -26..-20 (and the foot + gussets X -20..-6 below Z 36): the ball's
//    path never goes there (left ladder channel ball X -17.7..1.3, lowest left hand-over Z 68.7).
//  - Clear of moving parts: Elevator 1's counterweight pot (X -16.5..23.5, Y 78..118, bottom Z 78.4 at its lowest) is
//    above Z 76 and 3.5 mm to the side; the left carriage reaches Y 37.8 (holder starts at Y 42).
//  - Mount: 3 x M3 x 16 countersunk (DIN 7991), from under the base (countersink the base hole), nut in the foot's hex pocket
//    (v1.7t: x 16, one of the 2 stack screw lengths; the tip ends 3.4 mm over the nut, in the open pocket).
//    Base holes (6 mm birch): d 3.4 at world (X -13, Y 52), (X -13, Y 102), (X -13, Y 152), countersunk from below.
// Print pose = as mounted: foot on the bed, no support (all faces vertical or rising), one body, 119.5 x 20 x 76 mm.
// Card slot: 1.2 mm (laminated card <= 1 mm). Side lips hide 3.5 mm of each card edge, the bottom lip 4 mm.
// part = "holder" (print pose = world pose minus the offset) | "placed" (world) | "card" (the card, for pictures)
include <common.scad>         // v1.7t: fit sizes (m3_nut)
part = "placed";
$fn = 32;

hy = [42, 161.5];             // Y extent
hz = 76;                      // top (pot bottom >= 78.4)
xLip = [-26, -24.4];          // front lips (1.6 mm)
xSlot = [-24.4, -23.2];       // card slot (1.2 mm)
xPl = [-23.2, -20.2];         // back plate (3 mm)
xFt = [-20.2, -6];            // foot (Elevator 1's post 13 foot starts at X -5)
ftH = 5;                      // foot thickness
wall = 1.6;                   // side wall beyond the groove (Y)
cover = 3.5;                  // lip overlap on the card edges
zLedge = 3;                   // card bottom
zLipB = 7;                    // bottom lip top (covers 4 mm)
holeY = [50, 100, 150]; holeX = -10;   // v1.8 (grid, docs/modules_v1.8.md): bolts on grid nodes (v1.7: X -13, Y 52/102/152)
pinY = [60, 140];                      // v1.8: 2 locating pins (3 x 9 rod, pin_press, 5 deep in the foot, 4 out into the grid holes)
m3 = m3_clear; nutD = m3_nut; nutH = 2.6;   // v1.7t (fit audit): the nut pocket is m3_nut (6.6, standing), was 5.5/cos 30 + 0.4 = 6.75
card = [115, 72, 0.8];        // W (Y), H (Z), thickness

module holder() difference() {
    union() {
        translate([xPl[0], hy[0], 0]) cube([xPl[1]-xPl[0], hy[1]-hy[0], hz]);                       // back plate
        translate([xSlot[0], hy[0], 0]) cube([xSlot[1]-xSlot[0], wall, hz]);                       // side walls (groove ends)
        translate([xSlot[0], hy[1]-wall, 0]) cube([xSlot[1]-xSlot[0], wall, hz]);
        translate([xSlot[0], hy[0], 0]) cube([xSlot[1]-xSlot[0], hy[1]-hy[0], zLedge]);            // ledge the card stands on
        translate([xLip[0], hy[0], 0]) cube([xLip[1]-xLip[0], wall+cover, hz]);                    // side lips
        translate([xLip[0], hy[1]-wall-cover, 0]) cube([xLip[1]-xLip[0], wall+cover, hz]);
        translate([xLip[0], hy[0], 0]) cube([xLip[1]-xLip[0], hy[1]-hy[0], zLipB]);                // bottom lip
        translate([xFt[0]-0.01, hy[0], 0]) cube([xFt[1]-xFt[0]+0.01, hy[1]-hy[0], ftH]);           // foot
        for (y=[hy[0], 75, 128, hy[1]-3]) translate([0, y, 0]) gusset();                            // gussets
        for (y=holeY) translate([holeX, y, 0]) cylinder(d=nutD+2, h=ftH+nutH-1, $fn=6);          // nut bosses (v1.8: 8.6, they end at X -5.7 with the bolts at X -10)
    }
    for (y=pinY) translate([holeX, y, -0.01]) cylinder(d=pin_press, h=ftH, $fn=fit_fn);
    for (y=holeY) translate([holeX, y, 0]) {
        translate([0,0,-1]) cylinder(d=m3, h=20);
        translate([0,0,ftH+nutH-1-nutH]) cylinder(d=nutD, h=nutH+1, $fn=6);                         // nut pocket, open top
    }
    // finger notch at the top of the back plate (push the card up / pull it out)
    translate([xPl[0]-1, (hy[0]+hy[1])/2, hz]) rotate([0,90,0]) cylinder(r=9, h=10);
}
// triangle in XZ, 3 mm thick (Y): from the plate's back face (Z up to 36) down to the foot's end
module gusset() hull() {
    translate([xPl[1]-0.01, 0, 0]) cube([0.01, 3, 36]);
    translate([xFt[1]-3, 0, 0]) cube([3, 3, ftH]);
}
module card_world() color("white") translate([xSlot[0]+0.2, (hy[0]+hy[1]-card[0])/2, zLedge]) cube([card[2], card[0], card[1]]);

if (part=="placed") color("#59a5c4") holder();
if (part=="holder") translate([26, -hy[0], 0]) holder();     // print pose: foot on the bed at the origin
if (part=="card") card_world();
