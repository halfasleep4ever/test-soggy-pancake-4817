// v1.8 modular: THE place to set the coaster's size (docs/coaster_v1.8_modular.md section 3). Included by coaster_v1.scad,
// coaster_e1.scad (Elevator 1's lift kit follows) and v18m_e2_kit.scad. DEFAULT = the v1.7 geometry (Marie Murphy).
//  v18_th  ramp slope (deg)             v18_Lr  ramp length (mm)           v18_n  levels (odd; v18_H > 0: the most that fit)
//  v18_H   wanted Ztop (0 = use v18_n)   v18_goff  rail-gap offset (carrier ends set off mm wider: range 12+off .. 16.5+off)
// (-D on the command line reaches only the file you open, not the used files: change the values here for a shrink.)
v18_th = 2.5; v18_Lr = 200; v18_n = 19; v18_H = 0; v18_goff = 0;
v18_Ztop_min = 281;          // the E1 tray (Y 135) over the loop chute's top (Z 268.4): 5 mm clear at 281 (CAD)
function v18_nlev() = v18_H > 0 ? let(m=floor((v18_H - 56 - v18_Lr*sin(v18_th))/(v18_Lr*sin(v18_th)+8.05))+1) (m%2==1 ? m : m-1) : v18_n;
function v18_Ztop() = 56 + (v18_nlev()-1)*(v18_Lr*sin(v18_th) + 8.05) + v18_Lr*sin(v18_th);
v18_Z17 = 56 + 18*(200*sin(2.5)+8.05) + 200*sin(2.5);                 // v1.7 Ztop (366.654)
function v18_dZtop() = v18_Z17 - v18_Ztop();                            // how much lower the top is than v1.7
