// v1.7 stack side: one whole frame post (fr_post + the v1.7 foot flange), ONE body, in print pose (flat, tabs up).
// print X = world X, print Y = world Z (height), print Z = layers: back posts Z = world Y + 9, front posts Z = 61.65 - world Y (v1.7 doubler)
// openscad --backend=Manifold -D f=1 -D k=0 -o fea/stl/v17_post_f1k0.stl v17_fea_post.scad
include <coaster_v1.scad>
part = "none";
f = 1; k = 0;
if (f == 0) translate([0, 0, 9]) rotate([90, 0, 0]) mirror([0, 0, 1]) { fr_post(f, k); fr_foot(f, k); }
else translate([0, 0, 61.65]) rotate([-90, 0, 0]) { fr_post(f, k); fr_foot(f, k); }
