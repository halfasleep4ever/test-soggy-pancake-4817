// v1.8r: the parts this round changed, in their PRINT pose (as v16_stack_parts.scad mode "print" / E1_print), for cad/v18_stl/.
//   openscad --backend=Manifold -D 'pk="42_loop_chute"' -o v18_stl/42_loop_chute.stl v18r_export.scad
//   42_loop_chute : the chute with the v1.8r sight fin (loop frame: lies on its back face w = 0, print z = w)
//   50_finish_line: the finish sign, "< LINE" raised 1.5 mm (on its back, pose rotate([90,0,0]) as v16_stack_parts)
//   17_e1_wheel   : wheel and axle with the longer drum (disc face down)
//   21_e1_cw_pot  : the counterweight pot that hangs straight from the drum (upright)
//   13_e1_cw_post : the wheel-pin end post (flat on its Y 79.2 face)
//   12a_e1_frame  : the E1 frame (the bolt strip now joined to the wheel hub), front face down
include <coaster_v1.scad>
part = "none"; pk = "none";
if (pk=="42_loop_chute")  CL_chute();
if (pk=="50_finish_line") rotate([90,0,0]) finish_line();
if (pk=="17_e1_wheel")    E1_print("e1_wheel");
if (pk=="21_e1_cw_pot")   E1_print("e1_cw_pot");
if (pk=="13_e1_cw_post")  E1_print("e1_cw_post");
if (pk=="12a_e1_frame")   E1_print("e1_frame");
