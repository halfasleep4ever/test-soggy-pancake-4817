// Coaster v1 wrapper for the printed loop (loop_test.scad): 12 cm loop (ridge tips 121 mm apart), shorter lead-in and
// curve so the chute fits inside the box. coaster_v1.scad places the loop frame (x along X, y up, w = depth) at the POI.
include <loop_test.scad>
part = "none";
R = 62.5;            // ridge tips at R - 2 = 60.5 -> inside height 121 mm (scores 12 cm, 36 points)
L1 = 45; Rc = 40;    // lead-in and curve (test: 60 / 50)
ysplit = 1000;       // the chute is one piece in the coaster (fits the bed: about 70 x 190 mm)
ytop = 220;          // top of the chute track, above the POI (2026-10-27: was 200; the ball now rests UPHILL of the pencil)
xExit = 60;          // exit lane B to the felt corner (the E1 feed goes back under the ring's rising side here)
// v5 (2026-10-28), rule 3.k.v: the two sections must TOUCH at the POI. v4 had lane A band w 0..20 and lane B 21.5..41.5
// (a 1.5 mm gap). Now lane B is 20..40: both bands share the face w = 20, so the two tracks touch along the whole POI.
// Lane B's centre moves 1.5 mm in (w 30). The balls still clear each other's lane: a ball in lane A reaches w 20.5 at
// its equator, 7 mm above lane B's ridges (they start at w 20.6, 2 mm high).
bB0 = 20; bB1 = 40; wB = 30;
lab_h = 6.2;         // v5: label text size (6.1 mm capitals; size 6 gives 5.9) (rules 3.f, 3.k.iv, 3.k.v): 6 mm, raised 0.8 mm, on faces seen from the front
// one-piece chute (no joint): the straight from the top down to the arc
chute_all_st = [ for (y=[ytop:-5:arcTop[1]+0.01]) strSt(y) ];
// v5: START label block behind the chute at the start line (horizontal text, seen from the front)
st_s = strSt(ytop-30);                                   // the pencil hole centre = the start line (rule 4.g)
// The block stays inside the base (world X >= -24): it hangs down-left of the chute, under the line's extension.
module st_block() let(c=st_s[0], n=st_s[1], bx=-24-POIx_w, by0=165.4, by1=192.4) hull() {
    for (d=[3, -30]) let(q=strSt(ytop-30+d)[0]) translate([q[0]-n[0]*(T-0.5), q[1]-n[1]*(T-0.5), 0]) cylinder(r=0.5, h=bA, $fn=12);
    translate([bx, by0, 0]) cube([21, by1-by0, bA]);
}
POIx_w = 145;        // world X of the POI (coaster_v1.scad POIx)
module CL_chute() difference() {
    union() {
        sweep(chute_all_st, [ for (s=chute_all_st) prof(0, bA, wA) ]);
        peg(strSt(arcTop[1]), 0, 1);
        for (y=[90, 170]) tab(strSt(y), 0);
        at_station(strSt(ytop), 0, 0) cube([3, 14, bA]);
        st_block();
    color("#f4f1ea") translate([-10-POIx_w, 216-43.6, bA-0.01]) linear_extrude(0.81) mirror([1,0,0]) text("START", size=lab_h, halign="center", valign="center", font="Liberation Sans:style=Bold");
    }
    // v5, rules 3.f + 4.g: the start line runs across the track exactly through the pencil hole centre. The pencil (held
    // in the hand, across both ridges) lies ON the line; the ball rests on its uphill side, so all of the ball is
    // behind the line. (v4: line 6 mm downhill of the pencil centre, the pencil did not reach it.)
    // 1.2 mm groove across the front face (w = 20) of the wall, ridges and label block, 0.8 mm deep; paint it red.
    at_station(st_s, 0, bA-0.8) translate([-0.6, -T-24, 0]) cube([1.2, T+24+rp+1, 2]);   // through the label block
    at_station(st_s, rp+9.5, -1) cylinder(d=8.4, h=bA+2, $fn=24);     // pencil hole across both ridges
}
// The loop frame is mirrored in the world (at_loop), so every text here is mirrored to read right from the front.
// v5: label blocks on the ring piece (full depth w 0..40, so they print from the bed), raised text on the front face w = 40
poi_blk = [[-17, -22], [17, -T]];                        // loop frame x, y: under the POI
top_blk = [[-34, 2*R+T-0.5], [34, 2*R+T+19]];            // over the top of the ring
module CL_ring() difference() {
    union() {
        sweep(lead_st, [ for (s=lead_st) prof(0, bA, wA) ]);
        sweep([ for (th=[0:2.5:62.5]) ringSt(th) ], [ for (th=[0:2.5:62.5]) prof(0, bA, wA) ]);
        sweep([ for (th=[57.5:2.5:302.5]) ringSt(th) ], [ for (th=[57.5:2.5:302.5]) prof(0, bB1, wcRing(th)) ]);
        // the ring's last part (lane B only): its band starts at w 21.5 until th 337.5 (there lane B's wall is level with
        // the lead-in ball's side), and at w 20 from th 340 on, so the two tracks touch over the 42 mm round the POI
        sweep([ for (th=[297.5:2.5:337.5]) ringSt(th) ], [ for (th=[297.5:2.5:337.5]) prof(21.5, bB1, wB) ]);
        sweep([ for (th=[337.5:2.5:360]) ringSt(th) ], [ for (th=[337.5:2.5:360]) prof(th < 339 ? 21.5 : bB0, bB1, wB) ]);
        sweep([ for (x=[0:5:xExit]) leadSt(x) ], [ for (x=[0:5:xExit]) prof(bB0, bB1, wB) ]);
        for (th=[150, 180, 210, 240]) tab(ringSt(th), 0);
        tab(leadSt(-25), 0); tab(arcSt(-40), 0);
        for (b=[poi_blk, top_blk]) translate([b[0][0], b[0][1], 0]) cube([b[1][0]-b[0][0], b[1][1]-b[0][1], bB1]);
        // raised labels (0.8 mm) on the front face
        color("#f4f1ea") translate([0, -T-3.2, bB1-0.01]) linear_extrude(0.81) polygon([[-3,0],[3,0],[0,3]]);
        color("#f4f1ea") translate([0, -T-11.5, bB1-0.01]) linear_extrude(0.81) mirror([1,0,0]) text("POI", size=lab_h, halign="center", valign="center", font="Liberation Sans:style=Bold");
        color("#f4f1ea") translate([0, 2*R+T+1.2, bB1-0.01]) linear_extrude(0.81) polygon([[-3,3],[3,3],[0,0]]);
        color("#f4f1ea") translate([0, 2*R+T+13.5, bB1-0.01]) linear_extrude(0.81) mirror([1,0,0]) text("LOOP 121 mm", size=lab_h, halign="center", valign="center", font="Liberation Sans:style=Bold");
        color("#f4f1ea") translate([0, 2*R+T+6.2, bB1-0.01]) linear_extrude(0.81) mirror([1,0,0]) text("POI TO TOP INSIDE", size=3.2, halign="center", valign="center", font="Liberation Sans:style=Bold");
    }
    socket(strSt(arcTop[1]), 0, 1);
    // rule 3.k.v: the measuring point. A 2 mm cone dimple on the seam where the two tracks touch (x 0, w 20, on the wall
    // surface between the lanes) and a 1.2 mm line down the front face from the ridge tips to the POI label.
    translate([0, 0.01, bB0]) rotate([-90,0,0]) cylinder(d1=0, d2=2.4, h=1.2, $fn=16);
    translate([-0.6, -22.5, bB1-0.8]) cube([1.2, 22.5+rp+0.5, 2]);
    // rules 3.k.iii + iv: the loop height. Line + arrow at the highest inside point (ridge tips, y = 2R - 2), text over it.
    translate([-0.6, 2*R-rp-0.5, bB1-0.8]) cube([1.2, T+rp+3.5, 2]);
}
module CL_v1() { color("#59a5c4") CL_ring(); color("#d08a4a") CL_chute(); }
function CL_tab_holes() = let(h=function(s) [s[0][0]+s[1][0]*(-T-5), s[0][1]+s[1][1]*(-T-5)])
    concat([ for (th=[150, 180, 210, 240]) h(ringSt(th)) ], [ h(leadSt(-25)), h(arcSt(-40)) ], [ for (y=[90, 170]) h(strSt(y)) ]);
// ball centre path (loop frame [x, y, w]) for clearance checks
CL_nc = rp + sqrt(ball_r*ball_r - rsep*rsep);
function CL_ctr(s, w) = [s[0][0]+s[1][0]*CL_nc, s[0][1]+s[1][1]*CL_nc, w];
// ball centre at the start: resting on the pencil (pencil r 4.2 + ball r) on its uphill side
function CL_ballstart() = let(p=CL_ctr(strSt(ytop-30), wA), ys=[for (d=[0:0.1:25]) d], k=[for (d=ys) abs(norm(CL_ctr(strSt(ytop-30+d), wA)-p)-(4.2+ball_r))], m=min(k)) CL_ctr(strSt(ytop-30+ys[search(m, k)[0]]), wA);
function CL_path() = concat([CL_ballstart()], [ for (s=chute_all_st) if (CL_ctr(s, wA)[1] < CL_ballstart()[1] - 1) CL_ctr(s, wA) ], [ for (s=lead_st) CL_ctr(s, wA) ],
              [ for (th=[0:5:360]) CL_ctr(ringSt(th), wcRing(th)) ], [ for (x=[0:5:xExit]) CL_ctr(leadSt(x), wB) ]);
function CL_st() = st_s;   // v5: the start line station (coaster_v1 "use"s this file: variables do not cross, functions do)
function CL_T() = T; function CL_rp() = rp;
function CL_info() = [R, arcTop, strSt(ytop)[0], wA, wB, bB1, CL_nc];
