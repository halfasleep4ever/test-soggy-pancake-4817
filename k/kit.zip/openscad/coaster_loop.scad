// Coaster v1 wrapper for the printed loop (loop_test.scad): 12 cm loop (ridge tips 121 mm apart), shorter lead-in and
// curve so the chute fits inside the box. coaster_v1.scad places the loop frame (x along X, y up, w = depth) at the POI.
include <loop_test.scad>
part = "none";
R = 62.5;            // ridge tips at R - 2 = 60.5 -> inside height 121 mm (scores 12 cm, 36 points)
L1 = 45; Rc = 40;    // lead-in and curve (test: 60 / 50)
ysplit = 1000;       // the chute is one piece in the coaster (fits the bed: about 70 x 190 mm)
ytop = 220;          // top of the chute track, above the POI (2026-10-27: was 200; the ball now rests UPHILL of the pencil)
xExit = 60;          // exit lane B to the felt corner (the E1 feed goes back under the ring's rising side here)
// one-piece chute (no joint): the straight from the top down to the arc
chute_all_st = [ for (y=[ytop:-5:arcTop[1]+0.01]) strSt(y) ];
module CL_chute() difference() {
    union() {
        sweep(chute_all_st, [ for (s=chute_all_st) prof(0, bA, wA) ]);
        peg(strSt(arcTop[1]), 0, 1);
        for (y=[90, 170]) tab(strSt(y), 0);
        at_station(strSt(ytop), 0, 0) cube([3, 14, bA]);
    }
    // (2026-10-27) the ball rests on the pencil's uphill side, so it sits completely behind the start line just below
    // the pencil (rules 3.d, 3.f). Before, the pencil was above the line and the ball resting on it was past the line.
    // start line (rule 3.f): engraved across the top face + "START"
    let(s=strSt(ytop-36)) at_station(s, -T+0.4, bA-0.6) { translate([-0.5,-1,0]) cube([1, T+4, 1]); translate([0,-4.6,0]) linear_extrude(1) text("START", size=2.6, halign="center", valign="center"); }
    let(s=strSt(ytop-30)) at_station(s, rp+9.5, -1) cylinder(d=8.4, h=bA+2, $fn=24);     // pencil hole across both ridges
}
module CL_ring() difference() {
    union() {
        sweep(lead_st, [ for (s=lead_st) prof(0, bA, wA) ]);
        sweep([ for (th=[0:2.5:62.5]) ringSt(th) ], [ for (th=[0:2.5:62.5]) prof(0, bA, wA) ]);
        sweep([ for (th=[57.5:2.5:302.5]) ringSt(th) ], [ for (th=[57.5:2.5:302.5]) prof(0, bB1, wcRing(th)) ]);
        sweep([ for (th=[297.5:2.5:360]) ringSt(th) ], [ for (th=[297.5:2.5:360]) prof(bB0, bB1, wB) ]);
        sweep([ for (x=[0:5:xExit]) leadSt(x) ], [ for (x=[0:5:xExit]) prof(bB0, bB1, wB) ]);
        for (th=[150, 180, 210, 240]) tab(ringSt(th), 0);
        tab(leadSt(-25), 0); tab(arcSt(-40), 0);
    }
    socket(strSt(arcTop[1]), 0, 1);
    at_station(ringSt(180), -T+0.5, bB1-0.6) rotate([0,0,180]) linear_extrude(1) text("LOOP 121 mm", size=3.5, halign="center", valign="center");
    at_station(leadSt(12), -T+0.4, bB1-0.6) linear_extrude(1) text("< POI", size=3, halign="center", valign="center");
    at_station(leadSt(-12), -T+0.4, bA-0.6) linear_extrude(1) text("POI >", size=3, halign="center", valign="center");
}
module CL_v1() { color("#59a5c4") CL_ring(); color("#d08a4a") CL_chute(); }
function CL_tab_holes() = let(h=function(s) [s[0][0]+s[1][0]*(-T-5), s[0][1]+s[1][1]*(-T-5)])
    concat([ for (th=[150, 180, 210, 240]) h(ringSt(th)) ], [ h(leadSt(-25)), h(arcSt(-40)) ], [ for (y=[90, 170]) h(strSt(y)) ]);
// ball centre path (loop frame [x, y, w]) for clearance checks
CL_nc = rp + sqrt(ball_r*ball_r - rsep*rsep);
function CL_ctr(s, w) = [s[0][0]+s[1][0]*CL_nc, s[0][1]+s[1][1]*CL_nc, w];
// ball centre at the start: resting on the pencil (pencil r 4.2 + ball r) on its uphill side
function CL_ballstart() = let(p=CL_ctr(strSt(ytop-30), wA), ys=[for (d=[0:0.1:25]) d], k=[for (d=ys) abs(norm(CL_ctr(strSt(ytop-30+d), wA)-p)-(4.2+ball_r))], m=min(k)) CL_ctr(strSt(ytop-30+ys[search(m, k)[0]]), wA);
function CL_path() = concat([CL_ballstart()], [ for (s=chute_all_st) if (CL_ctr(s, wA)[1] < CL_ballstart()[1] - 1) CL_ctr(s, wA) ], [ for (s=lead_st) CL_ctr(s, wA) ],
              [ for (th=[0:5:360]) CL_ctr(ringSt(th), wcRing(th)) ], [ for (x=[0:5:xExit]) CL_ctr(leadSt(x), wB) ]);
function CL_info() = [R, arcTop, strSt(ytop)[0], wA, wB, bB1, CL_nc];
