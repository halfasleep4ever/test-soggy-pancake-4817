// FIT TEST 3 (2026-10-29, after coupon 2): no numbers on the part; guide picture cad/png/fit_test3_guide.png.
// The cut corner marks the FRONT-LEFT. In every row the sizes grow left to right: SMALL, MIDDLE, BIG.
// Sliced with scarf seams (no seam bump in the holes), like the real parts from now on.
// FRONT row: SNAP rod grooves. Coupon 2: every groove 2.95-3.10 let the rod slide freely in and out, because the lip
//   at the top was too small to print. Here the groove is 3.00 and the top opening narrows: 2.85 / 2.75 / 2.65
//   (the groove centre sits 0.47 / 0.60 / 0.70 mm below the top). Press a 3 mm rod down from the top.
//   Best = it clicks in by thumb, sits with no wobble, and does not fall out when the coupon is turned over.
// MIDDLE row: standing 3 mm pin SLIP holes 3.15 / 3.20 / 3.25 (coupon 2: 3.25 slides but wobbles a little).
//   Best = the smallest one the pin slides in and out of by hand.
// BACK row: standing 3 mm pin TURN holes 3.45 / 3.60 / 3.75. Best = the smallest one the pin turns freely in.
include <common.scad>
$fn = 48;
L = 30; W = 30; H = 6;
xs = [6, 15, 24];
module snap_groove(d, w, len) {                       // groove along Y, open on top; opening width w at the top face
    c = sqrt(pow(d/2, 2) - pow(w/2, 2));             // depth of the groove centre below the top face
    translate([0, 0, H - c]) rotate([90,0,0]) cylinder(d=d, h=len, center=true);
}
difference() {
    cube([L, W, H]);
    for (k=[0:2]) {
        translate([xs[k], 5, 0]) snap_groove(3.00, [2.85, 2.75, 2.65][k], 12);    // y -1..11, open at the front face
        translate([xs[k], 17, -1]) cylinder(d=[3.15, 3.20, 3.25][k], h=H + 2);
        translate([xs[k], 25, -1]) cylinder(d=[3.45, 3.60, 3.75][k], h=H + 2);
    }
    translate([0, 0, -1]) rotate([0,0,45]) cube([4, 4, H + 2], center=true);     // cut corner = front-left
}
