// v1.7 stack side FEA: assemblies (bonded pieces) in WORLD pose, for cad/fea/v17s_fea.py (it turns them to the print
// pose and checks one piece at a time with --eval). fk = assembly key.
include <v16_stack_parts.scad>
fk = "none";
if (fk=="e2_bracket")      { e2_bracket_lo(); e2_bracket_hi(); e2_bracket_beam(); }          // 38a + 38b + 38c (laps bonded)
if (fk=="ladder_front")    { frame_ladder(1); fr_strip(0); fr_strip(1); }                    // 06b + 06i + 06j (strips bonded)
if (fk=="ladder_back")     frame_ladder(0);
if (fk=="post_front_L")    { fr_post(1, 0); fr_foot(1, 0); }                                 // whole front-left post (lap bonded)
if (fk=="post_front_R")    { fr_post(1, 1); fr_foot(1, 1); }
if (fk=="post_back_R")     { fr_post(0, 1); fr_foot(0, 1); }
if (fk=="comb_front")      gd_body(1);                                                         // 08a + 08b (dovetail bonded)
if (fk=="comb_back")       gd_body(0);
if (fk=="tray_e1")         { tray_e1_a(); tray_e1_b(); }                                       // 25a + 25b (scarf bonded)
if (fk=="front_top")       { frame_ladder(1); fr_strip(0); fr_strip(1); p3_bracket(); }        // v1.7 FEA: 06b + 06i/j + 40 (bolted, taken as bonded)
