// FIT TEST 4 (2026-10-29): standing PRESS holes with scarf seams. Coupon 3 showed that 3.15 now slides (the seam bump
// that gripped the pin is gone), so the press size is smaller. Holes 2.95 / 3.00 / 3.05 / 3.10, sizes grow left to right,
// the cut corner marks the FRONT-LEFT, no numbers on the part. Best = a firm push and the pin stays in upside down.
include <common.scad>
$fn = 48;
L = 30; W = 8; H = 6;
xs = [4.5, 11.5, 18.5, 25.5];
difference() {
    cube([L, W, H]);
    for (k=[0:3]) translate([xs[k], 4, 1.2]) cylinder(d=[2.95, 3.00, 3.05, 3.10][k], h=H);
    translate([0, 0, -1]) rotate([0,0,45]) cube([4, 4, H + 2], center=true);
}
