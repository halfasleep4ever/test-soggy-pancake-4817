// v1.8 modular: HAND-OFF GAUGES (docs/modules_v1.8.md section 6). After a module swap, at each hand-off I1, I3, I6, I7:
//  1. "ball" : a printed 19.05 mm ball on a 4 mm stem with a handle. Set it on the GIVING track's end (it sits where the
//     real ball's centre is), slide it over the joint: it must drop 0 to 1.5 mm onto the RECEIVING track, never climb.
//  2. "feelers": 4 leaves 0.5 / 1.0 / 1.5 / 2.0 mm (labelled). With the gauge ball on the giving end, the 1.5 leaf must
//     NOT pass between the gauge ball and the receiving surface at the joint, the 0.5 leaf may (step 0..1.5 down).
//  3. "card": the target table (ball centre X, Y, Z of every hand-off, at the default size), engraved, for a ruler check
//     of the height over the base (Z) at I1, I6, I7 (I3 is 381 mm up: check it with the E1 cup at the top instead).
// Positions: docs/modules_v1.8.md section 6 (ball centre, sim path).
include <common.scad>
part = "ball";
$fn = 64;
module g_ball() union() {
    sphere(d=19.05);
    translate([0, 0, 8]) cylinder(d=4, h=40);                 // stem (up: it never touches a track)
    translate([0, 0, 48]) hull() { cylinder(d=12, h=2); translate([0, 0, 10]) cylinder(d=8, h=1); }   // handle
}
module g_feelers() for (i=[0:3]) let(t=[0.5, 1.0, 1.5, 2.0][i]) translate([0, i*16, 0]) difference() {
    union() { cube([60, 12, t]); translate([46, 0, 0]) cube([14, 12, 2.4]); }
    translate([53, 6, 2.4-0.6]) linear_extrude(1) text(str(t), size=4, halign="center", valign="center", font="Liberation Sans:style=Bold");
}
G = [["I1 loop>E1 feed", "205 149 53.0"], ["I3 E1 pour>tray", "270 128.5 381.6"],
     ["I6 ramp 19>gate", "229.8 16 56.0"], ["I7 gate>E2 feed", "244 17 49.1"]];
module g_card() difference() {
    cube([86, 44, 1.6]);
    for (i=[0:3]) translate([3, 36-i*10, 1.0]) linear_extrude(1) text(str(G[i][0], "  ", G[i][1]), size=3.2, font="Liberation Sans:style=Bold");
}
if (part=="ball")    translate([0, 0, 9.525]) g_ball();      // print: ball down on tree support, or print the ball and the stem apart
if (part=="feelers") g_feelers();
if (part=="card")    g_card();
