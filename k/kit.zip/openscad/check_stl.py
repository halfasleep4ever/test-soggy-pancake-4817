"""Check exported STL files: bed fit (Snapmaker U1: 270 x 270 x 270 mm), closed mesh, volume, part count.
Run: python3 check_stl.py stl/*.stl
"""
import struct, sys
from collections import Counter
from pathlib import Path

def load(p):
    data = Path(p).read_bytes()
    tris = []
    if data[:5] == b"solid" and b"facet" in data[:400]:
        v = []
        for line in data.decode(errors="ignore").splitlines():
            t = line.split()
            if t and t[0] == "vertex":
                v.append(tuple(float(x) for x in t[1:4]))
                if len(v) == 3: tris.append(v); v = []
    else:
        n = struct.unpack("<I", data[80:84])[0]
        for i in range(n):
            f = struct.unpack("<12f", data[84+i*50:84+i*50+48])
            tris.append([f[3:6], f[6:9], f[9:12]])
    return tris

def check(p):
    tris = load(p)
    q = lambda v: tuple(round(c, 3) for c in v)
    edges = Counter()
    vol = 0.0
    xs, ys, zs = [], [], []
    for a, b, c in tris:
        a, b, c = q(a), q(b), q(c)
        for e in ((a, b), (b, c), (c, a)): edges[tuple(sorted(e))] += 1
        vol += (a[0]*(b[1]*c[2]-b[2]*c[1]) - a[1]*(b[0]*c[2]-b[2]*c[0]) + a[2]*(b[0]*c[1]-b[1]*c[0])) / 6
        for v in (a, b, c): xs.append(v[0]); ys.append(v[1]); zs.append(v[2])
    open_e = sum(1 for k, n in edges.items() if n != 2)
    size = (max(xs)-min(xs), max(ys)-min(ys), max(zs)-min(zs))
    fits = all(s <= 270 for s in size)
    # connected parts (by shared vertices)
    parent = {}
    def f(x):
        while parent.setdefault(x, x) != x: parent[x] = parent[parent[x]]; x = parent[x]
        return x
    for a, b, c in tris:
        a, b, c = q(a), q(b), q(c); parent[f(b)] = f(a); parent[f(c)] = f(a)
    parts = len({f(v) for v in parent})
    ok = open_e == 0 and fits and abs(vol) > 1
    print(f"{'OK ' if ok else 'BAD'} {Path(p).name:28s} {size[0]:6.1f} x {size[1]:6.1f} x {size[2]:6.1f} mm  "
          f"vol {abs(vol)/1000:7.1f} cm3  open edges {open_e:3d}  pieces {parts}  zmin {min(zs):.2f}")
    return ok

if __name__ == "__main__":
    res = [check(p) for p in sys.argv[1:]]
    print(f"{sum(res)}/{len(res)} ok")


def normalize(p):
    """Rewrite an STL as binary, centred in x/y with its lowest point at z = 0 (slicers arrange these cleanly)."""
    tris = load(p)
    xs = [v[0] for t in tris for v in t]; ys = [v[1] for t in tris for v in t]; zs = [v[2] for t in tris for v in t]
    cx, cy, z0 = (min(xs)+max(xs))/2, (min(ys)+max(ys))/2, min(zs)
    out = bytearray(b"normalized".ljust(80, b" ")) + struct.pack("<I", len(tris))
    for t in tris:
        a, b, c = [(v[0]-cx, v[1]-cy, v[2]-z0) for v in t]
        u = [b[i]-a[i] for i in range(3)]; w = [c[i]-a[i] for i in range(3)]
        n = [u[1]*w[2]-u[2]*w[1], u[2]*w[0]-u[0]*w[2], u[0]*w[1]-u[1]*w[0]]
        L = sum(x*x for x in n) ** 0.5 or 1
        out += struct.pack("<12fH", *(x/L for x in n), *a, *b, *c, 0)
    Path(p).write_bytes(bytes(out))
