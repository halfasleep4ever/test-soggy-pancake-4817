"""Collision + ball-path checks for coaster_v1.scad (v5; OpenSCAD intersections; empty = no collision).
Run: python3 check_v1.py [-j N] [name ...]   -> one line per check: OK / HIT (volume, bounding box, pieces).
v5: "MUST" checks pass only when the intersection is NOT empty (the two loop tracks touch; the pencil lies on the
start line). New elevator checks: both elevators together (grid of all angle pairs, with ropes and cords), the real
timeline, and the ropes against every static part."""
import subprocess, sys, os, struct, re
from pathlib import Path
HERE = Path(__file__).resolve().parent
OUT = Path.home()/"Daniel/temp/v1work/chk"; OUT.mkdir(parents=True, exist_ok=True)
E1A = [-52.2 + i*104.4/14 for i in range(15)] + [52.2 - d for d in (6, 4.5, 3.5, 2.5, 1.8, 1.2, 0.6, 0.3)]   # finer at the top: the cam tips the cup there
E2A = [-53.1 + i*106.2/14 for i in range(15)] + [53.1 - d for d in (6, 4.5, 3.5, 2.5, 1.8, 1.2, 0.6, 0.3)]
def sweep(mod, origin, angles): return "union(){" + "".join(f"translate({origin}) {mod}({a:.2f});" for a in angles) + "}"
E1S = sweep("E1_moving", "[245.8,103,0]", E1A)
E2S = sweep("E2_moving", "[262,67,0]", E2A)
E1TOP = "translate([245.8,103,0]) E1_moving(52.2);"
E2REST = "translate([262,67,0]) E2_moving(-53.1);"
LAD = "all_carriages();"
# v5: moving parts + their cords/ropes; both elevators together
E1M = lambda a: f"translate([245.8,103,0]) E1_moving({a:.2f}); E1cords_w({a:.2f});"
E2M = lambda a: f"translate([262,67,0]) E2_moving({a:.2f}); E2rope_w({a:.2f});"
E2ALL = "union(){" + "".join(E2M(a) for a in E2A) + "}"
# moving parts WITHOUT the ball that E1_moving / E2_moving carry in the cup (for ball-path checks)
E1MB = lambda a: f"translate([245.8,103,0]) {{ E1_lever_at({a:.2f}); E1_cup_alone({a:.2f}); E1_roller_at({a:.2f}); E1_pot_at({a:.2f}); }} E1cords_w({a:.2f});"
E2MB = lambda a: f"translate([262,67,0]) {{ E2_lever_at({a:.2f}); E2_cup_alone({a:.2f}); E2_roller_at({a:.2f}); E2_p2_at({a:.2f}); E2_pot_at({a:.2f}); }} E2rope_w({a:.2f});"
def grid(angles):   # every E1 angle in the list against E2 at every angle (E1A x E2A = 23 x 23 pairs over the 3 groups)
    return "union(){" + "".join(f"intersection(){{ union(){{ {E1M(a)} }} {E2ALL} }}" for a in angles) + "}"
G = [E1A[0:8], E1A[8:15], E1A[15:]]
ROPE2 = "difference(){ union(){" + "".join(f"E2rope_w({a:.2f});" for a in E2A) + "} translate(E2ANC) sphere(r=6); }"   # (tied in the anchor)
ROPE2SELF = "union(){" + "".join(f"intersection(){{ difference(){{ E2rope_w({a:.2f}); translate([262,67,0]+E2_rope_pt({a:.2f})) sphere(r=9.5); }} translate([262,67,0]) E2_moving({a:.2f}); }}" for a in E2A) + "}"
CORD1 = "union(){" + "".join(f"E1cords_w({a:.2f});" for a in E1A) + "}"
START_PLANE = "at_loop() at_station(CL_st(), 0, -40) translate([-0.05, -60, 0]) cube([0.1, 120, 100]);"
DOWNHILL = "at_loop() at_station(CL_st(), 0, -40) translate([0, -60, 0]) cube([300, 120, 100]);"
MUST = {"poi_tracks_touch", "pencil_on_start_line", "trip_pin_E1_pressed", "trip_pin_E2_pressed"}
def saus(pts_expr, r="ball_r-0.3", fn=16):
    return f"let(pp={pts_expr}) for (k=[0:len(pp)-2]) hull() {{ translate(pp[k]) sphere(r={r}, $fn={fn}); translate(pp[k+1]) sphere(r={r}, $fn={fn}); }}"
LOOPPATH = "at_loop() " + saus("CL_path()")
# ramps: start 12 mm in (the ball leaves the 6 mm cup tongue there and drops onto the rails at gaps > 12)
RAMPS = ("for (i=[0:n-1]) let(s=i%2?1:-1, o=[0, s*d2/2, -(rod_drop(12)-rod_drop(gap))]) hull() "
         "{ translate(entry(i)+o+[dirOf(i)*(gap>15?16:12),0,0]) sphere(r=ball_r-0.3, $fn=16); translate(rend(i)+o-[dirOf(i)*4,0,0]) sphere(r=ball_r-0.3, $fn=16); }")
def cagedrop(s):   # ball falls down a channel from where it drops in (tray end) to its lowest carriage position
    return f"let(c=CH[{s}], t=[{'E2tray' if s == 0 else 'E1tray'}][0], e=t[len(t)-1]-[0,0,0.8]) hull(){{ translate(e) sphere(r=ball_r-0.3,$fn=16); translate([c[0],c[1],cupEntryZ(c[4][len(c[4])-1])+6]) sphere(r=ball_r-0.3,$fn=16); }}"
def handover(s):   # carriage -> lip -> through the cup's ladder slot -> exit corner, at every ladder position
    sx, sy = ("-1", "1") if s == 0 else ("1", "-1")
    return (f"let(c=CH[{s}]) for (i=c[4]) let(z=cupEntryZ(i)) " +
            saus(f"[[c[0],c[1],z+10], [c[0]+({sx})*8,c[1],z+3], [c[0]+({sx})*16,c[1],z], [c[0]+({sx})*22,c[1]+({sy})*1.0,z-0.8], [c[0]+({sx})*32.2,c[1]+({sy})*2.6,z-2.35]]"))
SKIPMOV = 'static_parts(skip="e1"); '
CHECKS = {
 # static structure
 "stack_vs_rest@12":  ("12",   "stack();", "static_parts(skip=\"stack\");"),
 "stack_vs_rest@16.5":("16.5", "stack();", "static_parts(skip=\"stack\");"),
 "ladder_vs_rest":    ("14.3", "union(){ cage(0); cage(1); tops(); }", "static_parts(skip=\"ladder\");"),
 "carriages@12":      ("12",   LAD, "static_parts();"),
 "carriages@16.5":    ("16.5", LAD, "static_parts();"),
 "flaps_vs_rest":     ("14.3", "flaps();", "static_parts(skip=\"flaps\");"),
 "feeds_vs_rest":     ("14.3", "union(){ gate(); feeds(); e1feed(); }", "static_parts(skip=\"feeds\");"),
 "loop_vs_rest":      ("14.3", "union(){ at_loop() CL_v1(); loop_board(); }", "static_parts(skip=\"loop\");"),
 # inside the groups (found by the Fusion v2 interference check)
 "spines_vs_cups":    ("14.3", "for (i=[0:n-1]) at_ramp(i) stack_spine();", "for (i=[0:n-2]) uturn(i);"),
 "carriers_vs_cups@16.5":("16.5", "for (i=[0:n-1]) at_ramp(i) translate([0, -rod_cc(gap), 4]) stack_carrier();", "for (i=[0:n-2]) uturn(i);"),
 "carriers_vs_frame@16.5":("16.5", "for (i=[0:n-1]) at_ramp(i) translate([0, -rod_cc(gap), 4]) stack_carrier();", "frame();"),
 "carriers_vs_frame@12":("12", "for (i=[0:n-1]) at_ramp(i) translate([0, -rod_cc(gap), 4]) stack_carrier();", "frame();"),
 "frame_vs_spines":   ("14.3", "frame();", "for (i=[0:n-1]) ramp(i);"),
 "gdstatic_vs_frames":("14.3", "gd_static();", "union(){ gd_frame(0); gd_frame(1); }"),
 "elevators_vs_base": ("14.3", "union(){ translate([245.8,103,0]) E1_static(); translate([262,67,0]) E2_static(); }", "base();"),
 "bracket_vs_rest":   ("14.3", "e2_bracket();", "static_parts(skip=\"bracket\");"),
 "bracket_vs_E2pulley":("14.3", "e2_bracket();", "translate([262,67,0]) E2_static();"),
 "cams_vs_E1top":     ("14.3", "tipcams();", "translate([245.8,103,0]) E1_moving(52.2);"),
 "carriage_pads":     ("14.3", "for (s=[0,1], i=CH[s][4]) at_ch(s) let(z=cupEntryZ(i)) translate([0, 0, z+2]) rotate([0, -35, 0]) translate([-10, -8, -0.5]) cube([20, 16, 2]);", "for (s=[0,1], i=CH[s][4]) at_ch(s) let(z=cupEntryZ(i)) translate([0, 0, z+2]) rotate([0, -35, 0]) difference() { translate([-14, -chHalf+1.6, -2.5]) cube([28, 2*chHalf-3.2, 4]); translate([-10.2, -8.2, -0.6]) cube([20.4, 16.4, 2.2]); }"),
 "pads_in_pockets":   ("14.3", "pads();", "static_parts();"),
 "ball_start":        ("14.3", "at_loop() translate(CL_ballstart()) sphere(r=ball_r-0.3, $fn=32);", "static_parts();"),
 # elevators swept over their lift (the flaps are lifted by the cups: checked at the top only)
 "E1sweep_vs_static": ("14.3", E1S, "static_parts(skip=\"e1\", nf=true);"),
 "E1sweep_vs_E1static":("14.3", E1S, "translate([245.8,103,0]) E1_static();"),
 "E1sweep_vs_E2rest": ("14.3", E1S, E2REST),
 "E1sweep_vs_carriages":("14.3", E1S, LAD),
 "E2sweep_vs_static": ("14.3", E2S, "static_parts(skip=\"e2\", nf=true);"),
 "E2sweep_vs_E2static":("14.3", E2S, "translate([262,67,0]) E2_static();"),
 "E2sweep_vs_E1top":  ("14.3", E2S, E1TOP),
 "E2sweep_vs_carriages":("14.3", E2S, LAD),
 "E1lever_vs_cup":    ("14.3", "union(){" + "".join(f"intersection(){{ translate([245.8,103,0]) E1_lever_at({a:.2f}); translate([245.8,103,0]) E1_cup_at({a:.2f}); }}" for a in E1A) + "}", "cube(3000, center=true);"),
 "E2lever_vs_cup":    ("14.3", "union(){" + "".join(f"intersection(){{ translate([262,67,0]) E2_lever_at({a:.2f}); translate([262,67,0]) E2_cup_at({a:.2f}); }}" for a in E2A) + "}", "cube(3000, center=true);"),
 "E1top_vs_flaps":    ("14.3", E1TOP, "flaps();"),
 "E2top_vs_flaps":    ("14.3", "translate([262,67,0]) E2_moving(53.1);", "flaps();"),
 # ball paths (ball 0.3 mm undersize): must touch nothing
 "ball_loop":         ("14.3", LOOPPATH, "static_parts(skip=\"loop\");"),
 "ball_loop_self":    ("14.3", LOOPPATH, "at_loop() CL_v1();"),
 "ball_E1feed":       ("14.3", saus("down(E1feed)", fn=48), "static_parts(nt=true);"),
 # v5: the ball (full size) must press each latch trip pin (v4's combined check intersected the two paths with each other)
 "trip_pin_E1_pressed": ("14.3", saus("[for (k=[len(E1feed)-2:len(E1feed)-1]) E1feed[k]-[0,0,0.8]]", r="ball_r", fn=48), "translate([245.8,103,0]) E1_trip_at();"),
 "trip_pin_E2_pressed": ("14.3", saus("[for (k=[len(E2feed)-2:len(E2feed)-1]) E2feed[k]-[0,0,0.8]]", r="ball_r", fn=48), "translate([262,67,0]) E2_trip_at();"),
 "ball_E1pour":       ("14.3", saus("E1pour"), "static_parts();"),
 "ball_E1tray":       ("14.3", saus("down(E1tray)"), "static_parts();"),
 "ball_E2pour":       ("14.3", saus("E2pour"), "static_parts();"),
 "ball_E2tray":       ("14.3", saus("down(E2tray)"), "static_parts();"),
 "ball_gate_in":      ("14.3", saus("[rend(18)-[4,0,0], rend(18)+[6,0,-2], [244,16,50.2], E2feed[0]]"), "static_parts();"),
 "ball_E2feed":       ("14.3", saus("E2feed"), "static_parts(nt=true);"),
 "ball_drop_finish":  ("14.3", saus("concat([[244,17,49.8]], finish_pts)"), "static_parts(skip=\"feeds\"); gate(flap=false); gate_flap(gate_open); feeds(); e1feed();"),
 "ball_E1cup_in":     ("14.3", saus("let(e=[245.8,103,0]+E1_pin(-52.2), c=[245.8,103,0]+E1_cupball(-52.2)) concat([E1feed[len(E1feed)-1]-[0,0,0.8]], [for (q=[[-12,0,-17.5],[-10.65,0,-17.78],[-9.3,0,-18.6],[-7.95,0,-19.98],[-7.05,0,-21.21]]) e+q], [c])"), "translate([245.8,103,0]) { E1_cup_alone(-52.2); E1_lever_at(-52.2); }"),
 "ball_E2cup_in":     ("14.3", saus("let(e=[262,67,0]+E2_pin(-53.1), c=[262,67,0]+E2cb(-53.1)) concat([E2feed[len(E2feed)-1]-[0,0,0.8]], [for (q=[[-12,0,-17.5],[-10.65,0,-17.78],[-9.3,0,-18.6],[-7.95,0,-19.98],[-7.05,0,-21.21]]) e+q], [c])"), "translate([262,67,0]) { E2_cup_alone(-53.1); E2_lever_at(-53.1); }"),
 "ball_paths_vs_pads":("14.3", saus("down(E1tray)")+saus("down(E1feed)", fn=48)+saus("E2feed")+RAMPS, "pads();"),
 "ball_ramps@12":     ("12",   RAMPS, "static_parts();"),
 "ball_ramps@14.3":   ("14.3", RAMPS, "static_parts();"),
 "ball_ramps@16.5":   ("16.5", RAMPS, "static_parts();"),
 "ball_cage_R":       ("14.3", cagedrop(0), "static_parts();"),
 "ball_cage_L":       ("14.3", cagedrop(1), "static_parts();"),
 "ball_handover_R":   ("14.3", handover(0), "static_parts();"),
 "ball_handover_L":   ("14.3", handover(1), "static_parts();"),
 "ball_handover_R@12":("12",   handover(0), "static_parts();"),
 "ball_handover_L@16.5":("16.5", handover(1), "static_parts();"),
 "E1sweep_vs_static@16.5": ("16.5", E1S, "static_parts(skip=\"e1\", nf=true);"),
 "E2sweep_vs_static@16.5": ("16.5", E2S, "static_parts(skip=\"e2\", nf=true);"),
 # ---- v5 ----
 # fix 4: both elevators together. Grid: each E1 angle against E2 at all its angles (all 23 x 23 pairs), with the
 # cups, floors, latch rollers, counterweights, E2's moving pulley, the E1 cords and the E2 rope.
 "v5_elev_grid_1":    ("14.3", grid(G[0]), "cube(3000, center=true);"),
 "v5_elev_grid_2":    ("14.3", grid(G[1]), "cube(3000, center=true);"),
 "v5_elev_grid_3":    ("14.3", grid(G[2]), "cube(3000, center=true);"),
 # the real timeline: E1 lifts while E2 rests; then E1 stays up while E2 lifts (ropes and cords included)
 "v5_timeline_E1lift":("14.3", "union(){" + "".join(E1M(a) for a in E1A) + "}", f"union(){{ {E2M(-53.1)} }}"),
 "v5_timeline_E2lift":("14.3", E2ALL, f"union(){{ {E1M(52.2)} }}"),
 # ropes and cords against every static part (E2's rope passes its catch flap in the slot), and E2's rope against
 # its own lever, cup and moving pulley at the same angle
 "v5_E2rope_vs_static":("14.3", ROPE2, "static_parts(skip=\"e2\");"),
 "v5_E2rope_vs_E2":   ("14.3", ROPE2SELF, "cube(3000, center=true);"),
 "v5_E1cords_vs_static":("14.3", CORD1, "static_parts(skip=\"e1\");"),
 "v5_gatecord_vs_feeds":("14.3", "gate_cord();", "union(){ feeds(); e1feed(); }"),
 # fix 5 (rule 3.k.v): the two loop tracks touch at the POI: the seam slab w 19.95..20.05 at the POI is solid
 "poi_tracks_touch":  ("14.3", "at_loop() CL_v1();", "at_loop() translate([-2, -6, 19.95]) cube([4, 6, 0.1]);"),
 # fix 7 (rule 4.g): the pencil lies on the start line; the ball at rest is wholly behind it
 "pencil_on_start_line":("14.3", "pencil();", START_PLANE),
 "ball_behind_start": ("14.3", "at_loop() translate(CL_ballstart()) sphere(r=ball_r, $fn=48);", DOWNHILL),
 "v5_lev_wheels_vs_rest":("14.3", "lev_wheels();", "static_parts(skip=\"base\"); base();"),
 "v5_finish_vs_E1rest":("14.3", "union(){ feeds(); finish_line(); }", "translate([245.8,103,0]) E1_moving(-52.2);"),
 # v5 (sim collision engine, 2026-10-28): every ball path against the MOVING parts in their pose at that moment.
 # Loop + E1 feed: both elevators down. E1 lift: E2 down. E1 pour + tray: E1 up (floor tipped), E2 down. Ramps pass 1
 # + gate + E2 feed: E1 up, E2 down. E2 pour + tray: both up. Ramps pass 2 + gate drop + finish: both up, flap open.
 "v5_mov_loop_E1feed": ("14.3", LOOPPATH + saus("down(E1feed)", fn=48), f"union(){{ {E1MB(-52.2)} {E2MB(-53.1)} }}"),
 "v5_mov_E1pour":     ("14.3", saus("E1pour", fn=32) + saus("down(E1tray)"), f"union(){{ {E1MB(52.2)} {E2MB(-53.1)} }}"),
 "v5_mov_pass1":      ("14.3", RAMPS + saus("[rend(18)-[4,0,0], rend(18)+[6,0,-2], [244,16,50.2], E2feed[0]]") + saus("E2feed"), f"union(){{ {E1MB(52.2)} {E2MB(-53.1)} }}"),
 "v5_mov_pass1@16.5": ("16.5", RAMPS + saus("[rend(18)-[4,0,0], rend(18)+[6,0,-2], [244,16,50.2], E2feed[0]]"), "gate(flap=true);"),
 "v5_mov_E2pour":     ("14.3", saus("E2pour", fn=32) + saus("down(E2tray)"), f"union(){{ {E1MB(52.2)} {E2MB(53.1)} }}"),
 "v5_mov_pass2_finish":("14.3", RAMPS + saus("concat([[244,17,49.8]], finish_pts)"), f"union(){{ {E1MB(52.2)} {E2MB(53.1)} gate_flap(gate_open); }}"),
 "v5_E2feed_vs_E2rest":("14.3", saus("E2feed", fn=48), E2MB(-53.1)),
 "v5_gateflap_open":  ("14.3", "difference(){ gate_flap(gate_open); translate(gate_hinge) rotate([-90,0,0]) cylinder(d=2.4, h=80, center=true, $fn=12); }", "static_parts(skip=\"feeds\"); feeds(); e1feed(); gate(flap=false);"),
}
def stl_info(p):
    data = p.read_bytes()
    if data[:5] == b"solid":
        v = [tuple(map(float, l.split()[1:4])) for l in data.decode(errors="ignore").splitlines() if l.strip().startswith("vertex")]
    else:
        nt = struct.unpack("<I", data[80:84])[0]; v = []
        for i in range(nt):
            f = struct.unpack("<12f", data[84+i*50:84+i*50+48]); v += [f[3:6], f[6:9], f[9:12]]
    tris = [v[i:i+3] for i in range(0, len(v), 3)]
    vol = sum((a[0]*(b[1]*c[2]-b[2]*c[1]) - a[1]*(b[0]*c[2]-b[2]*c[0]) + a[2]*(b[0]*c[1]-b[1]*c[0]))/6 for a,b,c in tris)
    xs, ys, zs = zip(*v)
    return abs(vol), (min(xs),max(xs),min(ys),max(ys),min(zs),max(zs))
def pieces(p):
    data = p.read_bytes()
    if data[:5] == b"solid":
        v = [tuple(map(float, l.split()[1:4])) for l in data.decode(errors="ignore").splitlines() if l.strip().startswith("vertex")]
    else:
        nt = struct.unpack("<I", data[80:84])[0]; v = []
        for i in range(nt):
            f = struct.unpack("<12f", data[84+i*50:84+i*50+48]); v += [f[3:6], f[6:9], f[9:12]]
    tris = [v[i:i+3] for i in range(0, len(v), 3)]
    q = lambda a: tuple(round(c, 3) for c in a); par = {}
    def f(a):
        while par.setdefault(a, a) != a: par[a] = par[par[a]]; a = par[a]
        return a
    for a, b, c in tris: par[f(q(a))] = f(q(b)); par[f(q(b))] = f(q(c))
    groups = {}
    for t3 in tris: groups.setdefault(f(q(t3[0])), []).append(t3)
    out = []
    for g in groups.values():
        vol = abs(sum((a[0]*(b[1]*c[2]-b[2]*c[1]) - a[1]*(b[0]*c[2]-b[2]*c[0]) + a[2]*(b[0]*c[1]-b[1]*c[0]))/6 for a,b,c in g))
        xs, ys, zs = zip(*[x for t3 in g for x in t3]); out.append((vol, (min(xs),max(xs),min(ys),max(ys),min(zs),max(zs))))
    return out
def run(name):
    g, A, B = CHECKS[name]
    scad = OUT/f"{re.sub('[^A-Za-z0-9]','_',name)}.scad"; stl = scad.with_suffix(".stl")
    if stl.exists(): stl.rename(OUT/("old_"+stl.name))
    # v5: both sides wrapped in union(): with several statements on one side, intersection() used to intersect them all
    # with each other (always empty), so checks like ball_drop_finish and ball_paths_vs_pads could never fail in v4.
    scad.write_text(f"include <{HERE}/coaster_v1.scad>\npart=\"none\"; gap={g};\nintersection() {{ union() {{ {A} }} union() {{ {B} }} }}\n")
    r = subprocess.run(["openscad", "-o", str(stl), str(scad)], capture_output=True, text=True)
    msg = r.stdout + r.stderr
    empty = "empty" in msg or not stl.exists()
    if name in MUST:
        if empty: return f"FAIL  {name}  (must touch / overlap, but the intersection is empty)"
        vol, bb = stl_info(stl)
        return f"OK    {name}  (touches: {vol:.2f} mm3, x {bb[0]:.1f}..{bb[1]:.1f} y {bb[2]:.1f}..{bb[3]:.1f} z {bb[4]:.1f}..{bb[5]:.1f})"
    if empty: return f"OK    {name}" + ("" if "empty" in msg else "  (no output: " + msg.strip().splitlines()[-1][:80] + ")")
    parts = pieces(stl)
    big = [p for p in parts if p[0] >= 0.5]
    if not big: return f"OK    {name}  (touching only)"
    big.sort(key=lambda p: -p[0])
    return f"HIT   {name}  {sum(p[0] for p in big):.0f} mm3 in {len(big)} piece(s):\n" + "\n".join(
        f"        {p[0]:8.1f} mm3  x {p[1][0]:.1f}..{p[1][1]:.1f}  y {p[1][2]:.1f}..{p[1][3]:.1f}  z {p[1][4]:.1f}..{p[1][5]:.1f}" for p in big[:12])
if __name__ == "__main__":
    args = sys.argv[1:]; jobs = 1
    if args[:1] == ["-j"]: jobs = int(args[1]); args = args[2:]
    names = args or list(CHECKS)
    if jobs == 1:
        for nm in names: print(run(nm), flush=True)
    else:
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(jobs) as ex:
            for line in ex.map(run, names): print(line, flush=True)
