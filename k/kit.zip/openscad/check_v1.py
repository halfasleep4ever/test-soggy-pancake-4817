"""Collision + ball-path checks for coaster_v1.scad (OpenSCAD intersections; empty = no collision).
Run: python3 check_v1.py [name ...]   -> prints one line per check: OK / HIT (volume, bounding box, pieces)."""
import subprocess, sys, os, struct, re
from pathlib import Path
HERE = Path(__file__).resolve().parent
OUT = Path.home()/"Daniel/temp/v1work/chk"; OUT.mkdir(parents=True, exist_ok=True)
E1A = [-52.2 + i*104.4/14 for i in range(15)]
E2A = [-53.1 + i*106.2/14 for i in range(15)]
def sweep(mod, origin, angles): return "union(){" + "".join(f"translate({origin}) {mod}({a:.2f});" for a in angles) + "}"
E1S = sweep("E1_moving", "[245.8,103,0]", E1A)
E2S = sweep("E2_moving", "[262,67,0]", E2A)
E1TOP = "translate([245.8,103,0]) E1_moving(52.2);"
E2REST = "translate([262,67,0]) E2_moving(-53.1);"
LAD = "all_carriages();"
def saus(pts_expr, r="ball_r-0.3", fn=16):
    return f"let(pp={pts_expr}) for (k=[0:len(pp)-2]) hull() {{ translate(pp[k]) sphere(r={r}, $fn={fn}); translate(pp[k+1]) sphere(r={r}, $fn={fn}); }}"
LOOPPATH = "at_loop() " + saus("CL_path()")
# ramps: start 12 mm in (the ball leaves the 6 mm cup tongue there and drops onto the rails at gaps > 12)
RAMPS = ("for (i=[0:n-1]) let(s=i%2?1:-1, o=[0, s*d2/2, -(rod_drop(12)-rod_drop(gap))]) hull() "
         "{ translate(entry(i)+o+[dirOf(i)*(gap>15?16:12),0,0]) sphere(r=ball_r-0.3, $fn=16); translate(rend(i)+o-[dirOf(i)*4,0,0]) sphere(r=ball_r-0.3, $fn=16); }")
def cagedrop(s):   # ball falls down a channel from where it drops in (tray end) to its lowest carriage position
    return f"let(c=CH[{s}], t=[{'E2tray' if s == 0 else 'E1tray'}][0], e=t[len(t)-1]-[0,0,0.8]) hull(){{ translate(e) sphere(r=ball_r-0.3,$fn=16); translate([c[0],c[1],cupEntryZ(c[4][len(c[4])-1])+6]) sphere(r=ball_r-0.3,$fn=16); }}"
def handover(s):   # carriage -> lip -> through the cup's ladder slot -> exit corner, at every ladder position
    sx, sy = ("-1", "1") if s == 0 else ("1", "-1")
    return (f"let(c=CH[{s}]) for (i=c[4]) let(z=cupEntryZ(i)) " +
            saus(f"[[c[0],c[1],z+10], [c[0]+({sx})*8,c[1],z+3], [c[0]+({sx})*16,c[1],z], [c[0]+({sx})*22,c[1]+({sy})*1.0,z-0.8], [c[0]+({sx})*32.2,c[1]+({sy})*2.6,z-2.35]]"))
SKIPMOV = 'static_parts(skip="e1"); '
CHECKS = {
 # static structure
 "stack_vs_rest@12":  ("12",   "stack();", "static_parts(skip=\"stack\");"),
 "stack_vs_rest@16.5":("16.5", "stack();", "static_parts(skip=\"stack\");"),
 "ladder_vs_rest":    ("14.3", "union(){ cage(0); cage(1); tops(); }", "static_parts(skip=\"ladder\");"),
 "carriages@12":      ("12",   LAD, "static_parts();"),
 "carriages@16.5":    ("16.5", LAD, "static_parts();"),
 "flaps_vs_rest":     ("14.3", "flaps();", "static_parts(skip=\"flaps\");"),
 "feeds_vs_rest":     ("14.3", "union(){ gate(); feeds(); e1feed(); }", "static_parts(skip=\"feeds\");"),
 "loop_vs_rest":      ("14.3", "union(){ at_loop() CL_v1(); loop_board(); }", "static_parts(skip=\"loop\");"),
 # elevators swept over their lift (the flaps are lifted by the cups: checked at the top only)
 "E1sweep_vs_static": ("14.3", E1S, "static_parts(skip=\"e1\", nf=true);"),
 "E1sweep_vs_E1static":("14.3", E1S, "translate([245.8,103,0]) E1_static();"),
 "E1sweep_vs_E2rest": ("14.3", E1S, E2REST),
 "E1sweep_vs_carriages":("14.3", E1S, LAD),
 "E2sweep_vs_static": ("14.3", E2S, "static_parts(skip=\"e2\", nf=true);"),
 "E2sweep_vs_E2static":("14.3", E2S, "translate([262,67,0]) E2_static();"),
 "E2sweep_vs_E1top":  ("14.3", E2S, E1TOP),
 "E2sweep_vs_carriages":("14.3", E2S, LAD),
 "E1top_vs_flaps":    ("14.3", E1TOP, "flaps();"),
 "E2top_vs_flaps":    ("14.3", "translate([262,67,0]) E2_moving(53.1);", "flaps();"),
 # ball paths (ball 0.3 mm undersize): must touch nothing
 "ball_loop":         ("14.3", LOOPPATH, "static_parts(skip=\"loop\");"),
 "ball_loop_self":    ("14.3", LOOPPATH, "at_loop() CL_v1();"),
 "ball_E1feed":       ("14.3", saus("down(E1feed)", fn=48), "static_parts();"),   # fine ball: it starts where the loop lane ends
 "ball_E1pour":       ("14.3", saus("E1pour"), "static_parts();"),
 "ball_E1tray":       ("14.3", saus("down(E1tray)"), "static_parts();"),
 "ball_E2pour":       ("14.3", saus("E2pour"), "static_parts();"),
 "ball_E2tray":       ("14.3", saus("down(E2tray)"), "static_parts();"),
 "ball_gate_in":      ("14.3", saus("[rend(18)-[4,0,0], rend(18)+[6,0,-2], [244,16,50.2], E2feed[0]]"), "static_parts();"),
 "ball_E2feed":       ("14.3", saus("E2feed"), "static_parts();"),
 "ball_drop_finish":  ("14.3", saus("concat([[244,17,49.8]], finish_pts)"), "static_parts(skip=\"feeds\"); gate(flap=false); feeds(); e1feed();"),
 "ball_E1cup_in":     ("14.3", saus("let(c=[245.8,103,0]+E1_cupball(-52.2)) [E1feed[len(E1feed)-1]-[0,0,0.8], c+[-9,-0.2,4.4], c+[-3,0,2], c]"), "translate([245.8,103,0]) { E1_cup_alone(-52.2); E1_lever_at(-52.2); }"),
 "ball_E2cup_in":     ("14.3", saus("let(c=[262,67,0]+E2cb(-53.1)) [E2feed[len(E2feed)-1]-[0,0,0.8], c+[-9,0,4.4], c+[-3,0,2], c]"), "translate([262,67,0]) { E2_cup_alone(-53.1); E2_lever_at(-53.1); }"),
 "ball_ramps@12":     ("12",   RAMPS, "static_parts();"),
 "ball_ramps@14.3":   ("14.3", RAMPS, "static_parts();"),
 "ball_ramps@16.5":   ("16.5", RAMPS, "static_parts();"),
 "ball_cage_R":       ("14.3", cagedrop(0), "static_parts();"),
 "ball_cage_L":       ("14.3", cagedrop(1), "static_parts();"),
 "ball_handover_R":   ("14.3", handover(0), "static_parts();"),
 "ball_handover_L":   ("14.3", handover(1), "static_parts();"),
 "ball_handover_R@12":("12",   handover(0), "static_parts();"),
 "ball_handover_L@16.5":("16.5", handover(1), "static_parts();"),
 "E1sweep_vs_static@16.5": ("16.5", E1S, "static_parts(skip=\"e1\", nf=true);"),
 "E2sweep_vs_static@16.5": ("16.5", E2S, "static_parts(skip=\"e2\", nf=true);"),
}
def stl_info(p):
    data = p.read_bytes()
    if data[:5] == b"solid":
        v = [tuple(map(float, l.split()[1:4])) for l in data.decode(errors="ignore").splitlines() if l.strip().startswith("vertex")]
    else:
        nt = struct.unpack("<I", data[80:84])[0]; v = []
        for i in range(nt):
            f = struct.unpack("<12f", data[84+i*50:84+i*50+48]); v += [f[3:6], f[6:9], f[9:12]]
    tris = [v[i:i+3] for i in range(0, len(v), 3)]
    vol = sum((a[0]*(b[1]*c[2]-b[2]*c[1]) - a[1]*(b[0]*c[2]-b[2]*c[0]) + a[2]*(b[0]*c[1]-b[1]*c[0]))/6 for a,b,c in tris)
    xs, ys, zs = zip(*v)
    return abs(vol), (min(xs),max(xs),min(ys),max(ys),min(zs),max(zs))
def pieces(p):
    data = p.read_bytes()
    if data[:5] == b"solid":
        v = [tuple(map(float, l.split()[1:4])) for l in data.decode(errors="ignore").splitlines() if l.strip().startswith("vertex")]
    else:
        nt = struct.unpack("<I", data[80:84])[0]; v = []
        for i in range(nt):
            f = struct.unpack("<12f", data[84+i*50:84+i*50+48]); v += [f[3:6], f[6:9], f[9:12]]
    tris = [v[i:i+3] for i in range(0, len(v), 3)]
    q = lambda a: tuple(round(c, 3) for c in a); par = {}
    def f(a):
        while par.setdefault(a, a) != a: par[a] = par[par[a]]; a = par[a]
        return a
    for a, b, c in tris: par[f(q(a))] = f(q(b)); par[f(q(b))] = f(q(c))
    groups = {}
    for t3 in tris: groups.setdefault(f(q(t3[0])), []).append(t3)
    out = []
    for g in groups.values():
        vol = abs(sum((a[0]*(b[1]*c[2]-b[2]*c[1]) - a[1]*(b[0]*c[2]-b[2]*c[0]) + a[2]*(b[0]*c[1]-b[1]*c[0]))/6 for a,b,c in g))
        xs, ys, zs = zip(*[x for t3 in g for x in t3]); out.append((vol, (min(xs),max(xs),min(ys),max(ys),min(zs),max(zs))))
    return out
def run(name):
    g, A, B = CHECKS[name]
    scad = OUT/f"{re.sub('[^A-Za-z0-9]','_',name)}.scad"; stl = scad.with_suffix(".stl")
    if stl.exists(): stl.rename(OUT/("old_"+stl.name))
    scad.write_text(f"include <{HERE}/coaster_v1.scad>\npart=\"none\"; gap={g};\nintersection() {{ {A} {B} }}\n")
    r = subprocess.run(["openscad", "-o", str(stl), str(scad)], capture_output=True, text=True)
    msg = r.stdout + r.stderr
    if "empty" in msg or not stl.exists(): return f"OK    {name}" + ("" if "empty" in msg else "  (no output: " + msg.strip().splitlines()[-1][:80] + ")")
    parts = pieces(stl)
    big = [p for p in parts if p[0] >= 0.5]
    if not big: return f"OK    {name}  (touching only)"
    big.sort(key=lambda p: -p[0])
    return f"HIT   {name}  {sum(p[0] for p in big):.0f} mm3 in {len(big)} piece(s):\n" + "\n".join(
        f"        {p[0]:8.1f} mm3  x {p[1][0]:.1f}..{p[1][1]:.1f}  y {p[1][2]:.1f}..{p[1][3]:.1f}  z {p[1][4]:.1f}..{p[1][5]:.1f}" for p in big[:12])
names = sys.argv[1:] or list(CHECKS)
for nm in names: print(run(nm), flush=True)
