// v1.6 (elevators): export one Elevator 1 part in its print pose. openscad --backend=Manifold -D 'pk="e1_frame"' v16e_e1.scad
// Keys: see E1_print() in coaster_e1.scad. Steel, pads and cords are not in these parts.
include <coaster_e1.scad>
part = "none";
pk = "e1_frame";
E1_print(pk);
