// v1.7 J58 picture: the gate cord route (white, thick) and its 3 printed guides (red) in the lower stack area
include <coaster_v1.scad>
part = "none";
color("#d0d0d0", 0.35) intersection() { union() { base_plate(); stack(); gate(); feeds(); v17_feed_stands(); e2_bracket(); cage(0); }
    translate([100, -20, -10]) cube([220, 120, 90]); }
translate([262,67,0]) intersection() { E2_v1(e2a); translate([-170, -90, -10]) cube([200, 100, 250]); }
color("#d47272") cord_guides();
color("white") gate_cord(e2a, 1.0);
