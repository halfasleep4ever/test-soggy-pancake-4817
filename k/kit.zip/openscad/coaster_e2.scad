// Coaster v1 wrapper for Elevator 2 (Type 2). Rig parts from elevator2_test.scad (lever, cup, latch, pulleys, yoke),
// placed for the full coaster:
//  - fulcrum tower IN FRONT of the lever (rig y +8..+16 = world Y 95..103),
//  - rope (v5): lever end -> up over P1 -> level left over P3 -> down round the moving pulley P2 -> up to the anchor,
//    all in the lever plane (world Y 67). P2 and a slim counterweight pot hang at world X 80, Y 67.
// coaster_v1.scad places it at world (262, 67, 0) (the BACK elevator: fed by the bottom gate). Its latch is the rig's,
// in front of the lever (world Y 81..89).
include <elevator2_test.scad>
horn_s = 1;                   // E2's horn is on +y: its ball pours toward -y
crank_y0 = 14; crank_y1 = 18; roller_y = 16.25;   // v3: latch 1 mm further out (the E2 feed's foam corner passes at Y 79.7)
part2 = "none";
// v1: longer lever so the lift reaches the top ladder position (rig: cup 195 / rope 215 -> 223 / 245.4, lift about 357)
A = 223; EF = A + 8;   // v4: rope point 8 mm past the cup pin, lever straight (G2 = 0): the top pulley can sit 30 mm lower
G2 = 0;
E2_ORIGIN = [262, 67, 0];
// (2026-10-27) the lever end is bent 7 deg up (v3: the rig lever too, see elevator2_test.scad)
module lever2_v1() lever2();
// v5 (2026-10-28): the v4 rope ran from P1 (Y 67) slanting forward to the moving pulley at world Y 134. It crossed
// Elevator 1's cup sweep (lever 22..52 deg) and E1's tip cam: that is the overlap Kai saw. Now the whole rope stays in
// E2's own lever plane (world Y 67), above everything at the top:
//   lever end -> up the RIGHT side of P1 -> over its top -> level to the left along Z 441 (above both elevators) ->
//   over P3 (world X 99.6, on a bracket on the stack's front top beam) -> down round the moving pulley P2 -> up to the
//   anchor. P2 and the slim pot hang at world X 80, Y 67, in front of the stack and behind the loop, clear of E1.
// The two top pulleys only turn the rope: the pulley IMA stays 0.5 (P2 is the only moving pulley).
rr = 9.8;                                    // rope centre radius in a pulley groove (groove bottom 9.2, rim 10.5)
P1v = [EN(SW)[0] - rr, 0, EN(SW)[2] + 14];   // the rope comes up its right side at the lever end's top X
P3v = [99.6 - E2_ORIGIN[0], 0, P1v[2]];      // second top pulley
P2x = P3v[0] - 2*rr; P2y = 0;                // moving pulley: hangs from P3's left side
P2topv = P1v[2] - 30;
anchor = [P2x - rr, 0, P1v[2] + 5];
function E2_up(a) = EN(a)[2] - EN(-SW)[2];
function E2_p2(a) = [P2x, P2y, P2topv - E2_up(a)/2];
// rope path (rig coordinates) at lever angle a: lever end -> tangent on P1 -> arc over P1 -> P3 -> P2 -> anchor
function _tan_r(q, c) = let(d=[q[0]-c[0], q[2]-c[2]], L=norm(d), ph=atan2(d[1], d[0]), b=acos(rr/L)) ph + b;
function _arc(c, a0, a1) = [for (k=[0:8]) let(t=a0+(a1-a0)*k/8) c + rr*[cos(t), 0, sin(t)]];
function E2_rope_pts(a) = let(q=EN(a), t1=_tan_r(q, P1v), p2=E2_p2(a))
    concat([q], _arc(P1v, t1, 90), _arc(P3v, 90, 180), _arc(p2, 0, -180), [anchor]);
module E2_rope(a, r=0.5) let(p=E2_rope_pts(a)) for (k=[0:len(p)-2]) hull() { translate(p[k]) sphere(r, $fn=8); translate(p[k+1]) sphere(r, $fn=8); }
module cw_pot_slim() difference() {                         // about 100 g: steel nuts, 16 mm pot (fits beside the channel)
    union() { cylinder(d=18, h=80, $fn=40); translate([-9,-2,74]) cube([18,4,6]); }
    translate([0,0,2]) cylinder(d=15, h=90, $fn=40); translate([0,0,77]) rotate([90,0,0]) cylinder(d=3, h=10, center=true);
}
module E2_tower() difference() {                            // in front of the lever: rig y +5..+13 = world Y 72..80
    union() {
        translate([F[0]-20, 5, 0]) cube([40, 8, F[2]+14]);
        translate([F[0]-20, 5, 0]) cube([40, 20, 8]);
        translate([F[0]-3, 13, 8]) rotate([90,0,90]) linear_extrude(6) polygon([[0,0],[12,0],[0,50]]);
    }
    translate([F[0], 0, F[2]]) rotate([-90,0,0]) cylinder(d=pin_hole-0.15, h=40);
    for (x=[F[0]-12, F[0]+12]) translate([x, 20, -1]) cylinder(d=m3_clear, h=10, $fn=20);
    // v5: two triangle windows (6 mm legs and one 6 mm diagonal stay), so the ramps behind show from the front.
    // The label moved to the P3 bracket at the top (6 mm text, in view).
    let(x0=F[0]-14, x1=F[0]+14, z0=14, z1=F[2]-16, k=6*sqrt(2)) translate([0, 4, 0]) rotate([90,0,0]) mirror([0,0,1]) linear_extrude(10) {
        polygon([[x0, z0+k], [x0, z1], [x1-k*(x1-x0)/(z1-z0), z1]]);
        polygon([[x0+k*(x1-x0)/(z1-z0), z0], [x1, z0], [x1, z1-k]]);
    }
}
module E2_v1(a=-53.1, ball=false) {
    color("#59646f") E2_tower();
    color("#59a5c4") translate(F) rotate([0,-a,0]) rotate([90,0,0]) lever2_v1();
    color("#59a5c4") cup_tipped(a);
    if (ball) color("silver") translate(ball_top_seat(a)) sphere(r=ball_r, $fn=32);
    let(r=[F[0]+R_local*cos(a), 0, F[2]+R_local*sin(a)]) color("silver") translate([r[0], roller_y, r[2]]) rotate([90,0,0]) cylinder(r=roller_r, h=2.5, center=true);
    color("#d08a4a") translate(H) { crank(); trip_pin(); }
    color("#4a5360") latch_post_v1();
    color("#d08a4a") { translate(P1v) pulley(); translate(P3v) pulley(); }
    p2 = E2_p2(a);
    color("#d08a4a") translate(p2) { pulley(); p2_block(); }
    color("#9aa3ad") translate([p2[0], p2[1], p2[2]-18-82]) cw_pot_slim();
    color("white") E2_rope(a);
}
module E2_cup_at(a) translate(E(a)) { cup_asm(cup_tilt(a)); translate(about_pv(cup_seat, cup_tilt(a))) sphere(r=ball_r, $fn=24); }
module E2_lever_at(a) translate(F) rotate([0,-a,0]) rotate([90,0,0]) lever2_v1();
module E2_pot_at(a) let(p2=E2_p2(a)) translate([p2[0], p2[1], p2[2]-18-82]) cw_pot_slim();
function E2_P3() = P3v;
function E2_rope_pt(a) = EN(a);
E2_SW = SW; E2_P1 = P1v; E2_anchor = anchor;
function E2cb(a) = E(a) + cup_seat;
function E2_info() = [F, P1v, anchor, SW, A, EF, R_local, P3v];
module latch_post_v1() intersection() { translate([H[0],0,0]) latch_post(); translate([-500,-500,0]) cube(1000); }   // no tenon on the plywood
module E2_static() { E2_tower(); translate(H) { crank(); trip_pin(); } latch_post_v1(); translate(P1v) pulley(); translate(P3v) pulley(); }
module E2_roller_at(a) let(r=[F[0]+R_local*cos(a), 0, F[2]+R_local*sin(a)]) translate([r[0], roller_y, r[2]]) rotate([90,0,0]) cylinder(r=roller_r, h=2.5, center=true);
module E2_moving(a) { E2_lever_at(a); E2_cup_at(a); E2_roller_at(a); let(p2=E2_p2(a)) translate(p2) { pulley(); p2_block(); } E2_pot_at(a); }
module E2_cup_alone(a) cup_tipped(a);                // cup without the ball (ball-entry check)
// for the Fusion v2 export: cup pin, rope point, moving pulley position at lever angle a (rig coordinates)
function E2_pin(a) = E(a);
function E2_p2pos(a) = E2_p2(a);
module E2_p2_at(a) let(p2=E2_p2(a)) translate(p2) { pulley(); p2_block(); }
module E2_static_parts() { E2_static(); }
// v3: the horn pin path and the cup tilt (the tip cam in coaster_v1.scad follows the pin)
function E2_hornpin(a) = horn_pin(a);
function E2_tilt(a) = cup_tilt(a);
function E2_tipspan() = tip_span;
// ball at the top in the tipped cup: on the seat, and at the open end of the floor (rig coordinates)
function E2_topseat() = ball_top_seat(SW);
function E2_topend()  = ball_top_end(SW);
module E2_static_nt() { E2_tower(); translate(H) crank(); latch_post_v1(); translate(P1v) pulley(); translate(P3v) pulley(); }   // without the trip pin
module E2_trip_at() translate(H) trip_pin();
function E2_cupseat() = cup_seat;  function E2_cuppv() = Pv;  function E2_flrot() = fl_rot;
module E2_cupframe() cup_frame();
module E2_cupfloor() { cup_floor(); horn_pin_part(0); color("silver") translate(Pv) rotate([90,0,0]) cylinder(d=3, h=25.2, center=true, $fn=12); }
function E2_G2() = G2;
// v5b: side pour toward -y onto the fixed catch funnel (coaster_v1.scad e2_funnel), rig coordinates. f(x, y) = funnel
// top z at rig (x, y); tg = points after the landing.
function E2_pour(f, tg) = pour_pts(f, tg);
function E2_land(f) = pour_land(f);
function E2_edge() = pour_edge();
function E2_ballat(a) = ball_top_seat(a);
