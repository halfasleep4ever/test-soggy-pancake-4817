// Coaster v1 wrapper for Elevator 2 (Type 2). Rig parts from elevator2_test.scad (lever, cup, latch, pulleys, yoke),
// placed for the full coaster:
//  - fulcrum tower IN FRONT of the lever (rig y +8..+16 = world Y 95..103),
//  - compact rope: lever end -> up over P1 (above the rope point's top) -> forward/right down to the moving pulley P2
//    -> up to the anchor. P2 and a slim counterweight pot hang at world X 280, Y 145 (in front of the ladder channel).
// coaster_v1.scad places it at world (262, 67, 0) (the BACK elevator: fed by the bottom gate). Its latch is the rig's,
// in front of the lever (world Y 81..89).
G2 = 7;                       // E2 lever end bent up 7 deg (see below); set before the include: the rig file calls EN()
include <elevator2_test.scad>
part2 = "none";
// v1: longer lever so the lift reaches the top ladder position (rig: cup 195 / rope 215 -> 223 / 245.4, lift about 357)
A = 223; EF = 245.4;
E2_ORIGIN = [262, 67, 0];
// (2026-10-27) the rig's lever runs straight on past the cup pin to the rope point; at rest (-53 deg) that part goes
// down-right through the cup and the ball. v1 bends the last part 7 deg up: the rope point stays EF from the fulcrum
// (same lever ratio), but sits 7 deg ahead of the cup pin, so the bent part passes over the cup at rest (and over the
// cup at the top, where it points up-left).
function EN(a) = [F[0]+EF*cos(a+G2), 0, F[2]+EF*sin(a+G2)];
module lever2_v1() difference() {
    union() {
        cylinder(d=18, h=8, center=true);
        hull() { cylinder(d=14, h=5.8, center=true); translate([A,0,0]) cylinder(d=9, h=5.8, center=true); }
        hull() { translate([A,0,0]) cylinder(d=9, h=5.8, center=true); translate([EF*cos(G2), EF*sin(G2), 0]) cylinder(d=9, h=5.8, center=true); }
        translate([R_local,0,0]) cylinder(d=9, h=6, center=true);
    }
    cylinder(d=4.5, h=20, center=true);
    for (z=[-4.01, 4.01-brg_h]) translate([0,0,z]) brg_pocket();
    translate([A,0,0]) cylinder(d=pin_hole+0.3, h=20, center=true);
    translate([R_local,0,0]) cylinder(d=pin_hole-0.15, h=20, center=true);
    translate([(EF-2.5)*cos(G2), (EF-2.5)*sin(G2), 0]) cylinder(d=2.2, h=20, center=true);
    translate([60,0,2.4]) linear_extrude(1.5) text("ELEVATOR 2 - TYPE 2", size=4.5, valign="center");   // rule label, in view
}
P1v = [EN(SW)[0]+9, 0, EN(SW)[2]+25];                     // world (267.1, 87, 406.9)
P2x = 290 - E2_ORIGIN[0]; P2y = 134 - E2_ORIGIN[1];        // moving pulley track (world X 290, Y 134: right of the ladder channel)
P2topv = P1v[2] - 30;
anchor = [P2x + 9, P2y, P1v[2] + 5];
function E2_up(a) = EN(a)[2] - EN(-SW)[2];
function E2_p2(a) = [P2x, P2y, P2topv - E2_up(a)/2];
module cw_pot_slim() difference() {                         // about 100 g: steel nuts, 16 mm pot (fits beside the channel)
    union() { cylinder(d=18, h=80, $fn=40); translate([-9,-2,74]) cube([18,4,6]); }
    translate([0,0,2]) cylinder(d=15, h=90, $fn=40); translate([0,0,77]) rotate([90,0,0]) cylinder(d=3, h=10, center=true);
}
module E2_tower() difference() {                            // in front of the lever: rig y +5..+13 = world Y 72..80
    union() {
        translate([F[0]-20, 5, 0]) cube([40, 8, F[2]+14]);
        translate([F[0]-20, 5, 0]) cube([40, 20, 8]);
        translate([F[0]-3, 13, 8]) rotate([90,0,90]) linear_extrude(6) polygon([[0,0],[12,0],[0,50]]);
    }
    translate([F[0], 0, F[2]]) rotate([-90,0,0]) cylinder(d=pin_hole-0.15, h=40);
    for (x=[F[0]-12, F[0]+12]) translate([x, 20, -1]) cylinder(d=m3_clear, h=10, $fn=20);
    translate([F[0]+4, 13.4, 30]) rotate([90,-90,0]) linear_extrude(1) text("ELEVATOR 2  TYPE 2", size=5.5);  // label (cut through the face)
}
module E2_v1(a=-53.1, ball=false) {
    color("#59646f") E2_tower();
    color("#59a5c4") translate(F) rotate([0,-a,0]) rotate([90,0,0]) lever2_v1();
    color("#59a5c4") translate(E(a)) cup();
    if (ball) color("silver") translate([E(a)[0]+3, 0, E(a)[2]-cup_drop]) sphere(r=ball_r, $fn=32);
    let(r=[F[0]+R_local*cos(a), 0, F[2]+R_local*sin(a)]) color("silver") translate([r[0], roller_y, r[2]]) rotate([90,0,0]) cylinder(r=roller_r, h=2.5, center=true);
    color("#d08a4a") translate(H) crank();
    color("#4a5360") latch_post_v1();
    color("#d08a4a") translate(P1v) pulley();
    p2 = E2_p2(a);
    color("#d08a4a") translate(p2) { rotate([0,0,90]) pulley(); rotate([0,0,90]) p2_block(); }
    color("#9aa3ad") translate([p2[0], p2[1], p2[2]-18-82]) cw_pot_slim();
    en = EN(a);
    color("white") { hull() { translate(en) sphere(0.5); translate([P1v[0]-9,0,P1v[2]]) sphere(0.5); }
                     hull() { translate([P1v[0],0,P1v[2]+10.5]) sphere(0.5); translate([p2[0]-9,p2[1],p2[2]]) sphere(0.5); }
                     hull() { translate([p2[0]+9,p2[1],p2[2]]) sphere(0.5); translate(anchor) sphere(0.5); } }
}
module E2_cup_at(a) translate(E(a)) { cup(); translate([3,0,-cup_drop]) sphere(r=ball_r, $fn=24); }
module E2_lever_at(a) translate(F) rotate([0,-a,0]) rotate([90,0,0]) lever2_v1();
module E2_pot_at(a) let(p2=E2_p2(a)) translate([p2[0], p2[1], p2[2]-18-82]) cw_pot_slim();
function E2_rope_pt(a) = EN(a);
E2_SW = SW; E2_P1 = P1v; E2_anchor = anchor;
function E2cb(a) = [E(a)[0]+3, 0, E(a)[2]-cup_drop];
function E2_info() = [F, P1v, anchor, SW, A, EF, R_local];
module latch_post_v1() intersection() { translate([H[0],0,0]) latch_post(); translate([-500,-500,0]) cube(1000); }   // no tenon on the plywood
module E2_static() { E2_tower(); translate(H) crank(); latch_post_v1(); translate(P1v) pulley(); }
module E2_moving(a) { E2_lever_at(a); E2_cup_at(a); let(p2=E2_p2(a)) translate(p2) { rotate([0,0,90]) pulley(); rotate([0,0,90]) p2_block(); } E2_pot_at(a); }
module E2_cup_alone(a) translate(E(a)) cup();                // cup without the ball (ball-entry check)
// for the Fusion v2 export: cup pin, rope point, moving pulley position at lever angle a (rig coordinates)
function E2_pin(a) = E(a);
function E2_p2pos(a) = E2_p2(a);
module E2_p2_at(a) let(p2=E2_p2(a)) translate(p2) { rotate([0,0,90]) pulley(); rotate([0,0,90]) p2_block(); }
module E2_static_parts() { E2_tower(); translate(H) crank(); latch_post_v1(); translate(P1v) pulley(); }
