// Layout for the simulator's V3 design: every ball path and mechanism number, straight from the CAD (world mm).
// Run: python3 export_sim.py (writes ../sims/v3_layout.js). One ECHO line, JSON after "SIMJSON=".
include <coaster_v1.scad>
part = "none";
function lw(p) = [POIx + p[0], loopY0 + p[2], POIz + p[1]];           // loop frame (x, y up, w) -> world
echo(str("SIMJSON=", [
  ["ball_r", ball_r], ["n", n], ["th", th], ["Lr", Lr], ["drop", drop], ["planeY", planeY],
  ["entries", [for (i=[0:n-1]) entry(i)]], ["rends", [for (i=[0:n-1]) rend(i)]], ["cupEntryZ", [for (i=[0:n-1]) cupEntryZ(i)]],
  ["chR", [CH[0][0], CH[0][1], CH[0][2], CH[0][3]]], ["chL", [CH[1][0], CH[1][1], CH[1][2], CH[1][3]]], ["ladR", CH[0][4]], ["ladL", CH[1][4]],
  ["loop", [for (p=CL_path()) lw(p)]], ["loopR", CL_info()[0]], ["loopNc", CL_info()[6]], ["ridgeGap", 2*6],
  ["E1feed", down(E1feed)], ["E1feedPads", [1, 4]], ["E2feedPads", [4]],
  ["E1O", E1O], ["E1P", E1_info()[0]], ["E1A", E1_info()[6]], ["E1SW", E1_info()[7]], ["E1LS", 50], ["E1drum", [10, 25]],
  ["E1seat", E1O + E1_cupball(-E1_info()[7])], ["E1cwdrop", E1_info()[5]], ["E2G2", E2_G2()], ["E1top", E1top], ["E1end", E1end],
  ["E1pour", E1pour], ["E1tray", down(E1tray)], ["E1trayPads", [1, 4]],
  ["E2O", E2O], ["E2F", E2_info()[0]], ["E2A", E2_info()[4]], ["E2EF", E2_info()[5]], ["E2SW", E2_info()[3]],
  ["E2seat", E2O + E2cb(-E2_info()[3])], ["E2top", E2top], ["E2end", E2end],
  ["E2pour", E2pour], ["E2tray", down(E2tray)],
  ["gateIn", [rend(18)-[4,0,0], rend(18)+[6,0,-2], [244,16,50.2], E2feed[0]]], ["E2feed", down(E2feed)],
  ["finish", concat([[244,17,49.8]], down(finish_pts))], ["finishY", finish_y + ball_r], ["finishLine", finish_y],   // v5: timed until the ball has fully crossed the line at Y 118
  ["gateFlap", gate_flap_info()],                                                           // v5: [hinge point, axis, open angle (deg)]
  ["pegGaps", concat([for (k=[0:9]) pg_gapA(k)], [for (k=[0:8]) pg_gapB(k)])], ["pegHoles", concat([for (k=[0:9]) [0, k, pg_holeX(0, k), pg_gapA(k), pg_s(pg_gapA(k))]], [for (k=[0:8]) [1, k, pg_holeX(1, k), pg_gapB(k), pg_s(pg_gapB(k))]])],   // v5b fix 3: peg plate holes: gap per hole (mm); [row, n, hole X, gap, slide travel]
  ["pegSlide", [pg_k, pg_xp]],
  ["E2funnel", [e2H, e2Hz, e2tb, e2hole]],                                               // v5b: no catch flaps; E2 catch funnel [centre, top z at the centre, slope (tan), hole r]
  ["E2P1", E2O + E2_info()[1]], ["E2P3", E2O + E2_info()[7]], ["E2anchor", E2O + E2_info()[2]], ["E2P2", E2O + E2_p2(0)], ["E2EN0", E2O + EN(0)],   // v5 rope: lever end, P1, P3, P2 (lever at 0 deg), anchor; rope radius in the groove = (P3 - P2)/2 in X
  ["cupSeat", E1_cupseat()], ["cupPv", E1_cuppv()], ["flRot", E1_flrot()], ["tipSpan", E1_tipspan()], ["tripX", -14],
  ["box", [Lx0, L, Wy0, Wy1]]
]));
