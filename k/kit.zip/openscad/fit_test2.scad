// FIT TEST 2 (2026-10-29, after drying the PETG): fit test 1's smallest rod groove (3.15) let the rod wobble,
// so this coupon goes tighter. About 10 min, PETG on filament 3.
// Row 1 (front): rod grooves 2.95 / 3.00 / 3.05 / 3.10, open on top like the spines: press a 3 mm rod in from above.
//   Best = the rod sits fully down with no wobble (a click is a bonus: the rods are glued with CA anyway).
// Row 2 (back): 3 mm pin SLIP holes 3.25 / 3.30 / 3.35 / 3.40 (the peg-plate lock pin, pulled out at the event).
//   Best = the smallest hole where the pin slides in and out by hand without sticking.
// Row 3 (back edge): HORIZONTAL teardrop pin holes 3.05 / 3.15 / 3.25 / 3.35, 11 mm deep, point up: push a 3 mm pin in from
//   the back face. Many parts print their pin holes lying down (cup pins, cage rods, comb-frame pins), and a lying
//   hole prints a different shape from a standing one, so it gets its own test. Best = firm push, stays in.
include <common.scad>
L = 52; W = 42; H = 6;
cut_h = 0.335;                     // the same groove opening plane as fit test 1 and the spines
xs = [8, 20, 32, 44];
// horizontal hole along Y with a 45 degree point on top (self-supporting roof), as the parts' tdrop_y(..., up=true)
module tdrop_up_y(d, h) rotate([90,0,0]) linear_extrude(h, center=true) hull() { circle(d=d, $fn=48); translate([0, d/2*sqrt(2)]) square(0.02, center=true); }
difference() {
    cube([L, W, H]);
    for (k=[0:3]) let(d=[2.95, 3.00, 3.05, 3.10][k]) {
        translate([xs[k], 6, H - cut_h]) rotate([0,0,90]) teardrop_x(d, 16);
        translate([xs[k] + 2.2, 8, H - 0.4]) linear_extrude(1) text(str(d), size=2.6, halign="left", valign="bottom");
    }
    for (k=[0:3]) let(d=[3.25, 3.30, 3.35, 3.40][k]) {
        translate([xs[k], 22, 1.2]) cylinder(d=d, h=H, $fn=48);
        translate([xs[k] - 3.5, 25.2, H - 0.4]) linear_extrude(1) text(str(d), size=2.6, halign="left");
    }
    for (k=[0:3]) let(d=[3.05, 3.15, 3.25, 3.35][k]) {
        translate([xs[k], W, 3]) tdrop_up_y(d, 22);                                    // y W-11..W+11: 11 mm into the back face, point up
        translate([xs[k] - 3.5, 36.2, H - 0.4]) linear_extrude(1) text(str(d), size=2.6, halign="left");
    }
}
