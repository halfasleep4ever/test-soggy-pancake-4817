// v1.7t (stack integration) FEA assemblies in WORLD pose (bonded pieces), for cad/fea/v17t_cases.py. fk = assembly key.
include <v16_stack_parts.scad>
fk = "none";
if (fk=="brk_t")      { e2_bracket_lo(); e2_bracket_hi(); e2_bracket_beam(); p1_strut(); ledge_hanger(); }   // 38a+38b+38c+38d+38e
if (fk=="tray_t")     { tray_e1_a(); tray_e1_b(); ledge_hanger(); }                                          // 25a+25b+38e (saddle bonded)
if (fk=="top_t")      { frame_ladder(1); fr_strip(0); fr_strip(1); p3_bracket(); p1_strut(); }               // 06b+06i/j+40+38d
if (fk=="gate_box_t") gate(flap=false);
if (fk=="flap_t")     gate_flap_part();
if (fk=="crank_t")    gate_crank();
if (fk=="guide62_t")  cord_guide_c();
