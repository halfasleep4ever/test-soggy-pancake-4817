// v1.6 (elevators): export one Elevator 2 part in its print pose. openscad --backend=Manifold -D 'pk="e2_tower"' v16e_e2.scad
// Keys: see E2_print() in coaster_e2.scad.
include <coaster_e2.scad>
part = "none"; part2 = "none";
pk = "e2_tower";
E2_print(pk);
