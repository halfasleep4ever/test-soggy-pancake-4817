// FIT TEST: one small PLA/PETG coupon that checks every press fit in the kit before the long prints (about 20 min).
// Row 1: rod grooves 3.15 / 3.25 / 3.35 (kit = 3.25), each open on top like the spines: press a 3 mm rod in from above.
// Row 2: 3 mm pin holes 3.15 / 3.25 / 3.35 (kit = 3.25).  Row 3: MR63 bearing seats 6.0 / 6.1 / 6.2 (kit = 6.1), M3 nut pockets 6.6 / 6.8.
// Pick the size in each row that fits best; if it is not the kit size, tell Claude and the parts get changed before printing.
include <common.scad>
L = 64; W = 46; H = 8;
cut_h = 0.335;                     // the groove opening plane: 3.18 mm wide for the 3.25 groove, the same as on the spines
xs = [12, 32, 52];
difference() {
    cube([L, W, H]);
    for (k=[0:2]) let(d=[3.15, 3.25, 3.35][k]) {
        // row 1: rod groove along Y at the top, centre 1.6 mm + cut_h below the top face
        translate([xs[k], 6, H - cut_h]) rotate([0,0,90]) teardrop_x(d, 16);
        translate([xs[k] + 3, 8, H - 0.4]) linear_extrude(1) text(str(d), size=2.6, halign="left", valign="bottom");
        // row 2: pin holes
        translate([xs[k], 24, 1.2]) cylinder(d=d, h=H, $fn=48);
        translate([xs[k] + 3, 20.5, H - 0.4]) linear_extrude(1) text(str(d), size=2.6, halign="left");
    }
    for (k=[0:2]) let(d=[6.0, 6.1, 6.2][k]) {
        translate([8 + k*13, 38, H - brg_h]) cylinder(d=d, h=brg_h + 1, $fn=64);
        translate([4 + k*13, 42.4, H - 0.4]) linear_extrude(1) text(["6.0","6.1","6.2"][k], size=2.2);
    }
    for (k=[0:1]) let(d=[6.6, 6.8][k]) {
        translate([47 + k*10, 38, H - 2.6]) cylinder(d=d, h=3, $fn=6);
        translate([43.5 + k*10, 42.4, H - 0.4]) linear_extrude(1) text(str(d), size=2.2);
    }
}
