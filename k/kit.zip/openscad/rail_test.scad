// TEST 1 + 2: one R3 ramp (200 mm, steel-rod rails, adjustable gap) -> U-turn cup -> exit stub (100 mm).
// Same numbers as the simulator: ramps at 2.5 deg, gap 12 to 16.5 mm, sub-planes 22 mm apart, 8 mm drop in the cup.
include <common.scad>

part = "assembly";   // assembly | spine200 | spine100 | carrier200 | carrier100 | cup | riser_a | riser_b | riser_c | riser_d | gauges

slope    = 2.5;          // deg
gap_show = 12;           // gap used for the assembly preview
rod_z    = 12;           // rod centre height above the spine bottom
slab_h   = 4;
plane_dy = 22;           // sideways distance between two ramp planes
cc12     = rod_cc(12);   // 13.9
cc_max   = rod_cc(16.5); // 19.1

// ball sweep that every holder must stay clear of (all gaps 12..16.5), in spine coordinates:
// back rod at y = 0, front rod at y = -cc, ball centre at y = -cc/2, z = rod_z + rod_drop(gap)
module ball_sweep(L) {
    hull() for (g=[12,16.5]) translate([-1, -rod_cc(g)/2, rod_z+rod_drop(g)]) rotate([0,90,0]) cylinder(r=ball_r+0.6, h=L+2, $fn=64);
    // and everything above the ball centre line is free
    hull() for (g=[12,16.5]) translate([-1, -rod_cc(g)/2-ball_r-0.6, rod_z+rod_drop(g)]) cube([L+2, 2*ball_r+1.2, 40]);
}

// spine = slab + back rail wall (rod at y = 0). Inserts for the front-rail carrier every 40 mm.
module spine(L) {
    nI = floor((L-40)/40)+1;   // screw points from x = 20 to L-20 only (none at the very end)
    difference() {
        union() {
            translate([0,-31,0]) cube([L, 37.6, slab_h]);
            translate([0,-1.0,0]) cube([L, 4.6, rod_z+2.6]);          // back wall (4.6 thick: leaves 1.3 mm behind the rod hole's point)
        }
        translate([L/2,0,rod_z]) teardrop_x(rod_hole, L+2);            // back rod
        ball_sweep(L);
        // carrier screws: M3 from the top through the carrier slot, nut in a hex pocket under the slab
        // pocket roof is a stepped bridge (slot, then square, then round hole) so no layer prints over empty space
        for (i=[0:nI-1]) translate([20+i*40, -23.5, 0]) {
            translate([0,0,-0.01]) cylinder(d=m3_nut, h=2.6, $fn=6);
            translate([-m3_nut/2, -m3_clear/2, 2.5]) cube([m3_nut, m3_clear, 0.3]);
            translate([-m3_clear/2, -m3_clear/2, 2.5]) cube([m3_clear, m3_clear, 0.5]);
            translate([0,0,2.9]) cylinder(d=m3_clear, h=slab_h);
        }
        // riser screws: M3 up from under the riser, nut on top of the slab (below the ball path)
        for (x=[20, L-20]) translate([x, riser_y, -1]) cylinder(d=m3_clear, h=slab_h+2);
        translate([L/2, -12, slab_h-0.6]) linear_extrude(1) text(str(L," mm spine"), size=4, halign="center", valign="center");
    }
}
// front rail carrier: holds the front rod, slides sideways on slots (gap 12 -> 16.5 = 5.2 mm of travel)
module carrier(L) {
    nI = floor((L-40)/40)+1;   // screw points from x = 20 to L-20 only (none at the very end)
    difference() {
        union() {
            translate([0,-2.6,0]) cube([L, 3.6, rod_z+2.6-slab_h]);                  // wall, rod at y = 0
            for (i=[0:nI-1]) translate([20+i*40-6, -13.5, 0]) cube([12, 11, 3]);     // feet with slots
        }
        translate([L/2,0,rod_z-slab_h]) teardrop_x(rod_hole, L+2);
        for (i=[0:nI-1]) hull() for (y=[-9.6,-4.4]) translate([20+i*40, y, -1]) cylinder(d=m3_clear, h=5);
        // keep clear of the ball (carrier frame: rod at y = 0, ball centre at y = +cc/2)
        translate([0,0,-slab_h]) mirror([0,1,0]) translate([0,0,0]) ball_sweep_front(L);
    }
}
module ball_sweep_front(L) {
    hull() for (g=[12,16.5]) translate([-1, -rod_cc(g)/2, rod_z+rod_drop(g)]) rotate([0,90,0]) cylinder(r=ball_r+0.6, h=L+2, $fn=64);
}
// gap gauges: slide between the two rods (inner spacing = cc - 3 mm) at both ends, then tighten the carrier screws
module gauges() {
    gs=[12,13.5,15,16.5];
    for (i=[0:3]) translate([i*24,0,0]) difference() {
        union() { translate([-rod_cc(gs[i])/2+rod_d/2, 0, 0]) cube([rod_cc(gs[i])-rod_d, 8, 10]); translate([-9,8,0]) cube([18,10,2]); }
        translate([0,13,1.4]) linear_extrude(1) text(str(gs[i]), size=5, halign="center", valign="center");
    }
}
// risers: slab bottom height at x = 20 and x = L-20 (160 mm apart)
// A = ramp high end, B = ramp low end, C = stub high end, D = stub low end
tan_s = tan(slope);
riser_y = -12;           // riser screw line in spine coordinates (between the rails, under the ball path)
hB = 20;                 hA = hB + 160*tan_s;          // ramp: 20 and 27.0 mm
ramp_end_bottom = hB - 20*tan_s;                        // spine bottom at the cup end (x = 200)
ball12 = rod_z + rod_drop(12);                          // ball centre above the spine bottom at gap 12
cup_in  = ramp_end_bottom + rod_z + rod_drop(16.5) - 1.0;   // ball centre in the cup at entry (below every rail height)
cup_out = cup_in - 6.5;                                  // ball centre at the cup exit (total drop about 8 mm)
stub_bottom0 = cup_out - 0.5 - ball12;                   // stub spine bottom at its cup end
hC = stub_bottom0 - 20*tan_s;  hD = stub_bottom0 - 80*tan_s;
module riser(h, lbl) {
    difference() {
        union() { rbox(16, 16, h); }
        translate([0,0,h-6]) cylinder(d=m3_clear, h=7);
        translate([0,0,-1]) cylinder(d=m3_head, h=h-5.9);
        translate([0,-8.01,h/2]) rotate([90,0,0]) linear_extrude(0.6) text(lbl, size=4, halign="center", valign="center");
    }
}
// U-turn cup, in world coordinates of the test layout: ramp ball line y = 0 (gap 12) .. -2.6 (gap 16.5),
// stub ball line y = 22 .. 24.6. Ball arrives moving +x at x = 200, turns on a half circle around (203, 11)
// with radius 11 .. 13.6 mm (all gaps), and leaves moving -x at x = 200. It drops cup_in -> cup_out on the way.
cup_cx = 203; cup_cy = plane_dy/2;
function cup_path(rad) = concat(
    [ for (x=[196:3.5:203]) [x, cup_cy-rad, 0] ],
    [ for (a=[-90:15:90]) [cup_cx+rad*cos(a), cup_cy+rad*sin(a), (a+90)/180] ],
    [ for (x=[203:-3.5:196]) [x, cup_cy+rad, 1] ]);
module cup(out=cup_out, tag="U-TURN 8") {   // out = ball centre height at the exit (8 mm or 5 mm total drop)
    r = ball_r + 0.7;
    rin = cup_cy; rout = cup_cy + (rod_cc(16.5)-rod_cc(12))/2;      // 11 and 13.6
    P = cup_path(rin); Q = cup_path(rout);
    z = function(f) cup_in - (cup_in-out)*f;
    top = cup_in + 9;                                               // outer wall high enough for the ball to bank
    difference() {
        hull() for (p=concat(P,Q)) translate([p[0]+(p[0]<200?4:0), p[1], 0]) cylinder(r=r+3.2, h=top);
        for (i=[0:len(P)-2]) hull() for (pp=[P[i],P[i+1],Q[i],Q[i+1]]) translate([pp[0], pp[1], z(pp[2])]) sphere(r=r, $fn=40);
        // open top so the ball is always visible, and the end faces the spines butt against
        for (i=[0:len(P)-2]) hull() for (pp=[P[i],P[i+1],Q[i],Q[i+1]]) translate([pp[0], pp[1], z(pp[2])]) cylinder(r=r*0.55, h=40);
        translate([150,-40,-1]) cube([50.2, 100, 100]);
        // no thin post in the middle of the turn: the outer wall guides the ball
        hull() for (x=[190, cup_cx]) translate([x, cup_cy, cup_out-ball_r]) cylinder(r=rin-0.5, h=40);
        translate([cup_cx+rout+1.5, cup_cy, top-0.6]) rotate(90) linear_extrude(1) text(tag, size=3.2, halign="center", valign="center");
    }
}

// ---------- layout / assembly ----------
module ramp_assembly(L, gap) {
    spine(L);
    translate([0,-rod_cc(gap),slab_h]) carrier(L);
    color("silver") { translate([L/2,0,rod_z]) hole_x(rod_d, L); translate([L/2,-rod_cc(gap),rod_z]) hole_x(rod_d, L); }
}
module layout(gap=gap_show) {
    // ramp: back rod at world y = cc12/2 so the gap-12 ball line is y = 0; tilted down toward +x
    translate([0, rod_cc(12)/2, 0]) {
        translate([20,0,0]) rotate([0,slope,0]) translate([-20,0,hA]) color("#d08a4a") ramp_assembly(200, gap);
        color("#4a5360") { translate([20,riser_y,0]) riser(hA,"A"); translate([180,riser_y,0]) riser(hB,"B"); }
    }
    color("#59a5c4") cup();
    // exit stub: turned 180 deg, back rod at world y = 22 - cc12/2, its x = 0 at world x = 200, going down toward -x
    translate([200, plane_dy - rod_cc(12)/2, 0]) rotate([0,0,180]) {
        translate([20,0,0]) rotate([0,slope,0]) translate([-20,0,hC]) color("#d08a4a") ramp_assembly(100, gap);
        color("#4a5360") { translate([20,riser_y,0]) riser(hC,"C"); translate([80,riser_y,0]) riser(hD,"D"); }
    }
}

if (part=="assembly")   layout();
if (part=="spine200")   spine(200);
if (part=="spine100")   spine(100);
if (part=="carrier200") carrier(200);
if (part=="carrier100") carrier(100);
if (part=="cup")        translate([-200,0,0]) cup();
if (part=="cup5")       translate([-200,0,0]) cup(cup_in - 3.5, "U-TURN 5");   // 3 mm less drop: put a 3 mm shim under risers C and D
if (part=="shims3")     for (i=[0:1]) translate([i*20,0,0]) difference() { rbox(16,16,3); translate([0,0,-1]) cylinder(d=m3_clear+0.6, h=5); }
if (part=="riser_a")    riser(hA,"A");
if (part=="riser_b")    riser(hB,"B");
if (part=="riser_c")    riser(hC,"C");
if (part=="riser_d")    riser(hD,"D");
if (part=="gauges")     gauges();
echo(str("risers A,B,C,D = ", hA, ", ", hB, ", ", hC, ", ", hD, " mm; cup in/out ball centre z = ", cup_in, " / ", cup_out));
