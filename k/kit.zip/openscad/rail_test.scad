// TEST 1 + 2 (+ v3 tilt test: risers A 2.0 / 2.5 / 3.0 / 3.5 deg, part="tilt_set"): one R3 ramp (200 mm, steel-rod rails, adjustable gap) -> U-turn cup -> exit stub (100 mm).
// Same numbers as the simulator: ramps at 2.5 deg, gap 12 to 16.5 mm, sub-planes 22 mm apart, 8 mm drop in the cup.
include <common.scad>

part = "assembly";   // assembly | spine200 | spine100 | carrier200 | carrier100 | cup | stop10 | stop05 | stop10b | step4 | riser_a | riser_b | riser_c | riser_d | gauges

slope    = 2.5;          // deg
gap_show = 12;           // gap used for the assembly preview
rod_z    = 12;           // rod centre height above the spine bottom
slab_h   = 4;
plane_dy = 22;           // sideways distance between two ramp planes
cc12     = rod_cc(12);   // 13.9
cc_max   = rod_cc(16.5); // 19.1

// ball sweep that every holder must stay clear of (all gaps 12..16.5), in spine coordinates:
// back rod at y = 0, front rod at y = -cc, ball centre at y = -cc/2, z = rod_z + rod_drop(gap)
module ball_sweep(L) {
    hull() for (g=[12,16.5]) translate([-1, -rod_cc(g)/2, rod_z+rod_drop(g)]) rotate([0,90,0]) cylinder(r=ball_r+0.6, h=L+2, $fn=64);
    // and everything above the ball centre line is free
    hull() for (g=[12,16.5]) translate([-1, -rod_cc(g)/2-ball_r-0.6, rod_z+rod_drop(g)]) cube([L+2, 2*ball_r+1.2, 40]);
}

// spine = slab + back rail wall (rod at y = 0). Inserts for the front-rail carrier every 40 mm.
module spine(L) {
    nI = floor((L-40)/40)+1;   // screw points from x = 20 to L-20 only (none at the very end)
    difference() {
        union() {
            translate([0,-31,0]) cube([L, 37.6, slab_h]);
            translate([0,-1.0,0]) cube([L, 4.6, rod_z+2.6]);          // back wall (4.6 thick: leaves 1.3 mm behind the rod hole's point)
        }
        translate([L/2,0,rod_z]) teardrop_x(rod_hole, L+2);            // back rod
        for (x=[-1, L-4]) translate([x,0,rod_z]) rotate([0,90,0]) cylinder(d=4.2, h=5);   // end relief: a cutter-flared rod end fits
        ball_sweep(L);
        // carrier screws: M3 from the top through the carrier slot, nut in a hex pocket under the slab
        // pocket roof is a stepped bridge (slot, then square, then round hole) so no layer prints over empty space
        for (i=[0:nI-1]) translate([20+i*40, -23.5, 0]) {
            translate([0,0,-0.01]) cylinder(d=m3_nut, h=2.6, $fn=6);
            translate([-m3_nut/2, -m3_clear/2, 2.5]) cube([m3_nut, m3_clear, 0.3]);
            translate([-m3_clear/2, -m3_clear/2, 2.5]) cube([m3_clear, m3_clear, 0.5]);
            translate([0,0,2.9]) cylinder(d=m3_clear, h=slab_h);
        }
        // riser screws: M3 up from under the riser, nut on top of the slab (below the ball path)
        for (x=[20, L-20]) translate([x, riser_y, -1]) cylinder(d=m3_clear, h=slab_h+2);
        translate([L/2, -12, slab_h-0.6]) linear_extrude(1) text(str(L," mm spine"), size=4, halign="center", valign="center");
    }
}
// front rail carrier: holds the front rod, slides sideways on slots (gap 12 -> 16.5 = 5.2 mm of travel)
module carrier(L) {
    nI = floor((L-40)/40)+1;   // screw points from x = 20 to L-20 only (none at the very end)
    difference() {
        union() {
            translate([0,-2.6,0]) cube([L, 3.6, rod_z+2.6-slab_h]);                  // wall, rod at y = 0
            for (i=[0:nI-1]) translate([20+i*40-6, -13.5, 0]) cube([12, 11, 3]);     // feet with slots
        }
        translate([L/2,0,rod_z-slab_h]) teardrop_x(rod_hole, L+2);
        for (x=[-1, L-4]) translate([x,0,rod_z-slab_h]) rotate([0,90,0]) cylinder(d=4.2, h=5);   // end relief, as on the spine
        for (i=[0:nI-1]) hull() for (y=[-9.6,-4.4]) translate([20+i*40, y, -1]) cylinder(d=m3_clear, h=5);
        // keep clear of the ball (carrier frame: rod at y = 0, ball centre at y = +cc/2)
        translate([0,0,-slab_h]) mirror([0,1,0]) translate([0,0,0]) ball_sweep_front(L);
    }
}
module ball_sweep_front(L) {
    hull() for (g=[12,16.5]) translate([-1, -rod_cc(g)/2, rod_z+rod_drop(g)]) rotate([0,90,0]) cylinder(r=ball_r+0.6, h=L+2, $fn=64);
}
// gap gauges: slide between the two rods (inner spacing = cc - 3 mm) at both ends, then tighten the carrier screws
module gauges() {
    gs=[12,13.5,15,16.5];
    for (i=[0:3]) translate([i*24,0,0]) difference() {
        union() { translate([-rod_cc(gs[i])/2+rod_d/2, 0, 0]) cube([rod_cc(gs[i])-rod_d, 8, 10]); translate([-9,8,0]) cube([18,10,2]); }
        translate([0,13,1.4]) linear_extrude(1) text(str(gs[i]), size=5, halign="center", valign="center");
    }
}
// risers: slab bottom height at x = 20 and x = L-20 (160 mm apart)
// A = ramp high end, B = ramp low end, C = stub high end, D = stub low end
tan_s = tan(slope);
riser_y = -12;           // riser screw line in spine coordinates (between the rails, under the ball path)
hB = 20;                 hA = hB + 160*tan_s;          // ramp: 20 and 27.0 mm
ramp_end_bottom = hB - 20*tan_s;                        // spine bottom at the cup end (x = 200)
ball12 = rod_z + rod_drop(12);                          // ball centre above the spine bottom at gap 12
cup_in  = ramp_end_bottom + rod_z + rod_drop(16.5) - 1.0;   // ball centre in the cup at entry (below every rail height)
cup_out = cup_in - 6.5;                                  // ball centre at the cup exit (total drop about 8 mm)
// the cup floor at the exit (ball bottom) is cup_out - (ball_r + 0.7). The exit tongue keeps the ball 0.8 mm above
// its gap-12 height on the stub rails, so the ball lands on the rods 6 mm past their cut ends.
tongue_lift = 0.8;
stub_bottom0 = cup_out - (ball_r + 0.7) - tongue_lift - (ball12 - ball_r);   // stub spine bottom at its cup end
hC = stub_bottom0 - 20*tan_s;  hD = stub_bottom0 - 80*tan_s;
module riser(h, lbl) {
    difference() {
        union() { rbox(16, 16, h); }
        translate([0,0,h-6]) cylinder(d=m3_clear, h=7);
        translate([0,0,-1]) cylinder(d=m3_head, h=h-5.9);
        translate([0,-8.01,h/2]) rotate([90,0,0]) linear_extrude(0.6) text(lbl, size=4, halign="center", valign="center");
    }
}
// U-turn cup, in world coordinates of the test layout: ramp ball line y = 0 (gap 12) .. -2.6 (gap 16.5),
// stub ball line y = 22 .. 24.6. Ball arrives moving +x at x = 200, turns on a half circle around (203, 11)
// with radius 11 .. 13.6 mm (all gaps), and leaves moving -x at x = 200. It drops cup_in -> cup_out on the way.
cup_cx = 203; cup_cy = plane_dy/2;
function cup_path(rad) = concat(
    [ for (x=[196:3.5:203]) [x, cup_cy-rad, 0] ],
    [ for (a=[-90:15:90]) [cup_cx+rad*cos(a), cup_cy+rad*sin(a), (a+90)/180] ],
    [ for (x=[203:-3.5:196]) [x, cup_cy+rad, 1] ]);
module cup(out=cup_out, tag="U-TURN 8") {   // out = ball centre height at the exit (8 mm or 5 mm total drop)
    r = ball_r + 0.7;
    rin = cup_cy; rout = cup_cy + (rod_cc(16.5)-rod_cc(12))/2;      // 11 and 13.6
    P = cup_path(rin); Q = cup_path(rout);
    z = function(f) cup_in - (cup_in-out)*f;
    top = cup_in + 9;                                               // outer wall high enough for the ball to bank
    // exit tongue: sits between the stub rods for their first 6 mm (world x 194..200), level with the cup floor,
    // so the ball never touches the rod ends. Then the ball drops onto the rods (1 mm at gap 12, 4 mm at gap 16.5).
    zT = out - (ball_r + 0.7);
    zb = stub_bottom0 + (out - cup_out) - 6*tan_s + slab_h + 0.6;   // clear of the stub slab (cup5 is used with 3 mm shims)
    yb = plane_dy - cc12/2;                                         // stub back rod, world y
    // underside slopes at 45 deg from the cup face to a 1.5 mm tip, so it prints with no support
    hull() {
        translate([200, yb + rod_d/2 + 0.5, zb]) cube([1, cc12 - rod_d - 1, zT - zb]);
        translate([194, yb + rod_d/2 + 0.5, zT - 1.5]) cube([0.5, cc12 - rod_d - 1, 1.5]);
    }
    difference() {
        hull() for (p=concat(P,Q)) translate([p[0]+(p[0]<200?4:0), p[1], 0]) cylinder(r=r+3.2, h=top);
        for (i=[0:len(P)-2]) hull() for (pp=[P[i],P[i+1],Q[i],Q[i+1]]) translate([pp[0], pp[1], z(pp[2])]) sphere(r=r, $fn=40);
        // open top so the ball is always visible, and the end faces the spines butt against
        for (i=[0:len(P)-2]) hull() for (pp=[P[i],P[i+1],Q[i],Q[i+1]]) translate([pp[0], pp[1], z(pp[2])]) cylinder(r=r*0.55, h=40);
        translate([150,-40,-1]) cube([50.2, 100, 100]);
        // no thin post in the middle of the turn: the outer wall guides the ball
        hull() for (x=[190, cup_cx]) translate([x, cup_cy, cup_out-ball_r]) cylinder(r=rin-0.5, h=40);
        translate([cup_cx+rout+1.5, cup_cy, top-0.6]) rotate(90) linear_extrude(1) text(tag, size=3.2, halign="center", valign="center");
    }
}

// ---------- stop cups (2026-10-26): set the exit speed, whatever speed the ball comes in with ----------
// Smooth cups let the ball keep its speed, and then R3 runs too fast (simulator). A stop cup kills the speed: the ball
// drops off the ramp end, hits a 10 mm EVA foam pad on the flat far wall, and then rolls from (almost) rest down a
// gentle floor, round the corner and out over the same exit tongue. The exit speed comes from the floor drop D
// (D = 1.0 mm -> about 10 cm/s, 0.5 mm -> about 7 cm/s, less rolling loss). Same mounting and tongue as cup().
pad_d = 10.4; pad_depth = 2.0;          // EVA dot 10 mm x 2 mm (2 dots stacked if the foam is 1 mm)
stop_x = 206;                           // ball centre at the pad (3 mm past where the smooth cup turns)
// the EVA foam pad itself (10 mm dot, 2 mm), flush with the far wall: shown in the assembly, checked in its pocket
pad_dot = 10.0;
module stoppad(D=1.0, out=cup_out, pad2=false) color("#2b2b2b") {
    r = ball_r + 0.7;
    y0 = -(rod_cc(16.5)-rod_cc(12))/2;  y1 = plane_dy - y0;
    zs = out + D;
    translate([stop_x + r + pad_depth/2, y0/2, zs - 0.7]) rotate([0,90,0]) cylinder(d=pad_dot, h=pad_depth, center=true, $fn=24);
    if (pad2) translate([stop_x - 3, y1 + r + pad_depth/2, zs - 0.7*D - 0.3*D*3/(stop_x-200) - 0.7]) rotate([90,0,0]) cylinder(d=pad_dot, h=pad_depth, center=true, $fn=24);
}
module stopcup(D=1.0, tag="STOP 1.0", pad2=false, out=cup_out, side_in=false, zcut=-1, x_in=false) {   // x_in: ladder entry through the far (+x) wall near the exit corner   // out: exit ball height (cup_in-3.5 = 9 mm stack pitch); side_in: ladder entry in the +y wall; zcut: trim the body below this z (stack: cups 2 levels apart)
    r = ball_r + 0.7;
    y0 = -(rod_cc(16.5)-rod_cc(12))/2;  y1 = plane_dy - y0;          // ball lines -2.6 .. 24.6 (all gaps)
    zs = out + D;                                                     // ball centre at the pad
    zc = function(x,y) zs - 0.7*D*(y-y0)/(y1-y0) - 0.3*D*(stop_x-x)/(stop_x-200);   // floor plane: down to the exit corner
    top = cup_in + 9;
    zT = out - (ball_r + 0.7);
    zb = max(zcut, stub_bottom0 + (out - cup_out) - 6*tan_s + slab_h + 0.6);
    yb = plane_dy - cc12/2;
    hull() {                                                          // exit tongue, as on cup()
        translate([200, yb + rod_d/2 + 0.5, zb]) cube([1, cc12 - rod_d - 1, zT - zb]);
        translate([194, yb + rod_d/2 + 0.5, zT - 1.5]) cube([0.5, cc12 - rod_d - 1, 1.5]);
    }
    difference() {
        hull() for (x=[200, stop_x], y=[y0, y1]) translate([x, y, 0]) cylinder(r=r + (x==stop_x ? 4.4 : 3.2), h=top);
        // pocket: a flat floor plane under the ball, open above (the ball is always visible)
        hull() for (x=[196, stop_x], y=[y0, y1], dz=[0, 40]) translate([x, y, zc(x,y)+dz]) sphere(r=r, $fn=40);
        translate([150,-40,-1]) cube([50.2, 100, 100]);
        // pad pocket in the far wall, where the incoming ball hits (all gaps: y -2.6 .. 0)
        translate([stop_x + r + pad_depth/2 - 0.5, y0/2, zs - 0.7]) teardrop_x(pad_d, pad_depth + 1.0);   // starts 1 mm inside the pocket (no shared face)
        // optional 2nd pad in the corner wall: the ball meets it after rolling across, so it arrives slower still
        if (pad2) translate([stop_x - 3, y1 + r + pad_depth/2 - 0.5, zc(stop_x-3,y1) - 0.7]) rotate([0,0,90]) teardrop_x(pad_d, pad_depth + 1.0);
        translate([stop_x - 2, (y0+y1)/2, top-0.6]) rotate(90) linear_extrude(1) text(tag, size=3.2, halign="center", valign="center");
        // ladder entry: a slot in the +y wall over the exit corner; the ladder chute drops the ball in here
        if (side_in) translate([stop_x - 9, y1, zc(stop_x,y1) - r + 1.5]) cube([16, 20, 40]);
        if (x_in) translate([stop_x + r - 1, y1 - 16, zc(stop_x,y1) - r + 1.5]) cube([12, 16 + r + 6, 40]);
        // (2026-10-27) the slot alone leaves a 2 mm ridge (the pocket's round edge) between the slot and the corner:
        // a sloped channel through the wall lets the ladder ball roll down into the exit corner (2.4 mm fall over 17 mm,
        // so a ball in the corner cannot climb out)
        if (x_in) hull() for (x=[stop_x - 1, stop_x + 16], y=[y1 - 4, y1], dz=[0, 40]) translate([x, y, zc(stop_x,y1) + (x > stop_x ? 2.4 : 0) + dz]) sphere(r=r, $fn=32);
        if (zcut > 0) translate([150, -40, -1]) cube([100, 100, zcut + 1]);
    }
}
// step cup, PLA only: the smooth cup's path, but the 6.5 mm drop is made of a few big steps. Each step costs the ball a
// share of its speed, more when it is fast, so the exit speed tends to one value. No pad; the test shows if it is steady.
module stepcup(n=4, tag="STEP 4") {
    r = ball_r + 0.7;
    rin = cup_cy; rout = cup_cy + (rod_cc(16.5)-rod_cc(12))/2;
    P = cup_path(rin); Q = cup_path(rout);
    z = function(f) cup_in - (cup_in-cup_out)*min(1, ceil(f*n - 0.001)/n);
    top = cup_in + 9;
    zT = cup_out - (ball_r + 0.7);
    zb = stub_bottom0 - 6*tan_s + slab_h + 0.6;
    yb = plane_dy - cc12/2;
    hull() {
        translate([200, yb + rod_d/2 + 0.5, zb]) cube([1, cc12 - rod_d - 1, zT - zb]);
        translate([194, yb + rod_d/2 + 0.5, zT - 1.5]) cube([0.5, cc12 - rod_d - 1, 1.5]);
    }
    difference() {
        hull() for (p=concat(P,Q)) translate([p[0]+(p[0]<200?4:0), p[1], 0]) cylinder(r=r+3.2, h=top);
        // each path piece is cut at the lower of its two end heights, so every step is a sharp drop
        for (i=[0:len(P)-2]) let(zz=min(z(P[i][2]), z(P[i+1][2]))) hull() for (pp=[P[i],P[i+1],Q[i],Q[i+1]]) translate([pp[0], pp[1], zz]) sphere(r=r, $fn=40);
        for (i=[0:len(P)-2]) hull() for (pp=[P[i],P[i+1],Q[i],Q[i+1]]) translate([pp[0], pp[1], z(pp[2])]) cylinder(r=r*0.55, h=40);
        translate([150,-40,-1]) cube([50.2, 100, 100]);
        hull() for (x=[190, cup_cx]) translate([x, cup_cy, cup_out-ball_r]) cylinder(r=rin-0.5, h=40);
        translate([cup_cx+rout+1.5, cup_cy, top-0.6]) rotate(90) linear_extrude(1) text(tag, size=3.2, halign="center", valign="center");
    }
}

// ---------- layout / assembly ----------
module ramp_assembly(L, gap) {
    spine(L);
    translate([0,-rod_cc(gap),slab_h]) carrier(L);
    color("silver") { translate([L/2,0,rod_z]) hole_x(rod_d, L); translate([L/2,-rod_cc(gap),rod_z]) hole_x(rod_d, L); }
}
module layout(gap=gap_show) {
    // ramp: back rod at world y = cc12/2 so the gap-12 ball line is y = 0; tilted down toward +x
    translate([0, rod_cc(12)/2, 0]) {
        translate([20,0,0]) rotate([0,slope,0]) translate([-20,0,hA]) color("#d08a4a") ramp_assembly(200, gap);
        color("#4a5360") { translate([20,riser_y,0]) riser(hA,"A"); translate([180,riser_y,0]) riser(hB,"B"); }
    }
    color("#59a5c4") cup();
    // exit stub: turned 180 deg, back rod at world y = 22 - cc12/2, its x = 0 at world x = 200, going down toward -x
    translate([200, plane_dy - rod_cc(12)/2, 0]) rotate([0,0,180]) {
        translate([20,0,0]) rotate([0,slope,0]) translate([-20,0,hC]) color("#d08a4a") ramp_assembly(100, gap);
        color("#4a5360") { translate([20,riser_y,0]) riser(hC,"C"); translate([80,riser_y,0]) riser(hD,"D"); }
    }
}

if (part=="assembly")   layout();
if (part=="spine200")   spine(200);
if (part=="spine100")   spine(100);
if (part=="carrier200") carrier(200);
if (part=="carrier100") carrier(100);
if (part=="cup")        translate([-200,0,0]) cup();
// end-supported ramp (2026-10-27): the same spine and carrier, but only their two 26 mm ends. The rods span the 148 mm
// between them (sag under the ball about 0.03 mm). Test it against the full spine: same ball, same gap, time both.
module ends_only(L) intersection() { children(); union() { translate([-1,-60,-1]) cube([27,120,60]); translate([L-26,-60,-1]) cube([27,120,60]); } }
if (part=="spine200e")   ends_only(200) spine(200);
if (part=="carrier200e") ends_only(200) carrier(200);
if (part=="stop10")     translate([-200,0,0]) stopcup(1.0, "STOP 1.0");
if (part=="stop05")     translate([-200,0,0]) stopcup(0.5, "STOP 0.5");
if (part=="stop10b")    translate([-200,0,0]) stopcup(1.0, "STOP 1.0 B", pad2=true);
if (part=="step4")      translate([-200,0,0]) stepcup(4, "STEP 4");
if (part=="cup5")       translate([-200,0,0]) cup(cup_in - 3.5, "U-TURN 5");   // 3 mm less drop: put a 3 mm shim under risers C and D
if (part=="shims3")     for (i=[0:1]) translate([i*20,0,0]) difference() { rbox(16,16,3); translate([0,0,-1]) cylinder(d=m3_clear+0.6, h=5); }
if (part=="riser_a")    riser(hA,"A");
// (v3) tilt test: swap riser A for one of these (riser B stays). The ramp pivots on riser B, so the cup end does not
// move (0.2 mm). Time the ramp at each tilt and gap; the simulator's calibration panel fits the rolling resistance.
function hA_at(t) = hB + 160*tan(t);
if (part=="riser_a20")  riser(hA_at(2.0),"A 2.0");
if (part=="riser_a30")  riser(hA_at(3.0),"A 3.0");
if (part=="riser_a35")  riser(hA_at(3.5),"A 3.5");
if (part=="tilt_set")   for (i=[0:3]) translate([i*24,0,0]) riser(hA_at([2.0,2.5,3.0,3.5][i]), str("A ", [2.0,2.5,3.0,3.5][i]));
if (part=="riser_b")    riser(hB,"B");
if (part=="riser_c")    riser(hC,"C");
if (part=="riser_d")    riser(hD,"D");
if (part=="gauges")     gauges();
echo(str("risers A,B,C,D = ", hA, ", ", hB, ", ", hC, ", ", hD, " mm; cup in/out ball centre z = ", cup_in, " / ", cup_out));
