// v1.6 stack side: exploded views of the split parts (pictures cad/png/v16_stack_*.png, made by v16_build_stack.py --pics).
// The pieces are imported from world-pose STLs (D = folder, written by the builder): OpenSCAD's geometry cache mixes
// the colours of pieces that share a sub-tree (the lower post and the ladder both come from fr_post()).
// view = frame | frame_lap | frame_corner | comb | comb_joint | tray | tray_joint | bracket | bracket_joint | cage | carriage
include <coaster_v1.scad>
part = "none";
view = "frame";
D = ".";
C = ["#59a5c4", "#d6a648", "#6cbf8f", "#d47272", "#a07cc5", "#e0a040", "#4a90a0", "#c08060"];
module P(k, c, t=[0,0,0]) color(c) translate(t) import(str(D, "/", k, ".stl"), convexity=10);
module steel() color("silver") children();
module clip(o, s) intersection() { children(); translate(o) cube(s); }
// --- 06 stack frame: ladders out in Y, lower posts down, cross bars up ---
if (view=="frame") {
    P("frame_ladder_back", C[0], [0, -40, 0]); P("frame_ladder_front", C[1], [0, 40, 0]);
    P("frame_post_back_L", C[2], [0, -40, -40]); P("frame_post_back_R", C[3], [0, -40, -40]);
    P("frame_post_front_L", C[2], [0, 40, -40]); P("frame_post_front_R", C[3], [0, 40, -40]);
    P("frame_bar_L", C[4], [0, 0, 40]); P("frame_bar_R", C[4], [0, 0, 40]);
}
// lap of the back left post: the ladder 25 mm up, the 2 pins out to the side
if (view=="frame_lap") let(f=0, k=0, L=fr_lap(f, k), o=[10, -30, L[0]-30], s=[50, 60, 100]) {
    clip(o, s) P("frame_ladder_back", C[0], [0, 0, 25]);
    clip(o, s) P("frame_post_back_L", C[2]);
    steel() for (z=[fr_mid[f][k]-7, fr_mid[f][k]+7]) translate([fr_spl(k)[0]-18, fr_py(f)+2, z]) rotate([0,90,0]) cylinder(d=2, h=12, $fn=16);
}
// corner: the cross bar 15 mm up, its 2 pins
if (view=="frame_corner") let(o=[15, -20, yBeam-40], s=[50, 90, 80]) {
    clip(o, s) P("frame_ladder_back", C[0]); clip(o, s) P("frame_ladder_front", C[1]); clip(o, s) P("frame_bar_L", C[4], [0, 0, 15]);
    steel() for (f=[0,1]) translate([postX[0], fr_py(f)+2, yBeam+7]) cylinder(d=2, h=8, $fn=16);
}
// --- 07 / 08 comb frames: upper pieces 30 mm up ---
if (view=="comb") { P("comb_back_lo", C[0]); P("comb_back_hi", C[1], [0, 0, 30]); P("comb_front_lo", C[2], [0, 40, 0]); P("comb_front_hi", C[3], [0, 40, 30]); }
if (view=="comb_joint") let(o=[xB[0]-15, -20, gd_mid[0]-25], s=[30, 40, 60]) { clip(o, s) P("comb_back_lo", C[0]); clip(o, s) P("comb_back_hi", C[1], [0, 0, 12]); }
// --- 25 E1 tray: A 40 mm along +X, the 2 pins ---
if (view=="tray") { P("tray_e1_a", C[0], [40, 0, 0]); P("tray_e1_b", C[1]);
                    steel() for (sg=[-1,1]) translate([tr_x+20, 135+sg*15, tr_axz(tr_x)-12.725]) cylinder(d=3, h=10, $fn=16); }
if (view=="tray_joint") let(o=[tr_x-30, 100, 340], s=[80, 70, 60]) {
    clip(o, s) P("tray_e1_a", C[0], [20, 0, 0]); clip(o, s) P("tray_e1_b", C[1]);
    steel() for (sg=[-1,1]) translate([tr_x+10, 135+sg*15, tr_axz(tr_x)-12.725]) cylinder(d=3, h=10, $fn=16); }
// --- 38 E2 top bracket and 39 tip cams ---
if (view=="bracket") { P("e2_bracket_post_lo", C[0]); P("e2_bracket_post_hi", C[1], [25, 0, 30]); P("e2_bracket_beam", C[2], [50, 0, 60]); P("tip_cams", C[5], [50, 0, 30]); }
if (view=="bracket_joint") let(o=[280, -30, bk_L1[0]-25], s=[60, 60, 80]) {
    clip(o, s) P("e2_bracket_post_lo", C[0]); clip(o, s) P("e2_bracket_post_hi", C[1], [15, 0, 0]);
    steel() for (z=[bk_L1[0]+7, bk_L1[1]-7]) translate([bkX[1]+25, -5, z]) rotate([0,-90,0]) cylinder(d=3, h=10, $fn=16); }
// --- 23 / 35 cages (left top ring 30 mm up), 24 / 36 carriages ---
if (view=="cage") { P("cage_right", C[0], [-268+40, -38, 0]); P("cage_left", C[1], [8.2-40, -16, 0]); P("cage_left_topring", C[2], [8.2-40, -16, 30]); }
if (view=="carriage") { P("carriage_right", C[0], [-268+25, -38, -cupEntryZ(k2)]); P("carriage_left", C[1], [8.2-25, -16, -cupEntryZ(k1)]); }
