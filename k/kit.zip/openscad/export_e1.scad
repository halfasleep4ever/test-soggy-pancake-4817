// Elevator 1: each printed part in its assembled position (lever at the bottom, waiting for the ball). -D 'p="lever"'
include <elevator1_test.scad>
part = "none"; p = "lever"; a = -52.2;
f = (sin(a)+sn)/(2*sn);
if (p=="base_a") base_half("a");
if (p=="base_b") base_half("b");
if (p=="plate") plate();
for (i=[0:2]) if (p==str("gusset",i)) translate([[-235,-175,-115][i], plate_y1, 0]) rotate([90,0,90]) gusset();
if (p=="lever") translate(P) rotate([0,-a,0]) rotate([90,0,0]) lever();
if (p=="cup") translate(E(a)) cup();
if (p=="wheel") translate([W[0],0,W[2]]) wheel();
if (p=="idler") translate(I) idler();
if (p=="crank") translate(H) crank();
if (p=="latch_post") translate([H[0],0,0]) latch_post();
if (p=="feed_hi") feed_riser(-130);
if (p=="feed_lo") feed_riser(-40);
if (p=="post_lower") post(0,195);
if (p=="post_upper") post(195,390);
if (p=="tray") tray_bracket();
if (p=="cw_pot") translate([I[0]-6.5, -6.5, I[2]-30-122-f*cw_drop]) cw_pot();
