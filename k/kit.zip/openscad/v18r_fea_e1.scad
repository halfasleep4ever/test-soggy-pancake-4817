// v1.8r FEA (E1 counterweight hung from the drum): the changed E1 parts in their FEA poses (as v17f_fea_e1.scad).
//   e1_wheel / e1_cw_pot: the E1_print pose (local part coordinates)
//   e1_cw_post: post 13 (v1.8r), print rotation
//   e1_ff_frame: frame 12a + foot 12b (unchanged parts, new wheel pin load) in the frame's print pose -> (Xw, Zw, -Yw)
include <coaster_e1.scad>
part = "none";
fk = "e1_wheel";
module wld() translate(E1_ORIGIN) children();
if (fk=="e1_wheel")    E1_print("e1_wheel");
if (fk=="e1_cw_pot")   E1_print("e1_cw_pot");
// e1_cw_post (v1.8r wheel-pin end post): its print rotation, world numbers: FEA (X, Y, Z) = (Xw, -Zw, Yw - 79.2)
if (fk=="e1_cw_post")  translate([0,0,-79.2]) rotate([90,0,0]) wld() E1_cwpost();
if (fk=="e1_ff_frame") rotate([-90,0,0]) wld() union() { E1_frame(); E1_foot(); }
