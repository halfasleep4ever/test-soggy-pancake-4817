// v1.7i (elevator fit integration): the E2 latch post (31) in its NEW print pose (on its crank-side face), world numbers.
//   FEA (X, Y, Z) = (Xw, -Zw, Yw): Z = the layer direction (world Y).
include <coaster_e2.scad>
part = "none"; part2 = "none";
fk = "e2_latch_post";
if (fk=="e2_latch_post") rotate([90,0,0]) translate(E2_ORIGIN) latch_post_v1();
