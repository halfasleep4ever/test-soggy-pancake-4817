// v1.7t pictures: view = "gate_shut" | "gate_open" | "braces". Render: openscad -D 'view="..."' -o png ...
include <coaster_v1.scad>
part = "none";
view = "gate_shut";
if (view == "gate_shut" || view == "gate_open") let(a = view == "gate_open" ? E2_info()[3] : e2a)
    intersection() { union() { gate(flap=false); gate_flap(gate_phi(a)); cord_guide_c(); cord_guide_b(); gate_cord(a); gate_legs();
                                color("#d08a4a", 0.5) finish_track_body(); color("#d08a4a", 0.5) e2feed_part_v(); }
                     translate([218, -12, 0]) cube([82, 72, 70]); }
module e2feed_part_v() difference() { trough_chain([for (k=[2:len(E2feed)-1]) E2feed[k]], open_start=true, open_end=true, pads=[2]); trip_slot(E2O); }
if (view == "braces") {
    color("#c0392b") { p1_strut(); ledge_hanger(); }
    color("#8a94a3") { e2_bracket_beam(); tipcams(); p3_bracket(); fr_strip(1); }
    color("#d08a4a") tray_e1_a(); color("white") E2rope_w(e2a); translate([262,67,0]) E2_static();
}
