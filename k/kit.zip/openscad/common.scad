// Roller Coaster B test kit: shared sizes and helpers. Units: mm.
// Print in PETG, 0.2 mm layers, 4 walls, 30% gyroid unless a part says otherwise.

$fn = 48;

ball_d    = 19.05;          // 3/4 in steel ball
ball_r    = ball_d/2;
rod_d     = 3.0;            // steel rail rod
rod_hole  = 3.25;           // snug fit for the rod (print one test tie first)
pin_hole  = 3.25;           // 3 mm steel pins
brg_od    = 6.1;            // MR63 bearing seat (6 x 3 x 2.5)
brg_h     = 2.6;
m3_clear  = 3.4;
m3_insert = 4.0;            // M3 heat-set insert hole, 5.5 mm deep
m3_head   = 6.0;
m3_nut    = 6.6;            // across corners of an M3 nut pocket (5.5 mm across flats + clearance)

// rail geometry (matches the simulator): "gap" = spacing of the two contact points on the ball
rail_k     = (ball_r + rod_d/2) / ball_r;           // contact point -> rod centre scale
function rod_cc(gap)   = gap * rail_k;               // rod centre-to-centre spacing
function rod_drop(gap) = sqrt(ball_r*ball_r - (gap/2)*(gap/2)) * rail_k;   // ball centre -> rod centre, vertical

// hole along X that prints without support when the part lies flat (teardrop)
module teardrop_x(d, len) {
    rotate([0,90,0]) linear_extrude(height=len, center=true)
        union() { circle(d=d); rotate(45) square(d/2); }
}
module hole_x(d, len) { rotate([0,90,0]) cylinder(d=d, h=len, center=true); }
module hole_y(d, len) { rotate([90,0,0]) cylinder(d=d, h=len, center=true); }

// rounded box, centred in x and y, sitting on z = 0
module rbox(x, y, z, r=1.5) {
    hull() for (i=[-1,1], j=[-1,1]) translate([i*(x/2-r), j*(y/2-r), 0]) cylinder(r=r, h=z, $fn=20);
}

// bearing pocket from one face
module brg_pocket() { cylinder(d=brg_od, h=brg_h+0.01); }

// ---------- involute spur gear (2D outline + extrusion) ----------
function _rot(p,a) = [p[0]*cos(a)-p[1]*sin(a), p[0]*sin(a)+p[1]*cos(a)];
function _inv(rb,t) = [rb*(cos(t*180/PI)+t*sin(t*180/PI)), rb*(sin(t*180/PI)-t*cos(t*180/PI))];
function gear_rp(N, m) = m*N/2;

module gear2d(N, m, pa=20, backlash=0.1) {
    rp = m*N/2; rb = rp*cos(pa); ra = rp + m; rf = max(rp - 1.25*m, 0.6*rp);
    tmax = sqrt(pow(ra/rb,2) - 1);
    tp   = sqrt(pow(rp/rb,2) - 1);
    invp = (tp - atan(tp)*PI/180) * 180/PI;              // involute function at the pitch circle, deg
    half = 90/N + invp - (backlash/(2*rp))*180/PI;        // half-tooth angle from the base-circle start
    st = 8;
    pts = [ for (i=[0:N-1]) let(c = i*360/N) each concat(
        [ _rot([rf,0], c-half) ],
        [ for (k=[0:st]) _rot(_inv(rb, tmax*k/st), c-half) ],
        [ for (k=[st:-1:0]) let(q=_inv(rb, tmax*k/st)) _rot([q[0],-q[1]], c+half) ],
        [ _rot([rf,0], c+half) ]
    ) ];
    polygon(pts);
}
module gear(N, m, th, bore=pin_hole, hub_d=0, hub_h=0) {
    difference() {
        union() {
            linear_extrude(height=th) gear2d(N, m);
            if (hub_h > 0) cylinder(d=hub_d, h=th+hub_h);
        }
        translate([0,0,-1]) cylinder(d=bore, h=th+hub_h+2);
    }
}
