// Roller Coaster B test kit: shared sizes and helpers. Units: mm.
// Print in PETG, 0.2 mm layers, 4 walls, 30% gyroid unless a part says otherwise.

$fn = 48;

ball_d    = 19.05;          // 3/4 in steel ball
ball_r    = ball_d/2;
rod_d     = 3.0;            // steel rail rod
rod_hole  = 3.15;           // rod groove: fit test 2026-10-28, 3.15 snapped in best (smallest tested)
pin_hole  = 3.30;           // 3 mm steel pins: press holes = pin_hole-0.15 = 3.15 (fit test 2026-10-28 best); slip holes 3.30; turning holes +0.3
brg_od    = 6.0;            // MR63 bearing seat (6 x 3 x 2.5): fit test 2026-10-28, 6.0 best
brg_h     = 2.6;
m3_clear  = 3.4;
m3_insert = 4.0;            // M3 heat-set insert hole, 5.5 mm deep
m3_head   = 6.0;
m3_nut    = 6.6;            // M3 nut pocket across corners: fit test 2026-10-28, 6.6 best

// rail geometry (matches the simulator): "gap" = spacing of the two contact points on the ball
rail_k     = (ball_r + rod_d/2) / ball_r;           // contact point -> rod centre scale
function rod_cc(gap)   = gap * rail_k;               // rod centre-to-centre spacing
function rod_drop(gap) = sqrt(ball_r*ball_r - (gap/2)*(gap/2)) * rail_k;   // ball centre -> rod centre, vertical

// hole along X that prints without support when the part lies flat (teardrop)
module teardrop_x(d, len) {
    rotate([0,90,0]) linear_extrude(height=len, center=true)
        union() { circle(d=d); rotate(45) square(d/2); }
}
module hole_x(d, len) { rotate([0,90,0]) cylinder(d=d, h=len, center=true); }
module hole_y(d, len) { rotate([90,0,0]) cylinder(d=d, h=len, center=true); }

// rounded box, centred in x and y, sitting on z = 0
module rbox(x, y, z, r=1.5) {
    hull() for (i=[-1,1], j=[-1,1]) translate([i*(x/2-r), j*(y/2-r), 0]) cylinder(r=r, h=z, $fn=20);
}

// bearing pocket from one face
module brg_pocket() { cylinder(d=brg_od, h=brg_h+0.01); }

// ---------- involute spur gear (2D outline + extrusion) ----------
function _rot(p,a) = [p[0]*cos(a)-p[1]*sin(a), p[0]*sin(a)+p[1]*cos(a)];
function _inv(rb,t) = [rb*(cos(t*180/PI)+t*sin(t*180/PI)), rb*(sin(t*180/PI)-t*cos(t*180/PI))];
function gear_rp(N, m) = m*N/2;

module gear2d(N, m, pa=20, backlash=0.1) {
    rp = m*N/2; rb = rp*cos(pa); ra = rp + m; rf = max(rp - 1.25*m, 0.6*rp);
    tmax = sqrt(pow(ra/rb,2) - 1);
    tp   = sqrt(pow(rp/rb,2) - 1);
    invp = (tp - atan(tp)*PI/180) * 180/PI;              // involute function at the pitch circle, deg
    half = 90/N + invp - (backlash/(2*rp))*180/PI;        // half-tooth angle from the base-circle start
    st = 8;
    pts = [ for (i=[0:N-1]) let(c = i*360/N) each concat(
        [ _rot([rf,0], c-half) ],
        [ for (k=[0:st]) _rot(_inv(rb, tmax*k/st), c-half) ],
        [ for (k=[st:-1:0]) let(q=_inv(rb, tmax*k/st)) _rot([q[0],-q[1]], c+half) ],
        [ _rot([rf,0], c+half) ]
    ) ];
    polygon(pts);
}
module gear(N, m, th, bore=pin_hole, hub_d=0, hub_h=0) {
    difference() {
        union() {
            linear_extrude(height=th) gear2d(N, m);
            if (hub_h > 0) cylinder(d=hub_d, h=th+hub_h);
        }
        translate([0,0,-1]) cylinder(d=bore, h=th+hub_h+2);
    }
}

// ---- printed half-pipe trough along points (coaster v1 and the v3 rig tops) ----
// trough_chain: printed half-pipe along points. mouth: open from above at the start (ball drops in); drop_end: hole
// down at the end (ball drops out); open_start/open_end: no end cap; pads: indexes of corner points that get an EVA
// pad pocket in the outer wall.
// v5 (2026-10-28): the walls end LOW, lip mm above the trough axis (default -2.0: 1.2 mm below the ball centre, which
// rolls 0.8 mm under the axis). The ball shows from the front and the sides (rule 3.c), and the trough is open, not an
// enclosed track (rule 6.g). At each pad corner a short full-height bumper keeps the outer wall: the ball hits it head
// on. lip = 99 gives the v4 trough (tall walls, 16.5 mm top slot).
trough_lip = -2.0;
module halfspace(p, d) translate(p) rotate([0,0,atan2(d[1],d[0])]) translate([0,-60,-60]) cube([80,120,120]);
module trough_chain(pts, rin=ball_r+0.8, wall=2.4, mouth=false, drop_end=false, open_start=false, open_end=false, pads=[], lip=trough_lip) {
    module body() for (k=[0:len(pts)-2]) hull() { translate(pts[k]) sphere(r=rin+wall, $fn=20); translate(pts[k+1]) sphere(r=rin+wall, $fn=20); }
    module cuts(lowcut) {
        for (k=[0:len(pts)-2]) hull() { translate(pts[k]) sphere(r=rin, $fn=20); translate(pts[k+1]) sphere(r=rin, $fn=20); }
        if (lowcut) for (k=[0:len(pts)-2]) hull() { translate(pts[k]+[0,0,lip]) cylinder(r=rin+wall+1, h=40, $fn=20); translate(pts[k+1]+[0,0,lip]) cylinder(r=rin+wall+1, h=40, $fn=20); }
        else for (k=[0:len(pts)-2]) hull() { translate(pts[k]+[0,0,2]) cylinder(r=rin*0.8, h=40, $fn=16); translate(pts[k+1]+[0,0,2]) cylinder(r=rin*0.8, h=40, $fn=16); }
        let(m=len(pts)-1) {
            if (mouth)      translate(pts[0]) cylinder(r=rin+0.3, h=60, $fn=24);
            if (drop_end)   translate(pts[m]-[0,0,40]) cylinder(r=rin+0.3, h=80, $fn=24);
            if (open_start) halfspace(pts[0], pts[0]-pts[1]);
            if (open_end)   halfspace(pts[m], pts[m]-pts[m-1]);
            for (k=pads) let(d=pts[k]-pts[k-1], u=d/norm([d[0],d[1]])) translate(pts[k]+[u[0],u[1],0]*(rin+1)) rotate([0,0,atan2(u[1],u[0])]) rotate([0,90,0]) cylinder(d=10.4, h=2.1, center=true, $fn=24);
        }
    }
    difference() {
        union() {
            body();
            // bumper at each pad corner: the outer wall ahead of the incoming ball, 18 mm wide, up to 7 mm above the axis
            if (lip < 50) for (k=pads) let(d=pts[k]-pts[k-1], u=d/norm([d[0],d[1]])) intersection() {
                body();
                translate(pts[k]) rotate([0,0,atan2(u[1],u[0])]) translate([rin-0.5, -9, lip-1]) cube([wall+1.5, 18, 7-lip+1]);
            }
        }
        cuts(lip < 50);
    }
}
