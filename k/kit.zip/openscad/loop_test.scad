// TEST 3: printed 16 cm loop with a steep start chute (2026-10-26).
// Everything is printed lying on its side, so the layer lines run along the ball's path. The ball rides on two
// printed ridges 12 mm apart (like the steel rails). Two lanes side by side: lane A (entry, next to the board) and
// lane B (exit, 21.5 mm out). The ring's ridges move from lane A to lane B on the way round, so the exit passes the
// entry at the POI and the loop "appears to self-intersect" (rule 3.k). Open toward the middle: never enclosed (3.k.ii),
// ball always visible (3.c), nothing under the ball at the top (3.k.vi).
// Loop height (rule 3.k.iii): POI = the ridge tips at the bottom, highest inside point = the ridge tips at the top.
// Pieces (part=...): ring_main (arc + lead-in + loop + exit, one piece), chute_lo, chute_hi; screwed to the board
// (loop_board.scad). Only joints: on the straight chute, away from the fast bottom of the loop.
include <common.scad>

part = "assembly";   // assembly | ring_main | chute_lo | chute_hi

R     = 84.5;        // ring wall radius; ridge tips at R - 2 -> inside height 2*(R-2) = 165 mm (scores 16 cm)
T     = 6;           // wall thickness behind the ridges
rp    = 2.0;         // ridge height above the wall
rsep  = 6;           // ridge centres at lane centre +- 6 mm (12 mm apart)
wA    = 11; wB = 31.5; // lane centres (w = distance from the board): balls clear the board and each other's lane
bA = 20; bB0 = 21.5; bB1 = 41.5;   // lane A band 0..20, lane B band 21.5..41.5
L1    = 60;          // flat lead-in before the POI
Rc    = 50;          // curve from the 70 deg chute into the lead-in
ang   = 70;          // chute angle
ysplit = 170;        // chute_lo / chute_hi joint height (track surface)
ytop  = 335;         // top of the chute (track surface)
hole  = 3.6;         // board screws (M3 or #4 wood screws)

// ---- cross-section: [n, w], n = toward the ball (0 = wall surface), w = sideways (print z) ----
function ridge(wr) = [[0, wr-3.4], [rp, wr], [1.4, wr+1.0], [0, wr+2.0]];   // underside ~60 deg: prints without support
function prof(wlo, whi, wc) = concat([[-T, wlo], [0, wlo]], ridge(wc-rsep), ridge(wc+rsep), [[0, whi], [-T, whi]]);

// ---- sweep: stations [C=[x,y], nh=[nx,ny]] with a profile each -> one closed solid ----
module sweep(st, profs) {
    ns = len(st); np = len(profs[0]);
    pts = [ for (i=[0:ns-1]) for (p=profs[i]) [st[i][0][0]+st[i][1][0]*p[0], st[i][0][1]+st[i][1][1]*p[0], p[1]] ];
    faces = concat(
        [ for (i=[0:ns-2]) for (j=[0:np-1]) [i*np+j, (i+1)*np+j, (i+1)*np+(j+1)%np, i*np+(j+1)%np] ],
        [[ for (j=[0:np-1]) j ]],
        [[ for (j=[np-1:-1:0]) (ns-1)*np+j ]]);
    polyhedron(pts, faces, convexity=10);
}

// ---- paths ----
function ringSt(th) = [[R*sin(th), R - R*cos(th)], [-sin(th), cos(th)]];
function wcRing(th) = th <= 60 ? wA : th >= 300 ? wB : wA + (wB-wA)*smoothstep((th-60)/240);
function smoothstep(t) = t*t*(3-2*t);
d0 = [cos(-ang), sin(-ang)];                                     // travel direction on the chute (down-right)
arcTop = [-L1 + Rc*sin(-ang), Rc - Rc*cos(-ang)];
nStr = [-sin(-ang), cos(-ang)];                                  // ball side of the straight
function sAt(y) = (y - arcTop[1]) / (-d0[1]);                    // distance up the straight from the arc top
function strSt(y) = [[arcTop[0] - d0[0]*sAt(y), y], nStr];
function arcSt(h) = [[-L1 + Rc*sin(h), Rc - Rc*cos(h)], [-sin(h), cos(h)]];
function leadSt(x) = [[x, 0], [0, 1]];

// stations, in travel order
chute_hi_st = [ for (y=[ytop:-5:ysplit]) strSt(y) ];
chute_lo_st = concat([ for (y=[ysplit:-5:arcTop[1]+0.01]) strSt(y) ], [ strSt(arcTop[1]) ]);
lead_st     = concat([ strSt(arcTop[1]) ], [ for (h=[-ang+2.5:2.5:0]) arcSt(h) ], [ for (x=[-L1+5:5:0]) leadSt(x) ]);
xExit = 110;         // exit length (the ring piece must fit the 270 mm bed)

module at_station(s, n, w) { // place a child at station s, n mm toward the ball, w sideways; child x = along travel
    t = [s[1][1], -s[1][0]];  // travel direction = normal turned -90 deg
    translate([s[0][0]+s[1][0]*n, s[0][1]+s[1][1]*n, w]) rotate([0,0,atan2(t[1],t[0])]) children();
}
// ---- joints: a dovetail key, full height of the lane (a vertical prism in the print: no overhang). One piece has the
// key on its end face, the other the matching slot (0.15 mm clearance). Slide them together from above.
function dove(c) = [[-0.01, -1.5-c], [5+c, -2.2-c], [5+c, 2.2+c], [-0.01, 1.5+c]];
module key2d(fwd, c) mirror([fwd>0?0:1, 0]) polygon(dove(c));
module peg(s, wlo, fwd=1, whi=undef) at_station(s, -T/2, wlo) linear_extrude(whi==undef ? (wlo==0 ? bA : bB1-bB0) : whi-wlo) key2d(fwd, 0);
module socket(s, wlo, fwd=1, whi=undef) at_station(s, -T/2, wlo-1) linear_extrude((whi==undef ? (wlo==0 ? bA : bB1-bB0) : whi-wlo)+2) key2d(fwd, 0.15);
// board tab: sticks out behind the wall, screw hole along w, 4 mm thick on the board side of the piece
module tab(s, wlo) at_station(s, -T, wlo) difference() {
    translate([-6, -9, 0]) cube([12, 9.2, 4]);
    translate([0, -5, -1]) cylinder(d=hole, h=6, $fn=24);
}

// ---- pieces ----
// ring: arc + lead-in (lane A) -> loop (lane A, then both, then lane B) -> exit (lane B), in ONE piece. Its lane B part
// near the bottom prints over supports (plate 11 only). The lane A tabs hold everything; no spacers.
module ring_main() difference() {
    union() {
        sweep(lead_st, [ for (s=lead_st) prof(0, bA, wA) ]);
        sweep([ for (th=[0:2.5:62.5]) ringSt(th) ], [ for (th=[0:2.5:62.5]) prof(0, bA, wA) ]);
        sweep([ for (th=[57.5:2.5:302.5]) ringSt(th) ], [ for (th=[57.5:2.5:302.5]) prof(0, bB1, wcRing(th)) ]);
        sweep([ for (th=[297.5:2.5:360]) ringSt(th) ], [ for (th=[297.5:2.5:360]) prof(bB0, bB1, wB) ]);
        sweep([ for (x=[0:5:xExit]) leadSt(x) ], [ for (x=[0:5:xExit]) prof(bB0, bB1, wB) ]);
        translate([xExit, -T, bB0]) cube([4, T+14, bB1-bB0]);           // end stop
        for (th=[30, 90, 135, 180, 210]) tab(ringSt(th), 0);
        tab(leadSt(-30), 0); tab(arcSt(-40), 0);
    }
    socket(strSt(arcTop[1]), 0, 1);  // chute_lo's key (it points down into this piece)
    at_station(ringSt(180), -T+0.5, bB1-0.6) rotate([0,0,180]) linear_extrude(1) text("TOP 165 mm", size=4, halign="center", valign="center");
    at_station(leadSt(14), -T+0.4, bB1-0.6) linear_extrude(1) text("< POI", size=3, halign="center", valign="center");
    at_station(leadSt(-14), -T+0.4, bA-0.6) linear_extrude(1) text("POI >", size=3, halign="center", valign="center");
}
module chute_lo() difference() {
    union() {
        sweep(chute_lo_st, [ for (s=chute_lo_st) prof(0, bA, wA) ]);
        peg(strSt(arcTop[1]), 0, 1);
        for (y=[70, 140]) tab(strSt(y), 0);
    }
    socket(strSt(ysplit), 0, 1);    // chute_hi's key (it points down into this piece)
}
module chute_hi() difference() {
    union() {
        sweep(chute_hi_st, [ for (s=chute_hi_st) prof(0, bA, wA) ]);
        peg(strSt(ysplit), 0, 1);
        for (y=[220, 300]) tab(strSt(y), 0);
        at_station(strSt(ytop), 0, 0) cube([3, 14, bA]);              // end stop above the top mark
    }
    // start-height marks: cm above the POI at the ridge tips (hold the ball here with the pencil)
    for (hc=[ceil(ysplit/10):1:floor((ytop-15)/10)]) let(s=strSt(hc*10-rp)) at_station(s, -T+0.4, bA-0.6) {
        translate([-0.4,-2,0]) cube([0.8, 2.4, 1]); translate([0,-4.6,0]) linear_extrude(1) text(str(hc), size=2.6, halign="center", valign="center"); }
}
// board tab hole centres (x, y): used by loop_board.scad for the drilling template
function tab_holes() = let(h=function(s) [s[0][0]+s[1][0]*(-T-5), s[0][1]+s[1][1]*(-T-5)])
    concat([ for (th=[30, 90, 135, 180, 210]) h(ringSt(th)) ], [ h(leadSt(-30)), h(arcSt(-40)) ],
           [ for (y=[70, 140]) h(strSt(y)) ], [ for (y=[220, 300]) h(strSt(y)) ]);

module assembly() {
    color("#59a5c4") ring_main();
    color("#d08a4a") chute_lo(); color("#c07a3a") chute_hi();
    color("silver") translate([0, rp + sqrt(ball_r*ball_r - rsep*rsep), wA]) sphere(r=ball_r, $fn=32);
}
if (part=="assembly")  assembly();
if (part=="ring_main") ring_main();
if (part=="chute_lo")  chute_lo();
if (part=="chute_hi")  chute_hi();
