// v1.8p (2026-10-30): Elevator 2 counterweight pot 34, BIGGER (owner approved: pot 34 only; the rest of E2 is frozen).
// Why: E2's true balance with the lever's weight is 106.0 g hanging (cad/v18c_e2_counterweight.py). 1.30 x = 137.8 g
// hanging. The v1.7 pot (cw_pot_slim: bore d 15 x 72) held only 12.7 cm3, about 64 g of loose steel nuts.
// New pot: a rounded square column 18 x 18 (the same X and Y footprint as the old d 18 pot: world X 71..89, Y 58..76),
// 138 mm tall, with a press-on lid held down by a steel pin 3 x 18 through two ears. The cord loop from the P2 block
// ties round the middle of the pin (the pin is the bail).
// Included by coaster_e2.scad. Local coordinates: X, Y as the world (hang axis at X 0, Y 0), Z 0 = the pot's floor
// underside. The pin centre is e2p_pin_z; it hangs e2p_drop under the P2 pulley centre (as the old bail hole: 23 -> 24).
e2p_w = 18; e2p_r = 2;            // outer square and corner radius
e2p_t = 1.6;                      // wall (4 lines of 0.4)
e2p_fl = 2.0;                     // floor
e2p_h = 138;                      // floor underside to the rim
e2p_in = e2p_w - 2*e2p_t;         // bore 14.8 x 14.8
e2p_lid_t = 2.5; e2p_plug = 3.0; e2p_lid_c = 0.2;   // lid plate, plug depth, clearance
e2p_cord = 1.3;                   // gap pin underside to lid top: the tied cord loop passes under the pin
e2p_ear_y = 4;                    // ears: Y -4..4 on the two X walls
e2p_ear_t = 3.2;                  // ear thickness in X (wall 1.6 + 1.6 ledge inside, 45 deg chamfer under the ledge)
e2p_led_h = 6;                    // ledge height under the rim (inside the bore), plus the chamfer
e2p_pin_z = e2p_h + e2p_lid_t + e2p_cord + 1.5;   // pin centre
e2p_top = e2p_pin_z + 4;          // ear top (2.5 mm over the pin hole)
e2p_drop = 24;                    // pin centre under the P2 pulley centre (ear top 20 under it: block underside is 18)
e2p_lid_x = e2p_in/2 - e2p_ear_t + e2p_t - e2p_lid_c;   // lid half width in X (between the ear ledges): 5.6
// fill marks (engraved): heights over the floor underside, set from the slicer grams (see docs/coaster_v1.8.md v1.8p)
e2p_marks = [["1.25", 99.2], ["1.30", 104.0], ["1.40", 113.6]];
module e2p_sq(w, r, h) linear_extrude(h) offset(r=r, $fn=24) square(w-2*r, center=true);
module e2p_ear(s) {         // ear on the X wall at side s (Y -4..4): wall + inner ledge carried up over the rim, 45 deg
    xi = e2p_in/2 - (e2p_ear_t - e2p_t); xw = e2p_in/2 + 0.3;   // chamfer under the ledge; ends 0.3 mm inside the wall
    intersection() {
        rotate([90,0,0]) linear_extrude(2*e2p_ear_y + 1, center=true) scale([s, 1])
            polygon([[xw, e2p_h - e2p_led_h - (xw - xi)], [xi, e2p_h - e2p_led_h], [xi, e2p_top], [e2p_w/2, e2p_top], [e2p_w/2, e2p_h], [xw, e2p_h]]);
        rotate([90,0,90]) linear_extrude(e2p_w + 2, center=true)
            hull() { translate([-e2p_ear_y, e2p_h - e2p_led_h - 3]) square([2*e2p_ear_y, 1]); for (y=[-1,1]) translate([y*(e2p_ear_y - 2), e2p_top - 2]) circle(r=2, $fn=24); }
    }
}
module e2p_tdrop_x(d, x0, x1) translate([x0, 0, e2p_pin_z]) rotate([0,90,0]) linear_extrude(x1 - x0)
    hull() { circle(d=d, $fn=fit_fn); translate([-d/2*sqrt(2), 0]) square(0.02, center=true); }   // point to +Z (rotated frame: -x)
module cw_pot2_v18() difference() {
    union() {
        difference() { e2p_sq(e2p_w, e2p_r, e2p_h); translate([0,0,e2p_fl]) e2p_sq(e2p_in, 0.4, e2p_h); }
        for (s=[-1,1]) e2p_ear(s);
    }
    // pin holes along X, teardrop point up: press in the -X ear, slip in the +X ear (push the pin out to refill)
    e2p_tdrop_x(pin_press_lying, -e2p_w/2 - 1, -e2p_w/2 + e2p_ear_t + 0.5);
    e2p_tdrop_x(pin_slip, e2p_w/2 - e2p_ear_t - 0.5, e2p_w/2 + 1);
    // fill marks: a 0.4 mm groove round the bore, and a tick + ratio on the front (+Y) face
    for (m=e2p_marks) {
        translate([0,0,m[1] - 0.3]) difference() { e2p_sq(e2p_in + 0.8, 0.6, 0.6); translate([0,0,-1]) e2p_sq(e2p_in - 1, 0.4, 3); }
        translate([1, e2p_w/2 - 0.4, m[1] - 0.3]) cube([5.5, 1, 0.6]);      // tick (left of the text, seen from the front)
        translate([0, e2p_w/2 - 0.4, m[1]]) rotate([90,0,180]) linear_extrude(1) text(m[0], size=2.2, halign="left", valign="center");
    }
    translate([0, e2p_w/2 - 0.4, 40]) rotate([90,0,180]) linear_extrude(1) rotate(90) text("34 E2", size=3.2, halign="center", valign="center");
}
// lid: plate on the two Y-wall rims between the ears, plug 3 mm into the bore (locates it in Y); prints plate down
module cw_pot2_lid() {
    translate([-e2p_lid_x, -e2p_w/2, e2p_h]) cube([2*e2p_lid_x, e2p_w, e2p_lid_t]);
    translate([-e2p_lid_x, -e2p_in/2 + e2p_lid_c, e2p_h - e2p_plug]) cube([2*e2p_lid_x, e2p_in - 2*e2p_lid_c, e2p_plug + 0.01]);
}
module cw_pot2_pin() color("silver") translate([0, 0, e2p_pin_z]) rotate([0,90,0]) cylinder(d=3, h=e2p_w, center=true, $fn=12);
module cw_pot2_asm() { cw_pot2_v18(); cw_pot2_lid(); cw_pot2_pin(); }
module cw_pot2_lid_print() translate([0, 0, e2p_h + e2p_lid_t]) rotate([180,0,0]) cw_pot2_lid();   // plate on the bed
// bore area (mm2); capacity = area x (135 - 2) less the ear ledges = 29.0 cm3 (cad/v18c_e2_counterweight.py)
function e2p_area() = e2p_in*e2p_in - (4 - PI)*0.4*0.4;
