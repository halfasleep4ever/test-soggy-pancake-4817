// v1.7 FEA (elevators): one E1 part in an FEA pose = its PRINT rotation (Z = layer direction, as E1_print), but
// in WORLD coordinates and with no turn about Z or shift on the bed, so the FEA selectors use world numbers.
//   e1_cw_post : print on its X 2 face   -> FEA (X, Y, Z) = (-Zw, Yw, Xw)
//   e1_frame   : print front face down    -> FEA (X, Y, Z) = (Xw, Zw, -Yw)
//   e1_foot    : slab down                -> FEA = world
//   e1_latch_post: print on its +x face   -> FEA (X, Y, Z) = (Zw, Yw, -Xw)
//   e1_lever / e1_wheel / e1_crank / e1_cup_frame / e1_idler / e1_cw_pot: the E1_print pose (local part coordinates)
// openscad --backend=Manifold -D 'fk="e1_cw_post"' -o fea/stl17/e1_cw_post.stl v17f_fea_e1.scad
include <coaster_e1.scad>
part = "none";
fk = "e1_cw_post";
module wld() translate(E1_ORIGIN) children();
if (fk=="e1_cw_post")    rotate([0,-90,0]) wld() E1_cwpost();
if (fk=="e1_frame")      rotate([-90,0,0]) wld() E1_frame();
if (fk=="e1_foot")       wld() E1_foot();
if (fk=="e1_latch_post") rotate([0,90,0]) wld() latch_post_v1();
if (fk=="e1_lever")      E1_print("e1_lever");
if (fk=="e1_wheel")      E1_print("e1_wheel");
if (fk=="e1_crank")      E1_print("e1_crank");
if (fk=="e1_cup_frame")  E1_print("e1_cup_frame");
if (fk=="e1_cup_floor")  E1_print("e1_cup_floor");
if (fk=="e1_idler")      E1_print("e1_idler");
if (fk=="e1_cw_pot")     E1_print("e1_cw_pot");
// assemblies of bolted parts, treated as bonded (FEA only). The checks use --eval to look at one part in its own pose.
//   e1_ff_frame: frame 12a + foot 12b in the FRAME's print pose -> (Xw, Zw, -Yw);  e1_ff_foot: same in the foot's pose (world)
if (fk=="e1_ff_frame") rotate([-90,0,0]) wld() union() { E1_frame(); E1_foot(); }
if (fk=="e1_ff_foot")  wld() union() { E1_frame(); E1_foot(); }
// cup frame with its floor pin drawn as a PETG rod (d 3.15 x 25.2, through both plates): the steel pin ties the two plates
// together; a PETG rod is soft in bending but stiff enough along its axis (EA/L about 670 N/mm) for a side push.
if (fk=="e1_cup_frame_pin") translate([0,0,4.5]) rotate([180,0,0]) { cup_frame(); translate(Pv) rotate([90,0,0]) cylinder(d=3.15, h=25.2, center=true, $fn=24); }
