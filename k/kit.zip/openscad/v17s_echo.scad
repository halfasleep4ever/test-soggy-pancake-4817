include <coaster_v1.scad>
part="none";
echo(E1land=E1land, E2land=E2land, E1tray=E1tray, armkz=min([for (xx=[30, 38], yy=[109, 124]) tr_plB(xx, yy)]));
echo(slab=[for(i=[0:1]) [rlx(i,34), rlx(i,222.8)]], ledgeY=-slabOut-1);
