// Rail + U-turn test: each printed part in its assembled position (for Blender). -D 'p="spine200"'
include <rail_test.scad>
part = "none"; p = "spine200";
module rail_asm(which) {
    gap = 12;
    translate([0, rod_cc(12)/2, 0]) {
        translate([20,0,0]) rotate([0,slope,0]) translate([-20,0,hA]) {
            if (which=="spine200")   spine(200);
            if (which=="carrier200") translate([0,-rod_cc(gap),slab_h]) carrier(200);
        }
        if (which=="riser_a") translate([20,riser_y,0]) riser(hA,"A");
        if (which=="riser_b") translate([180,riser_y,0]) riser(hB,"B");
    }
    if (which=="cup") cup();
    translate([200, plane_dy - rod_cc(12)/2, 0]) rotate([0,0,180]) {
        translate([20,0,0]) rotate([0,slope,0]) translate([-20,0,hC]) {
            if (which=="spine100")   spine(100);
            if (which=="carrier100") translate([0,-rod_cc(gap),slab_h]) carrier(100);
        }
        if (which=="riser_c") translate([20,riser_y,0]) riser(hC,"C");
        if (which=="riser_d") translate([80,riser_y,0]) riser(hD,"D");
    }
    if (which=="gauges") translate([40,-70,0]) gauges();
}
rail_asm(p);
